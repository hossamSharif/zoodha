"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_stripe-payment_stripe-payment_page_ts"],{

/***/ 17815:
/*!*******************************************************!*\
  !*** ./src/app/stripe-payment/stripe-payment.page.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StripePaymentPage": () => (/* binding */ StripePaymentPage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _stripe_payment_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stripe-payment.page.html?ngResource */ 30809);
/* harmony import */ var _stripe_payment_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./stripe-payment.page.scss?ngResource */ 70924);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/socket-service.service */ 20905);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ 92340);
/* harmony import */ var _capacitor_community_stripe__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor-community/stripe */ 49377);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 25670);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);











let StripePaymentPage = class StripePaymentPage {
  constructor(toast, loadingController, modalCtrl, api, httpClient, http) {
    this.toast = toast;
    this.loadingController = loadingController;
    this.modalCtrl = modalCtrl;
    this.api = api;
    this.httpClient = httpClient;
    this.http = http;
    this.data = {};
    this.apis = 'https://coral-app-pr5y9.ondigitalocean.app/transactions/subescribestripe';
    _capacitor_community_stripe__WEBPACK_IMPORTED_MODULE_5__.Stripe.initialize({
      publishableKey: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__.environment.stripe.publishableKey
    });
  }

  httpPost(data) {
    let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpParams();
    params = params.append('data', data);
    return this.http.post(this.apis, data).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.first)());
  }

  closeModel() {
    this.modalCtrl.dismiss();
  }

  ngOnInit() {
    console.log(this.mzd, this.USER_INFO, this.amount);
    this.prepareTransaction();
    this.data = {
      name: this.USER_INFO.fullName,
      email: this.USER_INFO.email,
      amount: this.amount,
      currency: 'usd',
      transaction: this.trasaction
    };
    console.log('data', this.data);
  }

  prepareTransaction() {
    {
      let details = "سداد فاتورة إشنراك في مزاد " + " " + this.mzd['title'];
      let fromAccount = this.USER_INFO._id;
      let toAccount = "310000205349900001"; // رقم حساب الشركة

      let fromAccountTitle = "حساب  : " + this.USER_INFO.fullName;
      let toAccountTitle = "شركة زوودها";
      let comment = "سداد فاتورة إشنراك في مزاد " + " " + "من مزاد : " + this.mzd['title'] + "," + "رقم: " + this.mzd['_id'];
      this.trasaction = {
        _id: "",
        orderId: "",
        auctId: this.mzd['_id'],
        userId: this.USER_INFO._id,
        currentStatus: 0,
        typee: 1,
        pay: this.amount,
        details: details,
        comment: comment,
        fromAccount: fromAccount,
        toAccount: toAccount,
        fromAccountTitle: fromAccountTitle,
        toAccountTitle: toAccountTitle
      };
    }
  }

  prepareUserbj(resubiscr) {
    if (!resubiscr) {
      let mzdTemp = {
        _id: this.mzd['_id'],
        user: [{
          "userId": this.USER_INFO._id,
          "status": 1,
          "time": new Date(),
          "cancel": 0,
          "cancelTime": "",
          "reason": "",
          "transactionId": ""
        }]
      };
      return mzdTemp;
    } else {
      let mzdTemp = {
        _id: this.mzd['_id'],
        user: [{
          "userId": this.USER_INFO._id,
          "cancel": 0,
          "cancelTime": null,
          "reason": "",
          "cancelTransId": ""
        }]
      };
      return mzdTemp;
    }
  }

  subescribe() {
    this.presentLoadingWithOptions("جاري معالجة طلبك .."); //api to add user to log of mzad
    //console.log('prepareUserbj',this.prepareUserbj())

    this.api.updateAuctionUsers(this.prepareUserbj()).subscribe(data => {
      console.log('auction update', data, data['updatedAuctionUsers']); // this.mzd['users'] = data['updatedAuctionUsers']['users']

      console.log(this.mzd);
      this.presentToast("تم الإشتراك بنجاح ", 'success'); //back to details page with new data

      this.modalCtrl.dismiss(this.mzd, 'done');
    }, err => {
      this.loadingController.dismiss();
      console.log(err.error); // this.handleError(err.error.error) 
    }); //api to add pay transaction + 
    //
    //socket emmit to tell others + push notification 
  }

  crateTrans() {
    this.api.createTrans(this.trasaction).subscribe(data => {
      console.log(data);
      this.subescribe();
    }, err => {
      this.loadingController.dismiss();
      console.log(err.error);
    });
  }

  paymentSheet() {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        // be able to get event of PaymentSheet
        _capacitor_community_stripe__WEBPACK_IMPORTED_MODULE_5__.Stripe.addListener(_capacitor_community_stripe__WEBPACK_IMPORTED_MODULE_5__.PaymentSheetEventsEnum.Completed, () => {
          console.log('PaymentSheetEventsEnum.Completed');
        }); // const data = new HttpParams({
        //   fromObject:this.data
        // })
        // Connect to your backend endpoint, and get every key.

        const data$ = _this.httpPost(_this.data); //  this.http.post<{
        //   paymentIntent: string;
        //   ephemeralKey: string;
        //   customer: string;
        // }>(this.apis + 'payment-sheet', {}).pipe(first());


        let paymentIntent;
        let ephemeralKey;
        let customer;
        const res = yield data$.subscribe(data => {
          console.log('serv', data);
          paymentIntent = data['paymentIntent'];
          ephemeralKey = data['ephemeralKey'];
          customer = data['customer'];
        }); // prepare PaymentSheet with CreatePaymentSheetOption.

        yield _capacitor_community_stripe__WEBPACK_IMPORTED_MODULE_5__.Stripe.createPaymentSheet({
          paymentIntentClientSecret: paymentIntent,
          customerId: customer,
          customerEphemeralKeySecret: ephemeralKey,
          merchantDisplayName: "zoodoha"
        }); // present PaymentSheet and get result.

        const result = yield _capacitor_community_stripe__WEBPACK_IMPORTED_MODULE_5__.Stripe.presentPaymentSheet();

        if (result.paymentResult === _capacitor_community_stripe__WEBPACK_IMPORTED_MODULE_5__.PaymentSheetEventsEnum.Completed) {
          //create transaction done in the backend 
          //api to add user to log of mzad
          _this.crateTrans();

          console.log('Happy path', result.paymentResult);
        }
      } catch (error) {
        console.log('err', error);
      }
    })();
  } // async applePaySheet () {
  //   try {
  //     const isAvailable = Stripe.isApplePayAvailable().catch(() => undefined);
  //     if (isAvailable === undefined) {
  //       // disable to use Google Pay
  //       return;
  //     }
  //     // be able to get event of Apple Pay
  //     Stripe.addListener(ApplePayEventsEnum.Completed, () => {
  //       console.log('ApplePayEventsEnum.Completed');
  //     });
  //     // Connect to your backend endpoint, and get paymentIntent.
  //     const data$ =  this.httpPost(this.data)
  //     //  this.http.post<{
  //     //   paymentIntent: string;
  //     //   ephemeralKey: string;
  //     //   customer: string;
  //     // }>(this.apis + 'payment-sheet', {}).pipe(first());
  //      let paymentIntent :any  
  //     const res = await data$.subscribe(data =>{
  //       paymentIntent = data['paymentIntent'] 
  //     }) ; 
  //     // const { paymentIntent } = await this.http.post<{
  //     //   paymentIntent: string;
  //     // }>(environment.api + 'payment-sheet', {}).pipe(first()).toPromise(Promise);
  //     // Prepare Apple Pay
  //     await Stripe.createApplePay({
  //       paymentIntentClientSecret: paymentIntent,
  //       paymentSummaryItems: [{
  //         label: 'Product Name',
  //         amount: 1099.00
  //       }],
  //       merchantDisplayName: 'ksdshd',
  //       countryCode: 'US',
  //       currency: 'USD',
  //     });
  //     // Present Apple Pay
  //     const result = await Stripe.presentApplePay();
  //     if (result.paymentResult === ApplePayEventsEnum.Completed) {
  //       // Happy path
  //     }
  //   } catch (error) {
  //     console.log('err',error)
  //   }
  // }
  // Check to be able to use Apple Pay on device


  PaymentFlowSheet() {
    var _this2 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        _capacitor_community_stripe__WEBPACK_IMPORTED_MODULE_5__.Stripe.addListener(_capacitor_community_stripe__WEBPACK_IMPORTED_MODULE_5__.PaymentFlowEventsEnum.Completed, () => {
          console.log('PaymentFlowEventsEnum.Completed');
        }); // Connect to your backend endpoint, and get every key.

        const data$ = _this2.httpPost(_this2.data); //  this.http.post<{
        //   paymentIntent: string;
        //   ephemeralKey: string;
        //   customer: string;
        // }>(this.apis + 'payment-sheet', {}).pipe(first());


        let paymentIntent;
        let ephemeralKey;
        let customer;
        const res = yield data$.subscribe(data => {
          paymentIntent = data['paymentIntent'];
          ephemeralKey = data['ephemeralKey'];
          customer = data['customer'];
        }); // Prepare PaymentFlow with CreatePaymentFlowOption.

        _capacitor_community_stripe__WEBPACK_IMPORTED_MODULE_5__.Stripe.createPaymentFlow({
          paymentIntentClientSecret: paymentIntent,
          merchantDisplayName: "zoodoha",
          // setupIntentClientSecret: setupIntent,
          customerEphemeralKeySecret: ephemeralKey,
          customerId: customer
        }); // Present PaymentFlow. **Not completed yet.**

        const presentResult = yield _capacitor_community_stripe__WEBPACK_IMPORTED_MODULE_5__.Stripe.presentPaymentFlow();
        console.log(presentResult); // { cardNumber: "●●●● ●●●● ●●●● ****" }
        // Confirm PaymentFlow. Completed.

        const confirmResult = yield _capacitor_community_stripe__WEBPACK_IMPORTED_MODULE_5__.Stripe.confirmPaymentFlow();

        if (confirmResult.paymentResult === _capacitor_community_stripe__WEBPACK_IMPORTED_MODULE_5__.PaymentFlowEventsEnum.Completed) {// Happy path
        }
      } catch (error) {
        console.log('err', error);
      }
    })();
  }

  presentLoadingWithOptions(msg) {
    var _this3 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this3.loadingController.create({
        spinner: 'bubbles',
        mode: 'ios',
        duration: 5000,
        message: msg,
        translucent: true,
        // cssClass: 'custom-class custom-loading',
        backdropDismiss: false
      });
      yield loading.present();
      const {
        role,
        data
      } = yield loading.onDidDismiss();
      console.log('Loading dismissed with role:', role);
    })();
  }

  presentToast(msg, color) {
    var _this4 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this4.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  }

};

StripePaymentPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.LoadingController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService
}, {
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClientModule
}, {
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient
}];

StripePaymentPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-stripe-payment',
  template: _stripe_payment_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_stripe_payment_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], StripePaymentPage);


/***/ }),

/***/ 11859:
/*!*******************************************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/applepay/apple-pay-difinitions.interface.js ***!
  \*******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);


/***/ }),

/***/ 61744:
/*!*********************************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/applepay/apple-pay-events.enum.js ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApplePayEventsEnum": () => (/* binding */ ApplePayEventsEnum)
/* harmony export */ });
var ApplePayEventsEnum;

(function (ApplePayEventsEnum) {
  ApplePayEventsEnum["Loaded"] = "applePayLoaded";
  ApplePayEventsEnum["FailedToLoad"] = "applePayFailedToLoad";
  ApplePayEventsEnum["Completed"] = "applePayCompleted";
  ApplePayEventsEnum["Canceled"] = "applePayCanceled";
  ApplePayEventsEnum["Failed"] = "applePayFailed";
  ApplePayEventsEnum["DidSelectShippingContact"] = "applePayDidSelectShippingContact";
  ApplePayEventsEnum["DidCreatePaymentMethod"] = "applePayDidCreatePaymentMethod";
})(ApplePayEventsEnum || (ApplePayEventsEnum = {}));

/***/ }),

/***/ 37084:
/*!*****************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/applepay/index.js ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApplePayEventsEnum": () => (/* reexport safe */ _apple_pay_events_enum__WEBPACK_IMPORTED_MODULE_0__.ApplePayEventsEnum)
/* harmony export */ });
/* harmony import */ var _apple_pay_events_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./apple-pay-events.enum */ 61744);
/* harmony import */ var _apple_pay_difinitions_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./apple-pay-difinitions.interface */ 11859);



/***/ }),

/***/ 53073:
/*!**************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/definitions.js ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApplePayEventsEnum": () => (/* reexport safe */ _applepay_index__WEBPACK_IMPORTED_MODULE_0__.ApplePayEventsEnum),
/* harmony export */   "GooglePayEventsEnum": () => (/* reexport safe */ _googlepay_index__WEBPACK_IMPORTED_MODULE_1__.GooglePayEventsEnum),
/* harmony export */   "PaymentFlowEventsEnum": () => (/* reexport safe */ _paymentflow_index__WEBPACK_IMPORTED_MODULE_2__.PaymentFlowEventsEnum),
/* harmony export */   "PaymentSheetEventsEnum": () => (/* reexport safe */ _paymentsheet_index__WEBPACK_IMPORTED_MODULE_3__.PaymentSheetEventsEnum)
/* harmony export */ });
/* harmony import */ var _applepay_index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./applepay/index */ 37084);
/* harmony import */ var _googlepay_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./googlepay/index */ 58367);
/* harmony import */ var _paymentflow_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./paymentflow/index */ 35119);
/* harmony import */ var _paymentsheet_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./paymentsheet/index */ 31793);
/* harmony import */ var _shared_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./shared/index */ 10934);






/***/ }),

/***/ 53771:
/*!*********************************************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/googlepay/google-pay-difinitions.interface.js ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);


/***/ }),

/***/ 28523:
/*!***********************************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/googlepay/google-pay-events.enum.js ***!
  \***********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GooglePayEventsEnum": () => (/* binding */ GooglePayEventsEnum)
/* harmony export */ });
var GooglePayEventsEnum;

(function (GooglePayEventsEnum) {
  GooglePayEventsEnum["Loaded"] = "googlePayLoaded";
  GooglePayEventsEnum["FailedToLoad"] = "googlePayFailedToLoad";
  GooglePayEventsEnum["Completed"] = "googlePayCompleted";
  GooglePayEventsEnum["Canceled"] = "googlePayCanceled";
  GooglePayEventsEnum["Failed"] = "googlePayFailed";
})(GooglePayEventsEnum || (GooglePayEventsEnum = {}));

/***/ }),

/***/ 58367:
/*!******************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/googlepay/index.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GooglePayEventsEnum": () => (/* reexport safe */ _google_pay_events_enum__WEBPACK_IMPORTED_MODULE_0__.GooglePayEventsEnum)
/* harmony export */ });
/* harmony import */ var _google_pay_events_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./google-pay-events.enum */ 28523);
/* harmony import */ var _google_pay_difinitions_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./google-pay-difinitions.interface */ 53771);



/***/ }),

/***/ 49377:
/*!********************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/index.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApplePayEventsEnum": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.ApplePayEventsEnum),
/* harmony export */   "GooglePayEventsEnum": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.GooglePayEventsEnum),
/* harmony export */   "PaymentFlowEventsEnum": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.PaymentFlowEventsEnum),
/* harmony export */   "PaymentSheetEventsEnum": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.PaymentSheetEventsEnum),
/* harmony export */   "Stripe": () => (/* binding */ Stripe)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 26549);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 53073);

const Stripe = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('Stripe', {
  web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor-community_stripe_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 48802)).then(m => new m.StripeWeb())
});



/***/ }),

/***/ 35119:
/*!********************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/paymentflow/index.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentFlowEventsEnum": () => (/* reexport safe */ _payment_flow_events_enum__WEBPACK_IMPORTED_MODULE_0__.PaymentFlowEventsEnum)
/* harmony export */ });
/* harmony import */ var _payment_flow_events_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-flow-events.enum */ 98485);
/* harmony import */ var _payment_flow_definitions_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment-flow-definitions.interface */ 41880);



/***/ }),

/***/ 41880:
/*!*************************************************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/paymentflow/payment-flow-definitions.interface.js ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);


/***/ }),

/***/ 98485:
/*!***************************************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/paymentflow/payment-flow-events.enum.js ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentFlowEventsEnum": () => (/* binding */ PaymentFlowEventsEnum)
/* harmony export */ });
var PaymentFlowEventsEnum;

(function (PaymentFlowEventsEnum) {
  PaymentFlowEventsEnum["Loaded"] = "paymentFlowLoaded";
  PaymentFlowEventsEnum["FailedToLoad"] = "paymentFlowFailedToLoad";
  PaymentFlowEventsEnum["Opened"] = "paymentFlowOpened";
  PaymentFlowEventsEnum["Created"] = "paymentFlowCreated";
  PaymentFlowEventsEnum["Completed"] = "paymentFlowCompleted";
  PaymentFlowEventsEnum["Canceled"] = "paymentFlowCanceled";
  PaymentFlowEventsEnum["Failed"] = "paymentFlowFailed";
})(PaymentFlowEventsEnum || (PaymentFlowEventsEnum = {}));

/***/ }),

/***/ 31793:
/*!*********************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/paymentsheet/index.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentSheetEventsEnum": () => (/* reexport safe */ _payment_sheet_events_enum__WEBPACK_IMPORTED_MODULE_0__.PaymentSheetEventsEnum)
/* harmony export */ });
/* harmony import */ var _payment_sheet_events_enum__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./payment-sheet-events.enum */ 27707);
/* harmony import */ var _payment_sheet_definitions_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./payment-sheet-definitions.interface */ 72482);



/***/ }),

/***/ 72482:
/*!***************************************************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/paymentsheet/payment-sheet-definitions.interface.js ***!
  \***************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);


/***/ }),

/***/ 27707:
/*!*****************************************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/paymentsheet/payment-sheet-events.enum.js ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PaymentSheetEventsEnum": () => (/* binding */ PaymentSheetEventsEnum)
/* harmony export */ });
var PaymentSheetEventsEnum;

(function (PaymentSheetEventsEnum) {
  PaymentSheetEventsEnum["Loaded"] = "paymentSheetLoaded";
  PaymentSheetEventsEnum["FailedToLoad"] = "paymentSheetFailedToLoad";
  PaymentSheetEventsEnum["Completed"] = "paymentSheetCompleted";
  PaymentSheetEventsEnum["Canceled"] = "paymentSheetCanceled";
  PaymentSheetEventsEnum["Failed"] = "paymentSheetFailed";
})(PaymentSheetEventsEnum || (PaymentSheetEventsEnum = {}));

/***/ }),

/***/ 10934:
/*!***************************************************************************!*\
  !*** ./node_modules/@capacitor-community/stripe/dist/esm/shared/index.js ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);


/***/ }),

/***/ 26549:
/*!****************************************************!*\
  !*** ./node_modules/@capacitor/core/dist/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Capacitor": () => (/* binding */ Capacitor),
/* harmony export */   "CapacitorCookies": () => (/* binding */ CapacitorCookies),
/* harmony export */   "CapacitorException": () => (/* binding */ CapacitorException),
/* harmony export */   "CapacitorHttp": () => (/* binding */ CapacitorHttp),
/* harmony export */   "CapacitorPlatforms": () => (/* binding */ CapacitorPlatforms),
/* harmony export */   "ExceptionCode": () => (/* binding */ ExceptionCode),
/* harmony export */   "Plugins": () => (/* binding */ Plugins),
/* harmony export */   "WebPlugin": () => (/* binding */ WebPlugin),
/* harmony export */   "WebView": () => (/* binding */ WebView),
/* harmony export */   "addPlatform": () => (/* binding */ addPlatform),
/* harmony export */   "registerPlugin": () => (/* binding */ registerPlugin),
/* harmony export */   "registerWebPlugin": () => (/* binding */ registerWebPlugin),
/* harmony export */   "setPlatform": () => (/* binding */ setPlatform)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);


/*! Capacitor: https://capacitorjs.com/ - MIT License */
const createCapacitorPlatforms = win => {
  const defaultPlatformMap = new Map();
  defaultPlatformMap.set('web', {
    name: 'web'
  });
  const capPlatforms = win.CapacitorPlatforms || {
    currentPlatform: {
      name: 'web'
    },
    platforms: defaultPlatformMap
  };

  const addPlatform = (name, platform) => {
    capPlatforms.platforms.set(name, platform);
  };

  const setPlatform = name => {
    if (capPlatforms.platforms.has(name)) {
      capPlatforms.currentPlatform = capPlatforms.platforms.get(name);
    }
  };

  capPlatforms.addPlatform = addPlatform;
  capPlatforms.setPlatform = setPlatform;
  return capPlatforms;
};

const initPlatforms = win => win.CapacitorPlatforms = createCapacitorPlatforms(win);
/**
 * @deprecated Set `CapacitorCustomPlatform` on the window object prior to runtime executing in the web app instead
 */


const CapacitorPlatforms = /*#__PURE__*/initPlatforms(typeof globalThis !== 'undefined' ? globalThis : typeof self !== 'undefined' ? self : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : {});
/**
 * @deprecated Set `CapacitorCustomPlatform` on the window object prior to runtime executing in the web app instead
 */

const addPlatform = CapacitorPlatforms.addPlatform;
/**
 * @deprecated Set `CapacitorCustomPlatform` on the window object prior to runtime executing in the web app instead
 */

const setPlatform = CapacitorPlatforms.setPlatform;

const legacyRegisterWebPlugin = (cap, webPlugin) => {
  var _a;

  const config = webPlugin.config;
  const Plugins = cap.Plugins;

  if (!config || !config.name) {
    // TODO: add link to upgrade guide
    throw new Error(`Capacitor WebPlugin is using the deprecated "registerWebPlugin()" function, but without the config. Please use "registerPlugin()" instead to register this web plugin."`);
  } // TODO: add link to upgrade guide


  console.warn(`Capacitor plugin "${config.name}" is using the deprecated "registerWebPlugin()" function`);

  if (!Plugins[config.name] || ((_a = config === null || config === void 0 ? void 0 : config.platforms) === null || _a === void 0 ? void 0 : _a.includes(cap.getPlatform()))) {
    // Add the web plugin into the plugins registry if there already isn't
    // an existing one. If it doesn't already exist, that means
    // there's no existing native implementation for it.
    // - OR -
    // If we already have a plugin registered (meaning it was defined in the native layer),
    // then we should only overwrite it if the corresponding web plugin activates on
    // a certain platform. For example: Geolocation uses the WebPlugin on Android but not iOS
    Plugins[config.name] = webPlugin;
  }
};

var ExceptionCode;

(function (ExceptionCode) {
  /**
   * API is not implemented.
   *
   * This usually means the API can't be used because it is not implemented for
   * the current platform.
   */
  ExceptionCode["Unimplemented"] = "UNIMPLEMENTED";
  /**
   * API is not available.
   *
   * This means the API can't be used right now because:
   *   - it is currently missing a prerequisite, such as network connectivity
   *   - it requires a particular platform or browser version
   */

  ExceptionCode["Unavailable"] = "UNAVAILABLE";
})(ExceptionCode || (ExceptionCode = {}));

class CapacitorException extends Error {
  constructor(message, code, data) {
    super(message);
    this.message = message;
    this.code = code;
    this.data = data;
  }

}

const getPlatformId = win => {
  var _a, _b;

  if (win === null || win === void 0 ? void 0 : win.androidBridge) {
    return 'android';
  } else if ((_b = (_a = win === null || win === void 0 ? void 0 : win.webkit) === null || _a === void 0 ? void 0 : _a.messageHandlers) === null || _b === void 0 ? void 0 : _b.bridge) {
    return 'ios';
  } else {
    return 'web';
  }
};

const createCapacitor = win => {
  var _a, _b, _c, _d, _e;

  const capCustomPlatform = win.CapacitorCustomPlatform || null;
  const cap = win.Capacitor || {};
  const Plugins = cap.Plugins = cap.Plugins || {};
  /**
   * @deprecated Use `capCustomPlatform` instead, default functions like registerPlugin will function with the new object.
   */

  const capPlatforms = win.CapacitorPlatforms;

  const defaultGetPlatform = () => {
    return capCustomPlatform !== null ? capCustomPlatform.name : getPlatformId(win);
  };

  const getPlatform = ((_a = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _a === void 0 ? void 0 : _a.getPlatform) || defaultGetPlatform;

  const defaultIsNativePlatform = () => getPlatform() !== 'web';

  const isNativePlatform = ((_b = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _b === void 0 ? void 0 : _b.isNativePlatform) || defaultIsNativePlatform;

  const defaultIsPluginAvailable = pluginName => {
    const plugin = registeredPlugins.get(pluginName);

    if (plugin === null || plugin === void 0 ? void 0 : plugin.platforms.has(getPlatform())) {
      // JS implementation available for the current platform.
      return true;
    }

    if (getPluginHeader(pluginName)) {
      // Native implementation available.
      return true;
    }

    return false;
  };

  const isPluginAvailable = ((_c = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _c === void 0 ? void 0 : _c.isPluginAvailable) || defaultIsPluginAvailable;

  const defaultGetPluginHeader = pluginName => {
    var _a;

    return (_a = cap.PluginHeaders) === null || _a === void 0 ? void 0 : _a.find(h => h.name === pluginName);
  };

  const getPluginHeader = ((_d = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _d === void 0 ? void 0 : _d.getPluginHeader) || defaultGetPluginHeader;

  const handleError = err => win.console.error(err);

  const pluginMethodNoop = (_target, prop, pluginName) => {
    return Promise.reject(`${pluginName} does not have an implementation of "${prop}".`);
  };

  const registeredPlugins = new Map();

  const defaultRegisterPlugin = (pluginName, jsImplementations = {}) => {
    const registeredPlugin = registeredPlugins.get(pluginName);

    if (registeredPlugin) {
      console.warn(`Capacitor plugin "${pluginName}" already registered. Cannot register plugins twice.`);
      return registeredPlugin.proxy;
    }

    const platform = getPlatform();
    const pluginHeader = getPluginHeader(pluginName);
    let jsImplementation;

    const loadPluginImplementation = /*#__PURE__*/function () {
      var _ref = (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
        if (!jsImplementation && platform in jsImplementations) {
          jsImplementation = typeof jsImplementations[platform] === 'function' ? jsImplementation = yield jsImplementations[platform]() : jsImplementation = jsImplementations[platform];
        } else if (capCustomPlatform !== null && !jsImplementation && 'web' in jsImplementations) {
          jsImplementation = typeof jsImplementations['web'] === 'function' ? jsImplementation = yield jsImplementations['web']() : jsImplementation = jsImplementations['web'];
        }

        return jsImplementation;
      });

      return function loadPluginImplementation() {
        return _ref.apply(this, arguments);
      };
    }();

    const createPluginMethod = (impl, prop) => {
      var _a, _b;

      if (pluginHeader) {
        const methodHeader = pluginHeader === null || pluginHeader === void 0 ? void 0 : pluginHeader.methods.find(m => prop === m.name);

        if (methodHeader) {
          if (methodHeader.rtype === 'promise') {
            return options => cap.nativePromise(pluginName, prop.toString(), options);
          } else {
            return (options, callback) => cap.nativeCallback(pluginName, prop.toString(), options, callback);
          }
        } else if (impl) {
          return (_a = impl[prop]) === null || _a === void 0 ? void 0 : _a.bind(impl);
        }
      } else if (impl) {
        return (_b = impl[prop]) === null || _b === void 0 ? void 0 : _b.bind(impl);
      } else {
        throw new CapacitorException(`"${pluginName}" plugin is not implemented on ${platform}`, ExceptionCode.Unimplemented);
      }
    };

    const createPluginMethodWrapper = prop => {
      let remove;

      const wrapper = (...args) => {
        const p = loadPluginImplementation().then(impl => {
          const fn = createPluginMethod(impl, prop);

          if (fn) {
            const p = fn(...args);
            remove = p === null || p === void 0 ? void 0 : p.remove;
            return p;
          } else {
            throw new CapacitorException(`"${pluginName}.${prop}()" is not implemented on ${platform}`, ExceptionCode.Unimplemented);
          }
        });

        if (prop === 'addListener') {
          p.remove = /*#__PURE__*/(0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
            return remove();
          });
        }

        return p;
      }; // Some flair ✨


      wrapper.toString = () => `${prop.toString()}() { [capacitor code] }`;

      Object.defineProperty(wrapper, 'name', {
        value: prop,
        writable: false,
        configurable: false
      });
      return wrapper;
    };

    const addListener = createPluginMethodWrapper('addListener');
    const removeListener = createPluginMethodWrapper('removeListener');

    const addListenerNative = (eventName, callback) => {
      const call = addListener({
        eventName
      }, callback);

      const remove = /*#__PURE__*/function () {
        var _ref3 = (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
          const callbackId = yield call;
          removeListener({
            eventName,
            callbackId
          }, callback);
        });

        return function remove() {
          return _ref3.apply(this, arguments);
        };
      }();

      const p = new Promise(resolve => call.then(() => resolve({
        remove
      })));
      p.remove = /*#__PURE__*/(0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
        console.warn(`Using addListener() without 'await' is deprecated.`);
        yield remove();
      });
      return p;
    };

    const proxy = new Proxy({}, {
      get(_, prop) {
        switch (prop) {
          // https://github.com/facebook/react/issues/20030
          case '$$typeof':
            return undefined;

          case 'toJSON':
            return () => ({});

          case 'addListener':
            return pluginHeader ? addListenerNative : addListener;

          case 'removeListener':
            return removeListener;

          default:
            return createPluginMethodWrapper(prop);
        }
      }

    });
    Plugins[pluginName] = proxy;
    registeredPlugins.set(pluginName, {
      name: pluginName,
      proxy,
      platforms: new Set([...Object.keys(jsImplementations), ...(pluginHeader ? [platform] : [])])
    });
    return proxy;
  };

  const registerPlugin = ((_e = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _e === void 0 ? void 0 : _e.registerPlugin) || defaultRegisterPlugin; // Add in convertFileSrc for web, it will already be available in native context

  if (!cap.convertFileSrc) {
    cap.convertFileSrc = filePath => filePath;
  }

  cap.getPlatform = getPlatform;
  cap.handleError = handleError;
  cap.isNativePlatform = isNativePlatform;
  cap.isPluginAvailable = isPluginAvailable;
  cap.pluginMethodNoop = pluginMethodNoop;
  cap.registerPlugin = registerPlugin;
  cap.Exception = CapacitorException;
  cap.DEBUG = !!cap.DEBUG;
  cap.isLoggingEnabled = !!cap.isLoggingEnabled; // Deprecated props

  cap.platform = cap.getPlatform();
  cap.isNative = cap.isNativePlatform();
  return cap;
};

const initCapacitorGlobal = win => win.Capacitor = createCapacitor(win);

const Capacitor = /*#__PURE__*/initCapacitorGlobal(typeof globalThis !== 'undefined' ? globalThis : typeof self !== 'undefined' ? self : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : {});
const registerPlugin = Capacitor.registerPlugin;
/**
 * @deprecated Provided for backwards compatibility for Capacitor v2 plugins.
 * Capacitor v3 plugins should import the plugin directly. This "Plugins"
 * export is deprecated in v3, and will be removed in v4.
 */

const Plugins = Capacitor.Plugins;
/**
 * Provided for backwards compatibility. Use the registerPlugin() API
 * instead, and provide the web plugin as the "web" implmenetation.
 * For example
 *
 * export const Example = registerPlugin('Example', {
 *   web: () => import('./web').then(m => new m.Example())
 * })
 *
 * @deprecated Deprecated in v3, will be removed from v4.
 */

const registerWebPlugin = plugin => legacyRegisterWebPlugin(Capacitor, plugin);
/**
 * Base class web plugins should extend.
 */


class WebPlugin {
  constructor(config) {
    this.listeners = {};
    this.windowListeners = {};

    if (config) {
      // TODO: add link to upgrade guide
      console.warn(`Capacitor WebPlugin "${config.name}" config object was deprecated in v3 and will be removed in v4.`);
      this.config = config;
    }
  }

  addListener(eventName, listenerFunc) {
    var _this = this;

    const listeners = this.listeners[eventName];

    if (!listeners) {
      this.listeners[eventName] = [];
    }

    this.listeners[eventName].push(listenerFunc); // If we haven't added a window listener for this event and it requires one,
    // go ahead and add it

    const windowListener = this.windowListeners[eventName];

    if (windowListener && !windowListener.registered) {
      this.addWindowListener(windowListener);
    }

    const remove = /*#__PURE__*/function () {
      var _ref5 = (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
        return _this.removeListener(eventName, listenerFunc);
      });

      return function remove() {
        return _ref5.apply(this, arguments);
      };
    }();

    const p = Promise.resolve({
      remove
    });
    Object.defineProperty(p, 'remove', {
      value: function () {
        var _ref6 = (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
          console.warn(`Using addListener() without 'await' is deprecated.`);
          yield remove();
        });

        return function value() {
          return _ref6.apply(this, arguments);
        };
      }()
    });
    return p;
  }

  removeAllListeners() {
    var _this2 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.listeners = {};

      for (const listener in _this2.windowListeners) {
        _this2.removeWindowListener(_this2.windowListeners[listener]);
      }

      _this2.windowListeners = {};
    })();
  }

  notifyListeners(eventName, data) {
    const listeners = this.listeners[eventName];

    if (listeners) {
      listeners.forEach(listener => listener(data));
    }
  }

  hasListeners(eventName) {
    return !!this.listeners[eventName].length;
  }

  registerWindowListener(windowEventName, pluginEventName) {
    this.windowListeners[pluginEventName] = {
      registered: false,
      windowEventName,
      pluginEventName,
      handler: event => {
        this.notifyListeners(pluginEventName, event);
      }
    };
  }

  unimplemented(msg = 'not implemented') {
    return new Capacitor.Exception(msg, ExceptionCode.Unimplemented);
  }

  unavailable(msg = 'not available') {
    return new Capacitor.Exception(msg, ExceptionCode.Unavailable);
  }

  removeListener(eventName, listenerFunc) {
    var _this3 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const listeners = _this3.listeners[eventName];

      if (!listeners) {
        return;
      }

      const index = listeners.indexOf(listenerFunc);

      _this3.listeners[eventName].splice(index, 1); // If there are no more listeners for this type of event,
      // remove the window listener


      if (!_this3.listeners[eventName].length) {
        _this3.removeWindowListener(_this3.windowListeners[eventName]);
      }
    })();
  }

  addWindowListener(handle) {
    window.addEventListener(handle.windowEventName, handle.handler);
    handle.registered = true;
  }

  removeWindowListener(handle) {
    if (!handle) {
      return;
    }

    window.removeEventListener(handle.windowEventName, handle.handler);
    handle.registered = false;
  }

}

const WebView = /*#__PURE__*/registerPlugin('WebView');
/******** END WEB VIEW PLUGIN ********/

/******** COOKIES PLUGIN ********/

/**
 * Safely web encode a string value (inspired by js-cookie)
 * @param str The string value to encode
 */

const encode = str => encodeURIComponent(str).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
/**
 * Safely web decode a string value (inspired by js-cookie)
 * @param str The string value to decode
 */


const decode = str => str.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent);

class CapacitorCookiesPluginWeb extends WebPlugin {
  getCookies() {
    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const cookies = document.cookie;
      const cookieMap = {};
      cookies.split(';').forEach(cookie => {
        if (cookie.length <= 0) return; // Replace first "=" with CAP_COOKIE to prevent splitting on additional "="

        let [key, value] = cookie.replace(/=/, 'CAP_COOKIE').split('CAP_COOKIE');
        key = decode(key).trim();
        value = decode(value).trim();
        cookieMap[key] = value;
      });
      return cookieMap;
    })();
  }

  setCookie(options) {
    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        // Safely Encoded Key/Value
        const encodedKey = encode(options.key);
        const encodedValue = encode(options.value); // Clean & sanitize options

        const expires = `; expires=${(options.expires || '').replace('expires=', '')}`; // Default is "; expires="

        const path = (options.path || '/').replace('path=', ''); // Default is "path=/"

        const domain = options.url != null && options.url.length > 0 ? `domain=${options.url}` : '';
        document.cookie = `${encodedKey}=${encodedValue || ''}${expires}; path=${path}; ${domain};`;
      } catch (error) {
        return Promise.reject(error);
      }
    })();
  }

  deleteCookie(options) {
    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        document.cookie = `${options.key}=; Max-Age=0`;
      } catch (error) {
        return Promise.reject(error);
      }
    })();
  }

  clearCookies() {
    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        const cookies = document.cookie.split(';') || [];

        for (const cookie of cookies) {
          document.cookie = cookie.replace(/^ +/, '').replace(/=.*/, `=;expires=${new Date().toUTCString()};path=/`);
        }
      } catch (error) {
        return Promise.reject(error);
      }
    })();
  }

  clearAllCookies() {
    var _this4 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      try {
        yield _this4.clearCookies();
      } catch (error) {
        return Promise.reject(error);
      }
    })();
  }

}

const CapacitorCookies = registerPlugin('CapacitorCookies', {
  web: () => new CapacitorCookiesPluginWeb()
}); // UTILITY FUNCTIONS

/**
 * Read in a Blob value and return it as a base64 string
 * @param blob The blob value to convert to a base64 string
 */

const readBlobAsBase64 = /*#__PURE__*/function () {
  var _ref7 = (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = () => {
        const base64String = reader.result; // remove prefix "data:application/pdf;base64,"

        resolve(base64String.indexOf(',') >= 0 ? base64String.split(',')[1] : base64String);
      };

      reader.onerror = error => reject(error);

      reader.readAsDataURL(blob);
    });
  });

  return function readBlobAsBase64(_x) {
    return _ref7.apply(this, arguments);
  };
}();
/**
 * Normalize an HttpHeaders map by lowercasing all of the values
 * @param headers The HttpHeaders object to normalize
 */


const normalizeHttpHeaders = (headers = {}) => {
  const originalKeys = Object.keys(headers);
  const loweredKeys = Object.keys(headers).map(k => k.toLocaleLowerCase());
  const normalized = loweredKeys.reduce((acc, key, index) => {
    acc[key] = headers[originalKeys[index]];
    return acc;
  }, {});
  return normalized;
};
/**
 * Builds a string of url parameters that
 * @param params A map of url parameters
 * @param shouldEncode true if you should encodeURIComponent() the values (true by default)
 */


const buildUrlParams = (params, shouldEncode = true) => {
  if (!params) return null;
  const output = Object.entries(params).reduce((accumulator, entry) => {
    const [key, value] = entry;
    let encodedValue;
    let item;

    if (Array.isArray(value)) {
      item = '';
      value.forEach(str => {
        encodedValue = shouldEncode ? encodeURIComponent(str) : str;
        item += `${key}=${encodedValue}&`;
      }); // last character will always be "&" so slice it off

      item.slice(0, -1);
    } else {
      encodedValue = shouldEncode ? encodeURIComponent(value) : value;
      item = `${key}=${encodedValue}`;
    }

    return `${accumulator}&${item}`;
  }, ''); // Remove initial "&" from the reduce

  return output.substr(1);
};
/**
 * Build the RequestInit object based on the options passed into the initial request
 * @param options The Http plugin options
 * @param extra Any extra RequestInit values
 */


const buildRequestInit = (options, extra = {}) => {
  const output = Object.assign({
    method: options.method || 'GET',
    headers: options.headers
  }, extra); // Get the content-type

  const headers = normalizeHttpHeaders(options.headers);
  const type = headers['content-type'] || ''; // If body is already a string, then pass it through as-is.

  if (typeof options.data === 'string') {
    output.body = options.data;
  } // Build request initializers based off of content-type
  else if (type.includes('application/x-www-form-urlencoded')) {
    const params = new URLSearchParams();

    for (const [key, value] of Object.entries(options.data || {})) {
      params.set(key, value);
    }

    output.body = params.toString();
  } else if (type.includes('multipart/form-data')) {
    const form = new FormData();

    if (options.data instanceof FormData) {
      options.data.forEach((value, key) => {
        form.append(key, value);
      });
    } else {
      for (const key of Object.keys(options.data)) {
        form.append(key, options.data[key]);
      }
    }

    output.body = form;
    const headers = new Headers(output.headers);
    headers.delete('content-type'); // content-type will be set by `window.fetch` to includy boundary

    output.headers = headers;
  } else if (type.includes('application/json') || typeof options.data === 'object') {
    output.body = JSON.stringify(options.data);
  }

  return output;
}; // WEB IMPLEMENTATION


class CapacitorHttpPluginWeb extends WebPlugin {
  /**
   * Perform an Http request given a set of options
   * @param options Options to build the HTTP request
   */
  request(options) {
    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const requestInit = buildRequestInit(options, options.webFetchExtra);
      const urlParams = buildUrlParams(options.params, options.shouldEncodeUrlParams);
      const url = urlParams ? `${options.url}?${urlParams}` : options.url;
      const response = yield fetch(url, requestInit);
      const contentType = response.headers.get('content-type') || ''; // Default to 'text' responseType so no parsing happens

      let {
        responseType = 'text'
      } = response.ok ? options : {}; // If the response content-type is json, force the response to be json

      if (contentType.includes('application/json')) {
        responseType = 'json';
      }

      let data;
      let blob;

      switch (responseType) {
        case 'arraybuffer':
        case 'blob':
          blob = yield response.blob();
          data = yield readBlobAsBase64(blob);
          break;

        case 'json':
          data = yield response.json();
          break;

        case 'document':
        case 'text':
        default:
          data = yield response.text();
      } // Convert fetch headers to Capacitor HttpHeaders


      const headers = {};
      response.headers.forEach((value, key) => {
        headers[key] = value;
      });
      return {
        data,
        headers,
        status: response.status,
        url: response.url
      };
    })();
  }
  /**
   * Perform an Http GET request given a set of options
   * @param options Options to build the HTTP request
   */


  get(options) {
    var _this5 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this5.request(Object.assign(Object.assign({}, options), {
        method: 'GET'
      }));
    })();
  }
  /**
   * Perform an Http POST request given a set of options
   * @param options Options to build the HTTP request
   */


  post(options) {
    var _this6 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this6.request(Object.assign(Object.assign({}, options), {
        method: 'POST'
      }));
    })();
  }
  /**
   * Perform an Http PUT request given a set of options
   * @param options Options to build the HTTP request
   */


  put(options) {
    var _this7 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this7.request(Object.assign(Object.assign({}, options), {
        method: 'PUT'
      }));
    })();
  }
  /**
   * Perform an Http PATCH request given a set of options
   * @param options Options to build the HTTP request
   */


  patch(options) {
    var _this8 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this8.request(Object.assign(Object.assign({}, options), {
        method: 'PATCH'
      }));
    })();
  }
  /**
   * Perform an Http DELETE request given a set of options
   * @param options Options to build the HTTP request
   */


  delete(options) {
    var _this9 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this9.request(Object.assign(Object.assign({}, options), {
        method: 'DELETE'
      }));
    })();
  }

}

const CapacitorHttp = registerPlugin('CapacitorHttp', {
  web: () => new CapacitorHttpPluginWeb()
});
/******** END HTTP PLUGIN ********/



/***/ }),

/***/ 70924:
/*!********************************************************************!*\
  !*** ./src/app/stripe-payment/stripe-payment.page.scss?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = ".header-md::after {\n  background-image: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0cmlwZS1wYXltZW50LnBhZ2Uuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcaHVzYW0lMjBwcm9qXFx6b29kb2hhU2RcXHNyY1xcYXBwXFxzdHJpcGUtcGF5bWVudFxcc3RyaXBlLXBheW1lbnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0JBQUE7QUNDSiIsImZpbGUiOiJzdHJpcGUtcGF5bWVudC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyLW1kOjphZnRlciB7IFxyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcclxuXHJcbiAgfSIsIi5oZWFkZXItbWQ6OmFmdGVyIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn0iXX0= */";

/***/ }),

/***/ 30809:
/*!********************************************************************!*\
  !*** ./src/app/stripe-payment/stripe-payment.page.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar  color=\"light\">\n    <ion-buttons slot=\"start\">\n      <ion-button fill=\"clear\" (click)=\"closeModel()\">\n        <ion-icon name=\"close-circle-outline\" color=\"dark\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content dir=\"rtl\">\n\n<ion-list class=\"ion-margin-top\">\n  <ion-item button (click)=\"paymentSheet()\"> \n    <ion-icon  slot=\"start\" name=\"card-outline\" color=\"dark\"></ion-icon> \n    <ion-label>دفع عبر البطاقة \n    </ion-label>  \n    <ion-label slot=\"end\"><ion-note >usd</ion-note> &nbsp;<ion-text >{{amount}}</ion-text> </ion-label> \n  </ion-item>\n\n    <!-- <ion-item button (click)=\"paymentSheet()\" class=\"ion-margin-top\">  \n      <ion-icon  slot=\"start\" name=\"wallet-outline\" color=\"dark\"></ion-icon>\n      <ion-label>دفع عبر المحفظة  </ion-label>\n      <ion-label slot=\"end\"><ion-note >usd</ion-note> &nbsp; <ion-text>{{amount}}</ion-text>  </ion-label> \n    </ion-item> -->\n\n  <ion-item button disabled=\"true\" (click)=\"paymentSheet()\" class=\"ion-margin-top\"> \n    <ion-icon  slot=\"start\" name=\"logo-google\" color=\"danger\"></ion-icon>\n    <ion-label>\n       دفع عبر قوقل باي  \n      </ion-label>  \n    <ion-label slot=\"end\"><ion-note  >usd</ion-note> &nbsp; <ion-text >{{amount}}</ion-text> </ion-label> \n  </ion-item>\n  <ion-item button disabled=\"true\" (click)=\"paymentSheet()\" class=\"ion-margin-top\"> \n    <ion-icon slot=\"start\" name=\"logo-apple\" ></ion-icon>\n    <ion-label>\n       دفع عبر ابل باي \n    </ion-label>  \n    <ion-label slot=\"end\"><ion-note >usd</ion-note> &nbsp; <ion-text >{{amount}}</ion-text> </ion-label> \n  </ion-item>\n  <!-- <ion-item button (click)=\"\"></ion-item> -->\n  <!-- <ion-item button (click)=\"PaymentFlowSheet()\">PaymentFlowSheet</ion-item> -->\n</ion-list>\n\n\n\n  <!-- <ion-grid text-center>\n    <ion-row>\n      <ion-col>\n        Use this Pay button in your PWA's payment page with the attached logic.\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-card class=\"welcome-card\">\n    <ion-img src=\"/assets/stripe.png\"></ion-img>\n    <ion-card-header>\n      <ion-card-subtitle>Get Started</ion-card-subtitle>\n      <ion-card-title>Stripe Sample</ion-card-title>\n      <ion-row>\n        <ion-col >Total Payment</ion-col>\n         <ion-col> <ion-item><ion-input value=\"5302 0950 4832 9498    04/28 174 \"></ion-input></ion-item></ion-col>\n        \n        <ion-col> {{currencyIcon}}{{paymentAmount}} </ion-col>\n      </ion-row>\n    </ion-card-header>\n    <ion-card-content>\n      <form action=\"/\" method=\"post\" id=\"payment-form\">\n        <div class=\"form-row\">\n          <div id=\"card-element\"> a Stripe Element will be inserted here. </div>\n          Used to display Element errors\n          <div id=\"card-errors\" role=\"alert\"></div>\n        </div>\n        <ion-button type=\"submit\" color=\"success\" expand=\"full\">Make Payment</ion-button>\n      </form>\n    </ion-card-content>\n  </ion-card> -->\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_stripe-payment_stripe-payment_page_ts.js.map