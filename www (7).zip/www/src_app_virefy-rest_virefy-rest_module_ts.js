"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_virefy-rest_virefy-rest_module_ts"],{

/***/ 5441:
/*!***********************************************************!*\
  !*** ./src/app/virefy-rest/virefy-rest-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VirefyRestPageRoutingModule": () => (/* binding */ VirefyRestPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _virefy_rest_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./virefy-rest.page */ 65298);




const routes = [
    {
        path: '',
        component: _virefy_rest_page__WEBPACK_IMPORTED_MODULE_0__.VirefyRestPage
    }
];
let VirefyRestPageRoutingModule = class VirefyRestPageRoutingModule {
};
VirefyRestPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], VirefyRestPageRoutingModule);



/***/ }),

/***/ 61709:
/*!***************************************************!*\
  !*** ./src/app/virefy-rest/virefy-rest.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VirefyRestPageModule": () => (/* binding */ VirefyRestPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _virefy_rest_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./virefy-rest-routing.module */ 5441);
/* harmony import */ var _virefy_rest_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./virefy-rest.page */ 65298);







let VirefyRestPageModule = class VirefyRestPageModule {
};
VirefyRestPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _virefy_rest_routing_module__WEBPACK_IMPORTED_MODULE_0__.VirefyRestPageRoutingModule
        ],
        declarations: [_virefy_rest_page__WEBPACK_IMPORTED_MODULE_1__.VirefyRestPage]
    })
], VirefyRestPageModule);



/***/ }),

/***/ 65298:
/*!*************************************************!*\
  !*** ./src/app/virefy-rest/virefy-rest.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VirefyRestPage": () => (/* binding */ VirefyRestPage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _virefy_rest_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./virefy-rest.page.html?ngResource */ 97576);
/* harmony import */ var _virefy_rest_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./virefy-rest.page.scss?ngResource */ 54499);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/socket-service.service */ 20905);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ 80190);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);










let VirefyRestPage = class VirefyRestPage {
  constructor(toast, formBuilder, route, storage, rout, api) {
    this.toast = toast;
    this.formBuilder = formBuilder;
    this.route = route;
    this.storage = storage;
    this.rout = rout;
    this.api = api;
    this.style = 'style2';
    this.spinner = false;
    this.spinner2 = false;
    this.isSubmitted = false;
    this.outdateCode = false;
    this.user = {
      email: ""
    };
    this.route.queryParams.subscribe(params => {
      if (params && params.digit && params.user_info) {
        this.orignalCode = JSON.parse(params.digit);
        this.USER_INFO = JSON.parse(params.user_info); //this.timerKiller() //enable time killer fuction when you want to release v1 
      }
    });
    this.ionicForm = this.formBuilder.group({
      code: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.minLength(4), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.maxLength(4), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.pattern('^[0-9]+$')]]
    });
  }

  ngOnInit() {}

  get errorControl() {
    return this.ionicForm.controls;
  }

  timerKiller() {
    setTimeout(() => {
      this.route.queryParams.subscribe(params => {
        if (params && params.type) {
          this.outdateCode = true;
        }
      });
    }, 180000);
  }

  validate() {
    this.isSubmitted = true;

    if (this.ionicForm.valid == false) {
      console.log('Please provide all the required values!');
      return false;
    } else if (this.outdateCode == true) {
      this.presentToast(' انتهت المهلة ,إضغط إعادة ارسال للحصول علي رمز جديد', 'danger');
    } else if (this.code != this.orignalCode) {
      this.presentToast(' الرمز غير صحيح', 'danger');
      return false;
    } else {
      return true;
    }
  }

  confirmAccount() {
    console.log('confirm');

    if (this.validate() == true) {
      this.spinner = true;
      let navigationExtras = {
        queryParams: {
          user_info: JSON.stringify(this.USER_INFO)
        }
      };
      this.rout.navigate(['new-password'], navigationExtras);
      this.spinner = false;
    }
  }

  sendMail() {
    this.spinner2 = true;
    this.user.email = this.USER_INFO.email;
    this.api.sendMail(this.user).subscribe(data => {
      console.log('user was created', data);
      let res = data;
      console.log('email was sent', res['digit']);
      this.orignalCode = res['digit'];
      this.presentToast('تم ارسال الرمز بنجاح', 'success');
    }, err => {
      console.log(err);
      this.spinner2 = false;
      this.handleError(err.error.error);
    }, () => {
      this.spinner2 = false;
    });
  }

  handleError(msg) {
    if (msg == "email not found") {
      this.presentToast("البريد ليس موجود ", 'danger');
      return false;
    } else if (!msg) {
      this.presentToast('حدث خطأ ما ,حاول مرة اخري', 'danger');
      return false;
    } else {
      this.presentToast("حدث خطأ ما ,الرجاء المحاولة لاحقا    ", 'danger');
      return false;
    }
  }

  inputChang(ev) {
    console.log(ev.target.value); // if(ev.target.value.length == 4 && this.validate() == true){
    //   this.confirmAccount()
    // }  
  }

  getsms() {//   let seq = (Math.floor(Math.random() * 10000) + 10000).toString().substring(1)
    //   this.api.sendsms(this.phone , seq).subscribe(data =>{
    //     console.log('sms req',data)
    //     let res = data 
    //     console.log('sms response',data)
    //     //add ionic plugin to detect the sms msg and get the use substring and procced the confirmation fuction auto
    //    // this.orignalCode = res 
    //   }, (err) => {
    //   console.log(err); 
    // })  
  }

  presentToast(msg, color) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  }

};

VirefyRestPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController
}, {
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute
}, {
  type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__.Storage
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService
}];

VirefyRestPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-virefy-rest',
  template: _virefy_rest_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_virefy_rest_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], VirefyRestPage);


/***/ }),

/***/ 54499:
/*!**************************************************************!*\
  !*** ./src/app/virefy-rest/virefy-rest.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = ".custInput {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-dark);\n  background-color: var(--ion-color-primary-contrast);\n  border-radius: 2rem;\n}\n\n.custItem {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-dark);\n  background-color: var(--ion-color-primary-contrast);\n  border-radius: 2rem;\n}\n\n.mgt10 {\n  margin-top: 10px;\n}\n\n.roundedGrid {\n  border-radius: 50px;\n  /* border-bottom-left-radius: 50px; */\n  /* border-bottom-right-radius: 50px; */\n  /* border-top-left-radius: 50px; */\n  /* border-top-right-radius: 50px; */\n  padding-left: 10px;\n  padding-right: 10px;\n}\n\n.custGridStyl2 {\n  margin-top: 10%;\n  display: grid;\n  align-items: center;\n}\n\n.header-md::after {\n  background-image: none;\n}\n\n.bordernon {\n  border: none;\n}\n\n.custInputStyle1 {\n  text-align: center;\n  font-size: 20px;\n  font-weight: bold;\n  letter-spacing: 2rem;\n}\n\n.newHeight {\n  height: 375px;\n}\n\n.custH {\n  border-bottom-style: solid;\n  padding: 10px;\n  width: 120px;\n  text-align: center;\n}\n\n.custGrid2 {\n  position: relative;\n  top: -181px;\n}\n\n.footer-md::before {\n  background-image: none;\n}\n\n.borderNone {\n  border-radius: 0px;\n}\n\n.padd13 {\n  padding-top: 13%;\n}\n\n.padd1 {\n  padding: 1%;\n}\n\n.logoSvg {\n  position: absolute;\n  top: 30%;\n  left: 50%;\n  margin-right: 50%;\n  transform: translate(-50%, -50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZpcmVmeS1yZXN0LnBhZ2Uuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcaHVzYW0lMjBwcm9qXFx6b29kb2hhU2RcXHNyY1xcYXBwXFx2aXJlZnktcmVzdFxcdmlyZWZ5LXJlc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1DQUFBO0VBQ0EsbURBQUE7RUFDQSxtQkFBQTtBQ0RKOztBRElBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1DQUFBO0VBQ0EsbURBQUE7RUFDQSxtQkFBQTtBQ0RKOztBREdBO0VBQ0ksZ0JBQUE7QUNBSjs7QURHQTtFQUNJLG1CQUFBO0VBQ0EscUNBQUE7RUFDQSxzQ0FBQTtFQUNBLGtDQUFBO0VBQ0EsbUNBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDQUo7O0FESUE7RUFFSSxlQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FDRko7O0FESUE7RUFDSSxzQkFBQTtBQ0RKOztBREtBO0VBQ0ksWUFBQTtBQ0ZKOztBREtBO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtBQ0ZKOztBRElBO0VBQ0ksYUFBQTtBQ0RKOztBREdBO0VBQ0ksMEJBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FDQUo7O0FERUE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7QUNDSjs7QURDQTtFQUNJLHNCQUFBO0FDRUo7O0FEQUE7RUFDSSxrQkFBQTtBQ0dKOztBRERBO0VBQ0ksZ0JBQUE7QUNJSjs7QURGQTtFQUNJLFdBQUE7QUNLSjs7QURIQTtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtFQUNBLGdDQUFBO0FDTUoiLCJmaWxlIjoidmlyZWZ5LXJlc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcblxyXG4uY3VzdElucHV0e1xyXG4gICAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci13aWR0aDogMC41cHg7XHJcbiAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDJyZW07XHJcbn1cclxuXHJcbi5jdXN0SXRlbXtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IDAuNXB4O1xyXG4gICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAycmVtO1xyXG59XHJcbi5tZ3QxMHtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuXHJcbi5yb3VuZGVkR3JpZHsgXHJcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgLyogYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNTBweDsgKi9cclxuICAgIC8qIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1MHB4OyAqL1xyXG4gICAgLyogYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNTBweDsgKi9cclxuICAgIC8qIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiA1MHB4OyAqL1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogMTBweDtcclxuIFxyXG4gICAgLy8gYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xyXG4gICB9XHJcbi5jdXN0R3JpZFN0eWwye1xyXG4gICAgLy8gaGVpZ2h0OiAxMDAlO1xyXG4gICAgbWFyZ2luLXRvcDogMTAlO1xyXG4gICAgZGlzcGxheTogZ3JpZDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLmhlYWRlci1tZDo6YWZ0ZXIge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTpub25lO1xyXG59XHJcblxyXG5cclxuLmJvcmRlcm5vbntcclxuICAgIGJvcmRlcjogbm9uZTtcclxufVxyXG5cclxuLmN1c3RJbnB1dFN0eWxlMXsgXHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDIwcHg7IFxyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBsZXR0ZXItc3BhY2luZzogMnJlbTtcclxufVxyXG4ubmV3SGVpZ2h0e1xyXG4gICAgaGVpZ2h0OiAzNzVweDtcclxufVxyXG4uY3VzdEh7XHJcbiAgICBib3JkZXItYm90dG9tLXN0eWxlOiBzb2xpZDtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICB3aWR0aDogMTIwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuLmN1c3RHcmlkMntcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRvcDogLTE4MXB4O1xyXG59XHJcbi5mb290ZXItbWQ6OmJlZm9yZXtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6ICBub25lO1xyXG59XHJcbi5ib3JkZXJOb25le1xyXG4gICAgYm9yZGVyLXJhZGl1czogMHB4O1xyXG59XHJcbi5wYWRkMTN7XHJcbiAgICBwYWRkaW5nLXRvcDoxMyVcclxufVxyXG4ucGFkZDF7XHJcbiAgICBwYWRkaW5nOiAxJTtcclxufVxyXG4ubG9nb1N2Z3tcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMzAlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxufSIsIi5jdXN0SW5wdXQge1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBib3JkZXItd2lkdGg6IDAuNXB4O1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xuICBib3JkZXItcmFkaXVzOiAycmVtO1xufVxuXG4uY3VzdEl0ZW0ge1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBib3JkZXItd2lkdGg6IDAuNXB4O1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xuICBib3JkZXItcmFkaXVzOiAycmVtO1xufVxuXG4ubWd0MTAge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuXG4ucm91bmRlZEdyaWQge1xuICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICAvKiBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1MHB4OyAqL1xuICAvKiBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogNTBweDsgKi9cbiAgLyogYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNTBweDsgKi9cbiAgLyogYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDUwcHg7ICovXG4gIHBhZGRpbmctbGVmdDogMTBweDtcbiAgcGFkZGluZy1yaWdodDogMTBweDtcbn1cblxuLmN1c3RHcmlkU3R5bDIge1xuICBtYXJnaW4tdG9wOiAxMCU7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5oZWFkZXItbWQ6OmFmdGVyIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn1cblxuLmJvcmRlcm5vbiB7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuLmN1c3RJbnB1dFN0eWxlMSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbGV0dGVyLXNwYWNpbmc6IDJyZW07XG59XG5cbi5uZXdIZWlnaHQge1xuICBoZWlnaHQ6IDM3NXB4O1xufVxuXG4uY3VzdEgge1xuICBib3JkZXItYm90dG9tLXN0eWxlOiBzb2xpZDtcbiAgcGFkZGluZzogMTBweDtcbiAgd2lkdGg6IDEyMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5jdXN0R3JpZDIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRvcDogLTE4MXB4O1xufVxuXG4uZm9vdGVyLW1kOjpiZWZvcmUge1xuICBiYWNrZ3JvdW5kLWltYWdlOiBub25lO1xufVxuXG4uYm9yZGVyTm9uZSB7XG4gIGJvcmRlci1yYWRpdXM6IDBweDtcbn1cblxuLnBhZGQxMyB7XG4gIHBhZGRpbmctdG9wOiAxMyU7XG59XG5cbi5wYWRkMSB7XG4gIHBhZGRpbmc6IDElO1xufVxuXG4ubG9nb1N2ZyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAzMCU7XG4gIGxlZnQ6IDUwJTtcbiAgbWFyZ2luLXJpZ2h0OiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xufSJdfQ== */";

/***/ }),

/***/ 97576:
/*!**************************************************************!*\
  !*** ./src/app/virefy-rest/virefy-rest.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header>\n  <ion-toolbar color=\"primary\" >\n    <ion-buttons slot=\"end\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n     <ion-title dir=\"rtl\"> تغيير كلمة المرور</ion-title>\n   </ion-toolbar>\n</ion-header> -->\n \n\n<ion-content dir=\"rtl\"  *ngIf=\" style=='style1'\">\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col size=\"12\" class=\"head3 newHeight ion-text-center \">\n        <svg class=\"logoSvg\" width=\"119\" height=\"119\" viewBox=\"0 0 119 119\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <circle opacity=\"0.27\" cx=\"59.5\" cy=\"59.5\" r=\"59.5\" fill=\"white\"/>\n          <path d=\"M46.6627 30.08H56.1756C56.7579 30.08 57.23 29.6079 57.23 29.0262C57.23 28.4439 56.7579 27.9718 56.1756 27.9718H46.6627C46.0804 27.9718 45.6089 28.4439 45.6089 29.0262C45.6089 29.6079 46.0804 30.08 46.6627 30.08Z\" fill=\"white\"/>\n          <path d=\"M85.0825 48.0975H71.8416V29.5921C71.8533 28.1244 71.2832 26.7115 70.2556 25.663C69.2275 24.615 67.8263 24.017 66.3586 24H36.4891C35.0203 24.0152 33.6174 24.6126 32.5886 25.6612C31.5592 26.7092 30.988 28.1232 31.0002 29.5921V90.3979C30.988 91.8668 31.5592 93.2807 32.5886 94.3288C33.6173 95.3774 35.0203 95.9748 36.4891 95.99H66.3586C67.8275 95.9748 69.2304 95.3774 70.2598 94.3288C71.2886 93.2808 71.8598 91.8668 71.8482 90.3979V73.7368H85.2371H85.2365C87.5132 73.7315 89.6943 72.8229 91.3013 71.2106C92.9077 69.5978 93.8082 67.4133 93.8046 65.1366V56.7807C93.793 54.4749 92.8691 52.2669 91.2347 50.6402C89.6004 49.0129 87.3885 48.099 85.0827 48.0972L85.0825 48.0975ZM36.4897 26.1079H66.3592C67.2679 26.1248 68.1329 26.5008 68.7653 27.1536C69.3977 27.8064 69.7457 28.683 69.734 29.5917V32.4775H33.0962V29.5917C33.084 28.6796 33.4349 27.8 34.0714 27.1466C34.7078 26.4938 35.5781 26.1196 36.4897 26.1079L36.4897 26.1079ZM69.733 90.3845H69.7335C69.7452 91.2932 69.3972 92.1698 68.7648 92.8226C68.1324 93.4755 67.2675 93.8514 66.3588 93.8683H36.4893C35.5806 93.8514 34.7156 93.4755 34.0832 92.8226C33.4514 92.1698 33.1028 91.2932 33.1151 90.3845V34.5862H69.7529V48.0842H51.8965C49.8729 48.086 47.9331 48.8915 46.5032 50.323C45.0734 51.7551 44.2714 53.6966 44.2732 55.7203V65.1364C44.2686 67.3694 45.1341 69.5155 46.6851 71.1212C48.2366 72.7265 50.3525 73.6649 52.5842 73.7365C53.6386 76.6421 50.9068 78.7759 50.7907 78.8785C50.4357 79.1449 50.2854 79.6054 50.4148 80.0297C50.5442 80.454 50.9259 80.7524 51.3689 80.7752H51.8894C53.9976 80.7752 61.8971 80.3124 67.3151 73.7371L69.7328 73.7365L69.733 90.3845ZM91.6971 65.1361C91.7024 66.8551 91.0233 68.5057 89.8103 69.7232C88.5973 70.9408 86.9496 71.6263 85.2308 71.6281H66.8418C66.5177 71.6287 66.2123 71.7779 66.013 72.0332C62.2722 76.8028 56.9501 78.1521 53.8906 78.5252H53.89C54.5148 77.6002 54.875 76.5218 54.9316 75.4073C54.9881 74.2929 54.7392 73.1838 54.2118 72.2005C54.0299 71.8531 53.6714 71.6351 53.2798 71.6345H52.8618C51.1395 71.6362 49.4877 70.9514 48.2717 69.732C47.0559 68.5121 46.3757 66.8585 46.3827 65.1361V55.72C46.3844 54.2576 46.9662 52.8559 47.9996 51.8218C49.0336 50.7884 50.4353 50.2067 51.8978 50.2049H85.0843C86.8375 50.2067 88.5192 50.9038 89.7588 52.1441C90.9992 53.3839 91.6962 55.0654 91.698 56.8187L91.6971 65.1361Z\" fill=\"white\"/>\n          <path d=\"M57.3076 58.9393H56.7679L57.1537 58.5535L57.1531 58.5541C57.5652 58.142 57.5652 57.4746 57.1531 57.0625C56.7416 56.651 56.0737 56.651 55.6622 57.0625L55.2763 57.4484V56.9086C55.2763 56.3264 54.8048 55.8542 54.2225 55.8542C53.6402 55.8542 53.1681 56.3264 53.1681 56.9086V57.4227L52.7823 57.0369H52.7828C52.3708 56.6254 51.7034 56.6254 51.2913 57.0369C50.8798 57.449 50.8798 58.1164 51.2913 58.5284L51.6771 58.9143H51.1374L51.1368 58.9137C50.5551 58.9137 50.083 59.3858 50.083 59.9681C50.083 60.5504 50.5551 61.0219 51.1368 61.0219H51.6766L51.2907 61.4078H51.2913C50.8722 61.814 50.8623 62.4831 51.2691 62.9023C51.6754 63.3214 52.3445 63.3313 52.7631 62.925L53.1489 62.5392V63.0789C53.1489 63.6612 53.621 64.1333 54.2033 64.1333C54.785 64.1333 55.2571 63.6612 55.2571 63.0789V62.5648L55.643 62.9507C56.0545 63.3622 56.7224 63.3622 57.1339 62.9507C57.546 62.5386 57.546 61.8712 57.1339 61.4591L56.7481 61.0733H57.2878L57.2884 61.0738C57.8707 61.0738 58.3422 60.6017 58.3422 60.0194C58.3422 59.4372 57.8707 58.9656 57.2884 58.9656L57.3076 58.9393Z\" fill=\"white\"/>\n          <path d=\"M67.7471 58.9393H67.2074L67.5933 58.5535L67.5927 58.5541C68.0048 58.142 68.0048 57.4746 67.5927 57.0625C67.1812 56.651 66.5132 56.651 66.1017 57.0625L65.7159 57.4484V56.9086C65.7159 56.3264 65.2443 55.8542 64.662 55.8542C64.0798 55.8542 63.6076 56.3264 63.6076 56.9086V57.4227L63.2218 57.0369H63.2224C62.8103 56.6254 62.1429 56.6254 61.7308 57.0369C61.3193 57.449 61.3193 58.1164 61.7308 58.5284L62.1167 58.9143L61.5699 58.9137C60.9882 58.9137 60.5161 59.3858 60.5161 59.9681C60.5161 60.5504 60.9882 61.0219 61.5699 61.0219H62.1097L61.7238 61.4078H61.7244C61.3129 61.8198 61.3129 62.4872 61.7244 62.8993C62.1365 63.3108 62.8039 63.3108 63.2154 62.8993L63.6012 62.5135V63.0532C63.6012 63.6355 64.0733 64.1076 64.6556 64.1076C65.2379 64.1076 65.7094 63.6355 65.7094 63.0532V62.5648L66.0953 62.9506C66.5068 63.3621 67.1748 63.3621 67.5863 62.9506C67.9983 62.5385 67.9983 61.8712 67.5863 61.4591L67.2004 61.0732H67.7401L67.7407 61.0738C68.323 61.0738 68.7951 60.6017 68.7951 60.0194C68.7951 59.4371 68.323 58.9656 67.7407 58.9656L67.7471 58.9393Z\" fill=\"white\"/>\n          <path d=\"M77.8833 58.9393H77.3436L77.7294 58.5535L77.7288 58.5541C78.1409 58.142 78.1409 57.4746 77.7288 57.0625C77.3173 56.651 76.6494 56.651 76.2379 57.0625L75.852 57.4484V56.9086C75.852 56.3264 75.3799 55.8542 74.7976 55.8542C74.2159 55.8542 73.7438 56.3264 73.7438 56.9086V57.4227L73.3579 57.0369C72.9464 56.6254 72.2785 56.6254 71.867 57.0369C71.4549 57.449 71.4549 58.1164 71.867 58.5284L72.2528 58.9143H71.7131L71.7125 58.9137C71.1302 58.9137 70.6587 59.3858 70.6587 59.9681C70.6587 60.5504 71.1302 61.0219 71.7125 61.0219H72.2522L71.8664 61.4078H71.867C71.4479 61.8123 71.4362 62.4802 71.8413 62.8993C72.2458 63.3178 72.9132 63.3295 73.3323 62.925L73.7181 62.5391V63.0788C73.7181 63.6611 74.1897 64.1332 74.772 64.1332C75.3542 64.1332 75.8264 63.6611 75.8264 63.0788V62.5648L76.2122 62.9506H76.2116C76.6237 63.3621 77.2911 63.3621 77.7032 62.9506C78.1147 62.5385 78.1147 61.8711 77.7032 61.4591L77.3173 61.0732H77.8571L77.8576 61.0738C78.4393 61.0738 78.9115 60.6017 78.9115 60.0194C78.9115 59.4371 78.4393 58.9656 77.8576 58.9656L77.8833 58.9393Z\" fill=\"white\"/>\n          <path d=\"M87.7295 58.9393H87.1898L87.5756 58.5535L87.575 58.5541C87.9871 58.142 87.9871 57.4746 87.575 57.0625C87.1635 56.651 86.4961 56.651 86.0841 57.0625L85.6982 57.4484V56.9086C85.6982 56.3264 85.2267 55.8542 84.6444 55.8542C84.0621 55.8542 83.59 56.3264 83.59 56.9086V57.4227L83.2041 57.0369H83.2047C82.7856 56.6184 82.1066 56.6184 81.6875 57.0369C81.2684 57.456 81.2684 58.135 81.6875 58.5541L82.0734 58.9399L81.5593 58.9393C80.977 58.9393 80.5049 59.4115 80.5049 59.9937C80.5049 60.576 80.977 61.0481 81.5593 61.0481H82.099L81.7132 61.434V61.4334C81.3017 61.8455 81.3017 62.5129 81.7132 62.925C82.1252 63.3365 82.7926 63.3365 83.2047 62.925L83.6156 62.5648V63.1045C83.6156 63.6868 84.0878 64.1589 84.67 64.1589C85.2523 64.1589 85.7239 63.6868 85.7239 63.1045V62.5648L86.1097 62.9506C86.5218 63.3621 87.1892 63.3621 87.6013 62.9506C88.0128 62.5385 88.0128 61.8711 87.6013 61.459L87.2154 61.0732H87.7551V61.0738C88.3374 61.0738 88.8095 60.6017 88.8095 60.0194C88.8095 59.4371 88.3374 58.9656 87.7551 58.9656L87.7295 58.9393Z\" fill=\"white\"/>\n          <path d=\"M51.4201 83.2043C50.1157 83.2043 48.8648 83.7225 47.9427 84.6446C47.0206 85.5667 46.5024 86.8174 46.5024 88.1214C46.5024 89.4259 47.0206 90.6761 47.9427 91.5982C48.8648 92.5209 50.1155 93.0385 51.4201 93.0385C52.724 93.0385 53.9748 92.5209 54.8969 91.5982C55.819 90.6761 56.3372 89.4258 56.3372 88.1214C56.3354 86.8181 55.8167 85.5685 54.8952 84.6464C53.9731 83.7249 52.7234 83.2061 51.4201 83.2044L51.4201 83.2043ZM51.4201 90.9173C50.6752 90.9173 49.9606 90.6218 49.4338 90.0949C48.9069 89.568 48.6114 88.8534 48.6114 88.1086C48.6114 87.3637 48.9069 86.6491 49.4338 86.1227C49.9607 85.5958 50.6753 85.2997 51.4201 85.2997C52.165 85.2997 52.8796 85.5958 53.406 86.1227C53.9329 86.649 54.229 87.3636 54.229 88.1086C54.2307 88.8546 53.9352 89.571 53.4083 90.0991C52.8814 90.6272 52.1662 90.9238 51.4202 90.9238L51.4201 90.9173Z\" fill=\"white\"/>\n          </svg>   \n     </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid class=\"custGrid2 ion-margin-bottom\">\n     <ion-row class=\"ion-justify-content-center\">\n    <ion-col size=\"10\" >\n     <ion-card class=\"bordernon w100\" >\n      <ion-card-header>\n        <ion-card-title class=\"ion-text-center\">\n         <h3 ><b> رمز التأكيد</b></h3> \n        </ion-card-title>\n        <ion-card-subtitle class=\"ion-text-center\">\n           قمنا بإرسال بريد اليك         \n        </ion-card-subtitle>\n        <ion-card-subtitle class=\"ion-text-center\">\n         الرجاء ادخال رمز التأكيد المكون من 4 ارقام         \n       </ion-card-subtitle>\n        <ion-card-subtitle class=\"ion-text-center\">\n          <ion-text *ngIf=\"orignalCode\">  {{orignalCode}} </ion-text>\n        </ion-card-subtitle>\n      </ion-card-header>\n       <ion-grid>\n        <form [formGroup]=\"ionicForm\" (ngSubmit)=\"confirmAccount()\" novalidate>\n        <ion-row class=\"ion-padding-start\">\n          <ion-label>أدخل رمز التأكيد</ion-label> \n        </ion-row>\n        <ion-row class=\"ion-margin\" *ngIf=\"orignalCode\"> \n          <ion-col> \n            <ion-item>\n              <ion-input class=\"custInput\" formControlName=\"code\" [(ngModel)]=\"code\" (ionChange)=\"inputChang($event)\"></ion-input>\n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.code.errors?.pattern\">ادخل ارقام فقط  </ion-note> \n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.code.errors?.required\">رمز التأكيد مطلوب </ion-note>\n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && (errorControl.code.errors?.minlength || errorControl.code.errors?.maxlength)\">يجب ان يتكون من4 أرقام </ion-note> \n            </ion-item> \n          </ion-col> \n        </ion-row> \n       \n        <ion-row class=\"ion-margin\" >\n          <ion-col size=\"12\">\n            <ion-item color=\"primary\" button  [disabled]=\"spinner == true\"  (click)=\"confirmAccount()\">\n              <ion-label class=\"ion-text-center\">إرسال</ion-label> \n              <ion-spinner name=\"lines\" color=\"light\" *ngIf=\"spinner == true\"></ion-spinner> \n\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"ion-justify-content-start\">\n          <ion-button [disabled]=\"spinner2 == true\" fill=\"clear\"(click)=\"sendMail()\"> \n            <ion-label><ion-text color=\"primary\"><b>إعادة إرسال الرمز</b></ion-text> <ion-spinner name=\"lines\" color=\"light\" *ngIf=\"spinner2 == true\"></ion-spinner> </ion-label>\n          </ion-button>\n        </ion-row>  \n         </form>\n       </ion-grid> \n    \n      </ion-card>\n    </ion-col>\n    </ion-row>\n  </ion-grid>\n \n</ion-content>\n<ion-content dir=\"rtl\"  *ngIf=\" style=='style2'\">\n  \n  <ion-grid class=\"custGridStyl2 ion-margin-bottom\">\n\n    <ion-row>\n      <ion-col size=\"12\" class=\" ion-text-center \">\n        <svg  width=\"119\" height=\"119\" viewBox=\"0 0 119 119\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <circle opacity=\"0.27\" cx=\"59.5\" cy=\"59.5\" r=\"59.5\" fill=\"black\"/>\n          <path d=\"M46.6627 30.08H56.1756C56.7579 30.08 57.23 29.6079 57.23 29.0262C57.23 28.4439 56.7579 27.9718 56.1756 27.9718H46.6627C46.0804 27.9718 45.6089 28.4439 45.6089 29.0262C45.6089 29.6079 46.0804 30.08 46.6627 30.08Z\" fill=\"white\"/>\n          <path d=\"M85.0825 48.0975H71.8416V29.5921C71.8533 28.1244 71.2832 26.7115 70.2556 25.663C69.2275 24.615 67.8263 24.017 66.3586 24H36.4891C35.0203 24.0152 33.6174 24.6126 32.5886 25.6612C31.5592 26.7092 30.988 28.1232 31.0002 29.5921V90.3979C30.988 91.8668 31.5592 93.2807 32.5886 94.3288C33.6173 95.3774 35.0203 95.9748 36.4891 95.99H66.3586C67.8275 95.9748 69.2304 95.3774 70.2598 94.3288C71.2886 93.2808 71.8598 91.8668 71.8482 90.3979V73.7368H85.2371H85.2365C87.5132 73.7315 89.6943 72.8229 91.3013 71.2106C92.9077 69.5978 93.8082 67.4133 93.8046 65.1366V56.7807C93.793 54.4749 92.8691 52.2669 91.2347 50.6402C89.6004 49.0129 87.3885 48.099 85.0827 48.0972L85.0825 48.0975ZM36.4897 26.1079H66.3592C67.2679 26.1248 68.1329 26.5008 68.7653 27.1536C69.3977 27.8064 69.7457 28.683 69.734 29.5917V32.4775H33.0962V29.5917C33.084 28.6796 33.4349 27.8 34.0714 27.1466C34.7078 26.4938 35.5781 26.1196 36.4897 26.1079L36.4897 26.1079ZM69.733 90.3845H69.7335C69.7452 91.2932 69.3972 92.1698 68.7648 92.8226C68.1324 93.4755 67.2675 93.8514 66.3588 93.8683H36.4893C35.5806 93.8514 34.7156 93.4755 34.0832 92.8226C33.4514 92.1698 33.1028 91.2932 33.1151 90.3845V34.5862H69.7529V48.0842H51.8965C49.8729 48.086 47.9331 48.8915 46.5032 50.323C45.0734 51.7551 44.2714 53.6966 44.2732 55.7203V65.1364C44.2686 67.3694 45.1341 69.5155 46.6851 71.1212C48.2366 72.7265 50.3525 73.6649 52.5842 73.7365C53.6386 76.6421 50.9068 78.7759 50.7907 78.8785C50.4357 79.1449 50.2854 79.6054 50.4148 80.0297C50.5442 80.454 50.9259 80.7524 51.3689 80.7752H51.8894C53.9976 80.7752 61.8971 80.3124 67.3151 73.7371L69.7328 73.7365L69.733 90.3845ZM91.6971 65.1361C91.7024 66.8551 91.0233 68.5057 89.8103 69.7232C88.5973 70.9408 86.9496 71.6263 85.2308 71.6281H66.8418C66.5177 71.6287 66.2123 71.7779 66.013 72.0332C62.2722 76.8028 56.9501 78.1521 53.8906 78.5252H53.89C54.5148 77.6002 54.875 76.5218 54.9316 75.4073C54.9881 74.2929 54.7392 73.1838 54.2118 72.2005C54.0299 71.8531 53.6714 71.6351 53.2798 71.6345H52.8618C51.1395 71.6362 49.4877 70.9514 48.2717 69.732C47.0559 68.5121 46.3757 66.8585 46.3827 65.1361V55.72C46.3844 54.2576 46.9662 52.8559 47.9996 51.8218C49.0336 50.7884 50.4353 50.2067 51.8978 50.2049H85.0843C86.8375 50.2067 88.5192 50.9038 89.7588 52.1441C90.9992 53.3839 91.6962 55.0654 91.698 56.8187L91.6971 65.1361Z\" fill=\"white\"/>\n          <path d=\"M57.3076 58.9393H56.7679L57.1537 58.5535L57.1531 58.5541C57.5652 58.142 57.5652 57.4746 57.1531 57.0625C56.7416 56.651 56.0737 56.651 55.6622 57.0625L55.2763 57.4484V56.9086C55.2763 56.3264 54.8048 55.8542 54.2225 55.8542C53.6402 55.8542 53.1681 56.3264 53.1681 56.9086V57.4227L52.7823 57.0369H52.7828C52.3708 56.6254 51.7034 56.6254 51.2913 57.0369C50.8798 57.449 50.8798 58.1164 51.2913 58.5284L51.6771 58.9143H51.1374L51.1368 58.9137C50.5551 58.9137 50.083 59.3858 50.083 59.9681C50.083 60.5504 50.5551 61.0219 51.1368 61.0219H51.6766L51.2907 61.4078H51.2913C50.8722 61.814 50.8623 62.4831 51.2691 62.9023C51.6754 63.3214 52.3445 63.3313 52.7631 62.925L53.1489 62.5392V63.0789C53.1489 63.6612 53.621 64.1333 54.2033 64.1333C54.785 64.1333 55.2571 63.6612 55.2571 63.0789V62.5648L55.643 62.9507C56.0545 63.3622 56.7224 63.3622 57.1339 62.9507C57.546 62.5386 57.546 61.8712 57.1339 61.4591L56.7481 61.0733H57.2878L57.2884 61.0738C57.8707 61.0738 58.3422 60.6017 58.3422 60.0194C58.3422 59.4372 57.8707 58.9656 57.2884 58.9656L57.3076 58.9393Z\" fill=\"white\"/>\n          <path d=\"M67.7471 58.9393H67.2074L67.5933 58.5535L67.5927 58.5541C68.0048 58.142 68.0048 57.4746 67.5927 57.0625C67.1812 56.651 66.5132 56.651 66.1017 57.0625L65.7159 57.4484V56.9086C65.7159 56.3264 65.2443 55.8542 64.662 55.8542C64.0798 55.8542 63.6076 56.3264 63.6076 56.9086V57.4227L63.2218 57.0369H63.2224C62.8103 56.6254 62.1429 56.6254 61.7308 57.0369C61.3193 57.449 61.3193 58.1164 61.7308 58.5284L62.1167 58.9143L61.5699 58.9137C60.9882 58.9137 60.5161 59.3858 60.5161 59.9681C60.5161 60.5504 60.9882 61.0219 61.5699 61.0219H62.1097L61.7238 61.4078H61.7244C61.3129 61.8198 61.3129 62.4872 61.7244 62.8993C62.1365 63.3108 62.8039 63.3108 63.2154 62.8993L63.6012 62.5135V63.0532C63.6012 63.6355 64.0733 64.1076 64.6556 64.1076C65.2379 64.1076 65.7094 63.6355 65.7094 63.0532V62.5648L66.0953 62.9506C66.5068 63.3621 67.1748 63.3621 67.5863 62.9506C67.9983 62.5385 67.9983 61.8712 67.5863 61.4591L67.2004 61.0732H67.7401L67.7407 61.0738C68.323 61.0738 68.7951 60.6017 68.7951 60.0194C68.7951 59.4371 68.323 58.9656 67.7407 58.9656L67.7471 58.9393Z\" fill=\"white\"/>\n          <path d=\"M77.8833 58.9393H77.3436L77.7294 58.5535L77.7288 58.5541C78.1409 58.142 78.1409 57.4746 77.7288 57.0625C77.3173 56.651 76.6494 56.651 76.2379 57.0625L75.852 57.4484V56.9086C75.852 56.3264 75.3799 55.8542 74.7976 55.8542C74.2159 55.8542 73.7438 56.3264 73.7438 56.9086V57.4227L73.3579 57.0369C72.9464 56.6254 72.2785 56.6254 71.867 57.0369C71.4549 57.449 71.4549 58.1164 71.867 58.5284L72.2528 58.9143H71.7131L71.7125 58.9137C71.1302 58.9137 70.6587 59.3858 70.6587 59.9681C70.6587 60.5504 71.1302 61.0219 71.7125 61.0219H72.2522L71.8664 61.4078H71.867C71.4479 61.8123 71.4362 62.4802 71.8413 62.8993C72.2458 63.3178 72.9132 63.3295 73.3323 62.925L73.7181 62.5391V63.0788C73.7181 63.6611 74.1897 64.1332 74.772 64.1332C75.3542 64.1332 75.8264 63.6611 75.8264 63.0788V62.5648L76.2122 62.9506H76.2116C76.6237 63.3621 77.2911 63.3621 77.7032 62.9506C78.1147 62.5385 78.1147 61.8711 77.7032 61.4591L77.3173 61.0732H77.8571L77.8576 61.0738C78.4393 61.0738 78.9115 60.6017 78.9115 60.0194C78.9115 59.4371 78.4393 58.9656 77.8576 58.9656L77.8833 58.9393Z\" fill=\"white\"/>\n          <path d=\"M87.7295 58.9393H87.1898L87.5756 58.5535L87.575 58.5541C87.9871 58.142 87.9871 57.4746 87.575 57.0625C87.1635 56.651 86.4961 56.651 86.0841 57.0625L85.6982 57.4484V56.9086C85.6982 56.3264 85.2267 55.8542 84.6444 55.8542C84.0621 55.8542 83.59 56.3264 83.59 56.9086V57.4227L83.2041 57.0369H83.2047C82.7856 56.6184 82.1066 56.6184 81.6875 57.0369C81.2684 57.456 81.2684 58.135 81.6875 58.5541L82.0734 58.9399L81.5593 58.9393C80.977 58.9393 80.5049 59.4115 80.5049 59.9937C80.5049 60.576 80.977 61.0481 81.5593 61.0481H82.099L81.7132 61.434V61.4334C81.3017 61.8455 81.3017 62.5129 81.7132 62.925C82.1252 63.3365 82.7926 63.3365 83.2047 62.925L83.6156 62.5648V63.1045C83.6156 63.6868 84.0878 64.1589 84.67 64.1589C85.2523 64.1589 85.7239 63.6868 85.7239 63.1045V62.5648L86.1097 62.9506C86.5218 63.3621 87.1892 63.3621 87.6013 62.9506C88.0128 62.5385 88.0128 61.8711 87.6013 61.459L87.2154 61.0732H87.7551V61.0738C88.3374 61.0738 88.8095 60.6017 88.8095 60.0194C88.8095 59.4371 88.3374 58.9656 87.7551 58.9656L87.7295 58.9393Z\" fill=\"white\"/>\n          <path d=\"M51.4201 83.2043C50.1157 83.2043 48.8648 83.7225 47.9427 84.6446C47.0206 85.5667 46.5024 86.8174 46.5024 88.1214C46.5024 89.4259 47.0206 90.6761 47.9427 91.5982C48.8648 92.5209 50.1155 93.0385 51.4201 93.0385C52.724 93.0385 53.9748 92.5209 54.8969 91.5982C55.819 90.6761 56.3372 89.4258 56.3372 88.1214C56.3354 86.8181 55.8167 85.5685 54.8952 84.6464C53.9731 83.7249 52.7234 83.2061 51.4201 83.2044L51.4201 83.2043ZM51.4201 90.9173C50.6752 90.9173 49.9606 90.6218 49.4338 90.0949C48.9069 89.568 48.6114 88.8534 48.6114 88.1086C48.6114 87.3637 48.9069 86.6491 49.4338 86.1227C49.9607 85.5958 50.6753 85.2997 51.4201 85.2997C52.165 85.2997 52.8796 85.5958 53.406 86.1227C53.9329 86.649 54.229 87.3636 54.229 88.1086C54.2307 88.8546 53.9352 89.571 53.4083 90.0991C52.8814 90.6272 52.1662 90.9238 51.4202 90.9238L51.4201 90.9173Z\" fill=\"white\"/>\n          </svg>   \n     </ion-col>\n    </ion-row>\n\n  <ion-row class=\"ion-justify-content-center\">\n    <ion-col size=\"11\" >\n     <ion-card class=\" roundedGrid w100\" >\n      <ion-card-header>\n        <ion-card-title class=\"ion-text-center\">\n         <h3 ><b> رمز التأكيد</b></h3> \n        </ion-card-title>\n        <ion-card-subtitle class=\"ion-text-center\">\n           قمنا بإرسال بريد اليك         \n        </ion-card-subtitle>\n        <ion-card-subtitle class=\"ion-text-center\">\n         الرجاء ادخال رمز التأكيد المكون من 4 ارقام         \n       </ion-card-subtitle>\n        <ion-card-subtitle class=\"ion-text-center\">\n          <ion-text *ngIf=\"orignalCode\">  {{orignalCode}} </ion-text>\n        </ion-card-subtitle>\n      </ion-card-header>\n       <ion-grid>\n        <form [formGroup]=\"ionicForm\" (ngSubmit)=\"confirmAccount()\" novalidate>\n        \n        <ion-row class=\"ion-margin\" *ngIf=\"orignalCode\"> \n          <ion-col> \n            <ion-item class=\"custInput\">\n              <ion-input placeholder=\"ادخل رمز التأكيد هنا\"  formControlName=\"code\" [(ngModel)]=\"code\" (ionChange)=\"inputChang($event)\"></ion-input>\n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.code.errors?.pattern\">ادخل ارقام فقط  </ion-note> \n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.code.errors?.required\">رمز التأكيد مطلوب </ion-note>\n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && (errorControl.code.errors?.minlength || errorControl.code.errors?.maxlength)\">يجب ان يتكون من4 أرقام </ion-note> \n            </ion-item> \n          </ion-col> \n        </ion-row> \n       \n        <ion-row class=\"ion-margin\" >\n          <ion-col size=\"12\">\n            <ion-item   class=\"custItem\" color=\"dark\"  button  [disabled]=\"spinner == true\"  (click)=\"confirmAccount()\">\n              <ion-label class=\"ion-text-center\">إرسال</ion-label> \n              <ion-spinner name=\"lines\" color=\"light\" *ngIf=\"spinner == true\"></ion-spinner> \n\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-row class=\"ion-justify-content-start\">\n          <ion-button [disabled]=\"spinner2 == true\" fill=\"clear\"(click)=\"sendMail()\"> \n            <ion-label><ion-text color=\"primary\"><b>إعادة إرسال الرمز</b></ion-text> <ion-spinner name=\"lines\" color=\"light\" *ngIf=\"spinner2 == true\"></ion-spinner> </ion-label>\n          </ion-button>\n        </ion-row>  \n         </form>\n       </ion-grid> \n    \n      </ion-card>\n    </ion-col>\n    </ion-row>\n  </ion-grid>\n \n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_virefy-rest_virefy-rest_module_ts.js.map