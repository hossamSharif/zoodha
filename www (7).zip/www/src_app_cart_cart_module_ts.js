"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_cart_cart_module_ts"],{

/***/ 63951:
/*!*********************************************!*\
  !*** ./src/app/cart/cart-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartPageRoutingModule": () => (/* binding */ CartPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _cart_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cart.page */ 34612);




const routes = [
    {
        path: '',
        component: _cart_page__WEBPACK_IMPORTED_MODULE_0__.CartPage
    }
];
let CartPageRoutingModule = class CartPageRoutingModule {
};
CartPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CartPageRoutingModule);



/***/ }),

/***/ 12943:
/*!*************************************!*\
  !*** ./src/app/cart/cart.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartPageModule": () => (/* binding */ CartPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _cart_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cart-routing.module */ 63951);
/* harmony import */ var _cart_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cart.page */ 34612);







let CartPageModule = class CartPageModule {
};
CartPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _cart_routing_module__WEBPACK_IMPORTED_MODULE_0__.CartPageRoutingModule
        ],
        declarations: [_cart_page__WEBPACK_IMPORTED_MODULE_1__.CartPage]
    })
], CartPageModule);



/***/ }),

/***/ 34612:
/*!***********************************!*\
  !*** ./src/app/cart/cart.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartPage": () => (/* binding */ CartPage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _cart_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cart.page.html?ngResource */ 73098);
/* harmony import */ var _cart_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./cart.page.scss?ngResource */ 24068);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/storage */ 80190);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/socket-service.service */ 20905);










let CartPage = class CartPage {
  constructor(api, socket, route, storage, loadingController, toast, actionSheetCtl, datePipe, rout, modalController) {
    this.api = api;
    this.socket = socket;
    this.route = route;
    this.storage = storage;
    this.loadingController = loadingController;
    this.toast = toast;
    this.actionSheetCtl = actionSheetCtl;
    this.datePipe = datePipe;
    this.rout = rout;
    this.modalController = modalController;
    this.errorLoad = false;
    this.orders = undefined;
    this.showEmpty = false;
    this.showSkelton = false;
    this.higtPayedPrie = 0;
  }

  ngOnInit() {}

  ionViewDidEnter() {
    this.storage.get('user_info').then(response => {
      if (response) {
        this.USER_INFO = response.user;
        console.log('kkkkkkkkkk', this.USER_INFO);
        this.getOrders();
      }
    });
  }

  reload() {
    this.errorLoad = false;
    this.orders = undefined;
    this.getOrders();
  }

  getOrders() {
    this.showSkelton = true;
    this.api.getUserOrder(this.USER_INFO._id).subscribe(data => {
      console.log(data);
      let res = data['orders'];

      if (res.length == 0) {
        this.showEmpty;
      } else {
        this.orders = res;
        this.preparOrders();
      } //   this.mzd = data['auction'][0][0]
      //   this.users = data['auction'][1]
      //   console.log('im here baby',this.mzd , 'users',this.users)
      //  this.prepareAuc()

    }, err => {
      this.errorLoad = true;
      console.log(err);
    }, () => {
      this.showSkelton = false;
    });
  }

  preparOrders() {
    this.orders.forEach(element => {
      let arr = element['auctions'][0].logs.sort((a, b) => a.pay > b.pay ? -1 : 1);
      let winer = arr;
      element.higtPayedPrie = winer[0].pay;
    });
  }

  orderDetailsPage(orderId) {
    let navigationExtras = {
      queryParams: {
        id: JSON.stringify(orderId),
        user_info: JSON.stringify(this.USER_INFO)
      }
    };
    this.rout.navigate(['order-details'], navigationExtras);
  } // async presentModal(id?, status?) { 
  //   const modal = await this.modalController.create({
  //     component: OrderDetailsPage ,
  //     componentProps: {
  //       "item":"",
  //       "status": ""
  //     }
  //   });
  //   modal.onDidDismiss().then((dataReturned) => {
  //     if (dataReturned !== null) {
  //       console.log(dataReturned )
  //       this.doAfterDissmiss(dataReturned)
  //     }
  //   });
  //   return await modal.present(); 
  // }


  doAfterDissmiss(dataReturned) {
    this.presentToast("تم سداد المفاتورة  بنجاح , يمكنك متابعة طلبك ", 'success'); // this.rout.navigate(['cart']);  
  }

  presentLoadingWithOptions(msg) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this.loadingController.create({
        spinner: 'bubbles',
        mode: 'ios',
        duration: 5000,
        message: msg,
        translucent: true,
        // cssClass: 'custom-class custom-loading',
        backdropDismiss: false
      });
      yield loading.present();
      const {
        role,
        data
      } = yield loading.onDidDismiss();
      console.log('Loading dismissed with role:', role);
    })();
  }

  presentToast(msg, color) {
    var _this2 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this2.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  }

};

CartPage.ctorParameters = () => [{
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_4__.SocketServiceService
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_4__.SocketServiceService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute
}, {
  type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__.Storage
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ActionSheetController
}, {
  type: _angular_common__WEBPACK_IMPORTED_MODULE_7__.DatePipe
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController
}];

CartPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-cart',
  template: _cart_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_cart_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], CartPage);


/***/ }),

/***/ 24068:
/*!************************************************!*\
  !*** ./src/app/cart/cart.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = ".radus5 {\n  border-radius: 4%;\n}\n\n.borderlight {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-light-shade);\n}\n\n.badge {\n  padding-top: 4px;\n  padding-bottom: 5px;\n  padding-right: 13px;\n  padding-left: 14px;\n}\n\n.mgt10 {\n  margin-top: 10px;\n}\n\n.padding5 {\n  padding-top: 5px;\n}\n\n--ion-padding {\n  padding-left: unset;\n  padding-right: unset;\n  padding-inline-start: var(--ion-padding, 9px);\n  padding-inline-end: var(--ion-padding, 9px);\n}\n\n.timercol {\n  background-color: var(--ion-color-light-tint);\n  border-bottom-left-radius: 9px;\n  border-bottom-right-radius: 9px;\n}\n\n.htext {\n  text-align: center;\n  margin-top: 3px;\n  margin-bottom: 1px;\n}\n\n.hnom {\n  text-align: center;\n  margin-top: 1px;\n}\n\n.img {\n  height: 100%;\n}\n\n.custDiv {\n  border-width: 0.2px;\n  border-color: var(--ion-color-light-tint);\n  border-style: solid;\n  border-bottom: none;\n  text-align: center;\n  padding-top: 2px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcnQucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFxodXNhbSUyMHByb2pcXHpvb2RvaGFTZFxcc3JjXFxhcHBcXGNhcnRcXGNhcnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQUE7QUNDSjs7QURFQTtFQUNJLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQ0FBQTtBQ0NKOztBREVBO0VBQ0ksZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURFQTtFQUNJLGdCQUFBO0FDQ0o7O0FERUE7RUFDQSxnQkFBQTtBQ0NBOztBRENBO0VBQ0ksbUJBQUE7RUFDQSxvQkFBQTtFQUNBLDZDQUFBO0VBQ0EsMkNBQUE7QUNFSjs7QURDQTtFQUNJLDZDQUFBO0VBQ0EsOEJBQUE7RUFDQSwrQkFBQTtBQ0VKOztBREFBO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUNHSjs7QUREQTtFQUNJLGtCQUFBO0VBQ0EsZUFBQTtBQ0lKOztBRERBO0VBQ0ksWUFBQTtBQ0lKOztBREZBO0VBQ0ksbUJBQUE7RUFDQSx5Q0FBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDS0oiLCJmaWxlIjoiY2FydC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmFkdXM1e1xyXG4gICAgYm9yZGVyLXJhZGl1czogNCU7XHJcbn1cclxuXHJcbi5ib3JkZXJsaWdodHtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IC41cHg7XHJcbiAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XHJcbn1cclxuXHJcbi5iYWRnZXtcclxuICAgIHBhZGRpbmctdG9wOiA0cHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNXB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogMTNweDtcclxuICAgIHBhZGRpbmctbGVmdDogMTRweDtcclxufVxyXG4gXHJcbi5tZ3QxMHtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuXHJcbi5wYWRkaW5nNXtcclxucGFkZGluZy10b3A6IDVweDtcclxufVxyXG4tLWlvbi1wYWRkaW5ne1xyXG4gICAgcGFkZGluZy1sZWZ0OiB1bnNldDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IHVuc2V0O1xyXG4gICAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IHZhcigtLWlvbi1wYWRkaW5nLCA5cHgpO1xyXG4gICAgcGFkZGluZy1pbmxpbmUtZW5kOiB2YXIoLS1pb24tcGFkZGluZywgOXB4KTtcclxufVxyXG5cclxuLnRpbWVyY29se1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXRpbnQpO1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogOXB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDlweDtcclxufVxyXG4uaHRleHR7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tdG9wOiAzcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxcHg7XHJcbn1cclxuLmhub217XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tdG9wOiAxcHg7XHJcbn1cclxuXHJcbi5pbWd7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbn1cclxuLmN1c3REaXZ7XHJcbiAgICBib3JkZXItd2lkdGg6IDAuMnB4O1xyXG4gICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtdGludCk7XHJcbiAgICBib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gICAgYm9yZGVyLWJvdHRvbTogbm9uZTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHBhZGRpbmctdG9wOiAycHg7XHJcbn1cclxuIiwiLnJhZHVzNSB7XG4gIGJvcmRlci1yYWRpdXM6IDQlO1xufVxuXG4uYm9yZGVybGlnaHQge1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBib3JkZXItd2lkdGg6IDAuNXB4O1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XG59XG5cbi5iYWRnZSB7XG4gIHBhZGRpbmctdG9wOiA0cHg7XG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDEzcHg7XG4gIHBhZGRpbmctbGVmdDogMTRweDtcbn1cblxuLm1ndDEwIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLnBhZGRpbmc1IHtcbiAgcGFkZGluZy10b3A6IDVweDtcbn1cblxuLS1pb24tcGFkZGluZyB7XG4gIHBhZGRpbmctbGVmdDogdW5zZXQ7XG4gIHBhZGRpbmctcmlnaHQ6IHVuc2V0O1xuICBwYWRkaW5nLWlubGluZS1zdGFydDogdmFyKC0taW9uLXBhZGRpbmcsIDlweCk7XG4gIHBhZGRpbmctaW5saW5lLWVuZDogdmFyKC0taW9uLXBhZGRpbmcsIDlweCk7XG59XG5cbi50aW1lcmNvbCB7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC10aW50KTtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogOXB4O1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogOXB4O1xufVxuXG4uaHRleHQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDNweDtcbiAgbWFyZ2luLWJvdHRvbTogMXB4O1xufVxuXG4uaG5vbSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogMXB4O1xufVxuXG4uaW1nIHtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uY3VzdERpdiB7XG4gIGJvcmRlci13aWR0aDogMC4ycHg7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXRpbnQpO1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBib3JkZXItYm90dG9tOiBub25lO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmctdG9wOiAycHg7XG59Il19 */";

/***/ }),

/***/ 73098:
/*!************************************************!*\
  !*** ./src/app/cart/cart.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar dir=\"rtl\" >\n    <ion-title>\n      <ion-icon name=\"receipt-outline\"></ion-icon>\n     الطلبات \n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content> \n  <ion-grid *ngIf=\"errorLoad == true\" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n</ion-grid>\n\n\n<ion-grid *ngIf=\"!orders && errorLoad == false\"  class=\"custGrid\"> \n  <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n    <ion-col size=\"12\" class=\"ion-text-center\">\n      <!-- *ngIf=\"spinner == true\" -->\n      <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n    </ion-col>\n    <ion-col size=\"12\">\n      <!-- *ngIf=\"spinner == true\" --> \n    </ion-col>\n  </ion-row> \n</ion-grid>\n\n  <ion-grid *ngIf=\"orders\"> \n    <ion-row class=\"ion-padding \" *ngIf=\"orders.length > 0\">  \n      <ion-col size=\"12\" class=\"radus5 borderlight w100 ion-margin-top\" *ngFor =\"let order of orders\">\n        <ion-grid class=\"ion-no-padding\" dir=\"rtl\"> \n          <ion-row>\n            <ion-item class=\"w100\" lines=\"none\"> \n              <ion-badge *ngIf=\"order.currentStatus == 0\" color=\"warning\" slot=\"end\" class=\"badge\">\n                <ion-text> قيد المعالجة</ion-text> \n                  <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n                </ion-badge>\n                <ion-badge *ngIf=\"order.currentStatus == 2\" color=\"light\" slot=\"end\" class=\"badge\">\n                  <ion-text>تم الإستلام</ion-text> \n                    <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n                  </ion-badge>\n                  <ion-badge *ngIf=\"order.currentStatus == 1\" color=\"success\" slot=\"end\" class=\"badge\">\n                    <ion-text>تم الدفع</ion-text> \n                  <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n                  </ion-badge>\n                  <ion-badge *ngIf=\"order.currentStatus == 3\" color=\"danger\" slot=\"end\" class=\"badge\">\n                    <ion-text>تم الإلغاء</ion-text> \n                  <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n                  </ion-badge>\n              <ion-label>{{order.auctions[0].title}}</ion-label>\n            </ion-item>\n          </ion-row>\n           \n          <ion-row>\n            <ion-col size=\"6\" > \n              <img class=\"radus5 img\" [src]=\"order.auctions[0].imgs[0]\"/>   \n            </ion-col>\n            <ion-col size=\"6\">\n              <ion-grid   dir =\"rtl\" class=\"ion-no-padding\"> \n                <ion-row  class=\"mgt10 ion-padding-start\">\n                  <ion-label> \n                    <ion-note color=\"primary\"><b>رقم المزاد : </b>  </ion-note>\n                    <ion-text>{{order.auctions[0]._id.substring(0,6)}}</ion-text> \n                  </ion-label> \n                </ion-row> \n                <ion-row  class=\"mgt10 ion-padding-start\">\n                  <ion-label> \n                    <ion-note color=\"primary\"><b>سعر المنتج : </b>  </ion-note>\n                    <ion-note>   {{order.higtPayedPrie}} </ion-note>\n                    <ion-note>ج.س</ion-note>\n                  </ion-label>\n                </ion-row>\n                <ion-row  class=\"mgt10 ion-padding-start\">\n                  <ion-label> \n                    <ion-note color=\"primary\"><b>  العربون :</b>  </ion-note>\n                    <ion-note> {{ - order.auctions[0].deposit}} </ion-note>\n                    <ion-note>ج.س</ion-note>\n                  </ion-label>\n                </ion-row>\n                <ion-row *ngIf=\"order.discount\" class=\"mgt10 ion-padding-start\">\n                  <ion-label> \n                    <ion-note color=\"primary\"><b>  تخفيض :</b>  </ion-note>\n                    <ion-note> {{ - order.discount}} </ion-note>\n                    <ion-note>ج.س</ion-note>\n                  </ion-label>\n                </ion-row> \n                <ion-row  class=\"mgt10 ion-padding-start\">\n                  <ion-label> \n                    <ion-note color=\"primary\"><b>   المطلوب :</b>  </ion-note>\n                    <ion-note>  {{+order.higtPayedPrie  - +order.auctions[0].deposit }}   </ion-note>\n                    <ion-note>ج.س</ion-note>\n                  </ion-label>\n                </ion-row>\n              </ion-grid> \n            </ion-col>\n          </ion-row>\n         \n       \n          <ion-row  class=\"ion-margin-top ion-justify-content-center\" dir=\"rtl\"> \n            <ion-col size=\"4\">\n              <ion-button expand=\"block\" (click)=\"orderDetailsPage(order._id)\">\n                <h5 ><b>التفاصيل  </b></h5>\n                <!-- <h5 *ngIf=\"order.currentStatus == 1 \"><b>إستلام</b></h5>\n                <h5 *ngIf=\"order.currentStatus > 2 \"><b>التفاصيل</b></h5> -->\n              </ion-button>\n            </ion-col>\n          </ion-row>\n          </ion-grid>\n      </ion-col> \n    </ion-row>\n    <ion-row class=\"ion-padding \" *ngIf=\"orders.length == 0\" class=\"custGrid\">\n      <ion-col size=\"12\" class=\"ion-text-center\">\n        <!-- *ngIf=\"spinner == true\" -->\n        <h3>\n          <ion-label>\n            ليس لديك طلبات بعد !\n          </ion-label>\n        </h3>\n      </ion-col>\n    </ion-row>\n\n\n \n  </ion-grid>\n  \n  </ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_cart_cart_module_ts.js.map