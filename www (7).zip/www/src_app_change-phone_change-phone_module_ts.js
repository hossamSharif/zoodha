"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_change-phone_change-phone_module_ts"],{

/***/ 29851:
/*!*************************************************************!*\
  !*** ./src/app/change-phone/change-phone-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePhonePageRoutingModule": () => (/* binding */ ChangePhonePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _change_phone_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./change-phone.page */ 94676);




const routes = [
    {
        path: '',
        component: _change_phone_page__WEBPACK_IMPORTED_MODULE_0__.ChangePhonePage
    }
];
let ChangePhonePageRoutingModule = class ChangePhonePageRoutingModule {
};
ChangePhonePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ChangePhonePageRoutingModule);



/***/ }),

/***/ 25546:
/*!*****************************************************!*\
  !*** ./src/app/change-phone/change-phone.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePhonePageModule": () => (/* binding */ ChangePhonePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _change_phone_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./change-phone-routing.module */ 29851);
/* harmony import */ var _change_phone_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./change-phone.page */ 94676);







let ChangePhonePageModule = class ChangePhonePageModule {
};
ChangePhonePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _change_phone_routing_module__WEBPACK_IMPORTED_MODULE_0__.ChangePhonePageRoutingModule
        ],
        declarations: [_change_phone_page__WEBPACK_IMPORTED_MODULE_1__.ChangePhonePage]
    })
], ChangePhonePageModule);



/***/ }),

/***/ 94676:
/*!***************************************************!*\
  !*** ./src/app/change-phone/change-phone.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChangePhonePage": () => (/* binding */ ChangePhonePage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _change_phone_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./change-phone.page.html?ngResource */ 42495);
/* harmony import */ var _change_phone_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./change-phone.page.scss?ngResource */ 47368);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/socket-service.service */ 20905);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ 80190);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);










let ChangePhonePage = class ChangePhonePage {
  constructor(formBuilder, toast, api, storage, rout) {
    this.formBuilder = formBuilder;
    this.toast = toast;
    this.api = api;
    this.storage = storage;
    this.rout = rout;
    this.style = 'style2';
    this.errorLoad = false;
    this.oldPhone = "";
    this.spinner = false;
    this.isSubmitted = false;
    this.ionicForm = this.formBuilder.group({
      phone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.minLength(9), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.maxLength(9), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.pattern('^[0-9]+$')]]
    });
  }

  getProfile() {
    console.log('im here bro');
    this.storage.get('token').then(response => {
      if (response) {
        console.log('token', response);
        this.api.auth(response).subscribe(data => {
          console.log('authservices', data);
          this.USER_INFO = data['user'];
          console.log(this.USER_INFO);
          this.oldPhone = this.USER_INFO.phone;
        }, err => {
          console.log(err);
          this.errorLoad = true;
        });
      } else {
        this.rout.navigate(['login']);
      }
    });
  }

  reload() {
    this.errorLoad = false;
    this.USER_INFO = undefined;
    this.getProfile();
  }

  ngOnInit() {
    this.getProfile();
  }

  get errorControl() {
    return this.ionicForm.controls;
  }

  validate() {
    this.isSubmitted = true;

    if (this.ionicForm.valid == false) {
      console.log('Please provide all the required values!');
      return false;
    } else if (this.USER_INFO.phone == this.oldPhone) {
      this.presentToast('ادخلت نفس الرقم القديم , الرجاء ادخال رقم اخر', 'danger');
      return false;
    } else if (this.USER_INFO.phone[0] != 9 && +this.USER_INFO.phone[0] != 1) {
      console.log(this.USER_INFO.phone[0]);
      this.presentToast('رقم الجوال غير صحيح', 'danger');
    } else {
      return true;
    }
  }

  updatePhone() {
    if (this.validate() == true) {
      this.api.updateUser(this.USER_INFO).subscribe(data => {
        console.log('user was updated', data);
        let res = data;
        console.log('user was created', res['token']);
        this.storage.set('token', res['token']).then(response => {
          let navigationExtras = {
            queryParams: {
              type: JSON.stringify('exist'),
              data: JSON.stringify(res)
            }
          };
          this.rout.navigate(['verify'], navigationExtras);
        });
      }, err => {
        console.log();
        this.handleError(err.error.error);
      });
    }
  }

  handleError(msg) {
    if (msg == "duplicate phone") {
      this.presentToast('رقم الهاتف موجود مسبقا , قم بتسجيل الدخول', 'danger');
      return false;
    } else if (!msg) {
      this.presentToast('حدث خطأ ما ,حاول مرة اخري', 'danger');
      return false;
    }
  }

  presentToast(msg, color) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  }

};

ChangePhonePage.ctorParameters = () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService
}, {
  type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__.Storage
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}];

ChangePhonePage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-change-phone',
  template: _change_phone_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_change_phone_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ChangePhonePage);


/***/ }),

/***/ 47368:
/*!****************************************************************!*\
  !*** ./src/app/change-phone/change-phone.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = ".custInput {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-dark);\n  background-color: var(--ion-color-primary-contrast);\n  border-radius: 2rem;\n}\n\n.custItem {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-dark);\n  background-color: var(--ion-color-primary-contrast);\n  border-radius: 2rem;\n}\n\n.mgt10 {\n  margin-top: 10px;\n}\n\n.roundedGrid {\n  border-radius: 50px;\n  /* border-bottom-left-radius: 50px; */\n  /* border-bottom-right-radius: 50px; */\n  /* border-top-left-radius: 50px; */\n  /* border-top-right-radius: 50px; */\n  padding-left: 10px;\n  padding-right: 10px;\n}\n\n.custGridStyl2 {\n  margin-top: 10%;\n  display: grid;\n  align-items: center;\n}\n\n.header-md::after {\n  background-image: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYW5nZS1waG9uZS5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXGh1c2FtJTIwcHJvalxcem9vZG9oYVNkXFxzcmNcXGFwcFxcY2hhbmdlLXBob25lXFxjaGFuZ2UtcGhvbmUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1DQUFBO0VBQ0EsbURBQUE7RUFDQSxtQkFBQTtBQ0NKOztBREVBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1DQUFBO0VBQ0EsbURBQUE7RUFDQSxtQkFBQTtBQ0NKOztBRENBO0VBQ0ksZ0JBQUE7QUNFSjs7QURDQTtFQUNJLG1CQUFBO0VBQ0EscUNBQUE7RUFDQSxzQ0FBQTtFQUNBLGtDQUFBO0VBQ0EsbUNBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDRUo7O0FERUE7RUFFSSxlQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FDQUo7O0FERUE7RUFDSSxzQkFBQTtBQ0NKIiwiZmlsZSI6ImNoYW5nZS1waG9uZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY3VzdElucHV0e1xyXG4gICAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci13aWR0aDogMC41cHg7XHJcbiAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDJyZW07XHJcbn1cclxuXHJcbi5jdXN0SXRlbXtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IDAuNXB4O1xyXG4gICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAycmVtO1xyXG59XHJcbi5tZ3QxMHtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuXHJcbi5yb3VuZGVkR3JpZHsgXHJcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgLyogYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNTBweDsgKi9cclxuICAgIC8qIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1MHB4OyAqL1xyXG4gICAgLyogYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNTBweDsgKi9cclxuICAgIC8qIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiA1MHB4OyAqL1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogMTBweDtcclxuIFxyXG4gICAgLy8gYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xyXG4gICB9XHJcbi5jdXN0R3JpZFN0eWwye1xyXG4gICAgLy8gaGVpZ2h0OiAxMDAlO1xyXG4gICAgbWFyZ2luLXRvcDogMTAlO1xyXG4gICAgZGlzcGxheTogZ3JpZDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLmhlYWRlci1tZDo6YWZ0ZXIge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTpub25lO1xyXG59IiwiLmN1c3RJbnB1dCB7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGJvcmRlci13aWR0aDogMC41cHg7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XG4gIGJvcmRlci1yYWRpdXM6IDJyZW07XG59XG5cbi5jdXN0SXRlbSB7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGJvcmRlci13aWR0aDogMC41cHg7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XG4gIGJvcmRlci1yYWRpdXM6IDJyZW07XG59XG5cbi5tZ3QxMCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5yb3VuZGVkR3JpZCB7XG4gIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4gIC8qIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDUwcHg7ICovXG4gIC8qIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1MHB4OyAqL1xuICAvKiBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA1MHB4OyAqL1xuICAvKiBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNTBweDsgKi9cbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xufVxuXG4uY3VzdEdyaWRTdHlsMiB7XG4gIG1hcmdpbi10b3A6IDEwJTtcbiAgZGlzcGxheTogZ3JpZDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmhlYWRlci1tZDo6YWZ0ZXIge1xuICBiYWNrZ3JvdW5kLWltYWdlOiBub25lO1xufSJdfQ== */";

/***/ }),

/***/ 42495:
/*!****************************************************************!*\
  !*** ./src/app/change-phone/change-phone.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar dir=\"rtl\">\n    <ion-buttons slot=\"end\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title dir=\"rtl\">تغيير رقم الجوال</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content *ngIf=\" style=='style1'\">\n  <ion-grid *ngIf=\"errorLoad == true\" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n</ion-grid>\n\n\n<ion-grid *ngIf=\"!USER_INFO && errorLoad == false\"  class=\"custGrid\"> \n  <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n    <ion-col size=\"12\" class=\"ion-text-center\">\n      <!-- *ngIf=\"spinner == true\" -->\n      <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n    </ion-col>\n    <ion-col size=\"12\">\n      <!-- *ngIf=\"spinner == true\" --> \n    </ion-col>\n  </ion-row> \n</ion-grid>\n\n<ion-grid *ngIf=\"USER_INFO\">  \n  <form [formGroup]=\"ionicForm\" (ngSubmit)=\"updatePhone()\" novalidate>\n  <ion-grid *ngIf=\"USER_INFO\" dir=\"rtl\">\n    <ion-row>\n      <ion-list class=\"w100\">\n        <ion-label> <ion-text color=\"dark\">رقم الجوال </ion-text></ion-label>\n        <ion-item dir=\"ltr\"> \n          <ion-label slot=\"start\">+249</ion-label>\n          <ion-input  formControlName=\"phone\" placeholder=\"New phone here\" [(ngModel)]=\"USER_INFO.phone\"></ion-input>\n          <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.phone.errors?.pattern\">ادخل ارقام فقط  </ion-note> \n          <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.phone.errors?.required\">رقم الجوال مطلوب </ion-note>\n          <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && (errorControl.phone.errors?.minlength || errorControl.phone.errors?.maxlength)\">يجب ان يتكون من 9 أرقام </ion-note> \n        </ion-item>\n      </ion-list>\n    </ion-row>\n    <ion-row class=\"ion-margin\">\n      <ion-col size=\"12\">\n        <ion-item color=\"primary\"  [disabled]=\"spinner == true\" button (click)=\"updatePhone()\">\n          <ion-label class=\"ion-text-center\">حفــظ </ion-label> \n          <ion-spinner name=\"lines\" color=\"light\" *ngIf=\"spinner == true\"></ion-spinner>  \n        </ion-item>\n      </ion-col>\n    </ion-row>\n  </ion-grid> \n</form>\n</ion-grid>\n</ion-content>\n<ion-content *ngIf=\" style=='style2'\">\n  <ion-grid *ngIf=\"errorLoad == true\" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n</ion-grid>\n\n\n<ion-grid *ngIf=\"!USER_INFO && errorLoad == false\"  class=\"custGrid\"> \n  <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n    <ion-col size=\"12\" class=\"ion-text-center\">\n      <!-- *ngIf=\"spinner == true\" -->\n      <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n    </ion-col>\n    <ion-col size=\"12\">\n      <!-- *ngIf=\"spinner == true\" --> \n    </ion-col>\n  </ion-row> \n</ion-grid>\n\n<ion-grid class=\"custGridStyl2 ion-margin-bottom\">\n\n\n\n \n</ion-grid>\n\n\n<ion-grid *ngIf=\"USER_INFO\" class=\"ion-margin-top custGridStyl2\"> \n  <ion-row>\n    <ion-col size=\"12\" class=\" ion-text-center \">\n      <svg  width=\"119\" height=\"119\" viewBox=\"0 0 119 119\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n        <circle opacity=\"0.27\" cx=\"59.5\" cy=\"59.5\" r=\"59.5\" fill=\"black\"/>\n        <path d=\"M46.6627 30.08H56.1756C56.7579 30.08 57.23 29.6079 57.23 29.0262C57.23 28.4439 56.7579 27.9718 56.1756 27.9718H46.6627C46.0804 27.9718 45.6089 28.4439 45.6089 29.0262C45.6089 29.6079 46.0804 30.08 46.6627 30.08Z\" fill=\"white\"/>\n        <path d=\"M85.0825 48.0975H71.8416V29.5921C71.8533 28.1244 71.2832 26.7115 70.2556 25.663C69.2275 24.615 67.8263 24.017 66.3586 24H36.4891C35.0203 24.0152 33.6174 24.6126 32.5886 25.6612C31.5592 26.7092 30.988 28.1232 31.0002 29.5921V90.3979C30.988 91.8668 31.5592 93.2807 32.5886 94.3288C33.6173 95.3774 35.0203 95.9748 36.4891 95.99H66.3586C67.8275 95.9748 69.2304 95.3774 70.2598 94.3288C71.2886 93.2808 71.8598 91.8668 71.8482 90.3979V73.7368H85.2371H85.2365C87.5132 73.7315 89.6943 72.8229 91.3013 71.2106C92.9077 69.5978 93.8082 67.4133 93.8046 65.1366V56.7807C93.793 54.4749 92.8691 52.2669 91.2347 50.6402C89.6004 49.0129 87.3885 48.099 85.0827 48.0972L85.0825 48.0975ZM36.4897 26.1079H66.3592C67.2679 26.1248 68.1329 26.5008 68.7653 27.1536C69.3977 27.8064 69.7457 28.683 69.734 29.5917V32.4775H33.0962V29.5917C33.084 28.6796 33.4349 27.8 34.0714 27.1466C34.7078 26.4938 35.5781 26.1196 36.4897 26.1079L36.4897 26.1079ZM69.733 90.3845H69.7335C69.7452 91.2932 69.3972 92.1698 68.7648 92.8226C68.1324 93.4755 67.2675 93.8514 66.3588 93.8683H36.4893C35.5806 93.8514 34.7156 93.4755 34.0832 92.8226C33.4514 92.1698 33.1028 91.2932 33.1151 90.3845V34.5862H69.7529V48.0842H51.8965C49.8729 48.086 47.9331 48.8915 46.5032 50.323C45.0734 51.7551 44.2714 53.6966 44.2732 55.7203V65.1364C44.2686 67.3694 45.1341 69.5155 46.6851 71.1212C48.2366 72.7265 50.3525 73.6649 52.5842 73.7365C53.6386 76.6421 50.9068 78.7759 50.7907 78.8785C50.4357 79.1449 50.2854 79.6054 50.4148 80.0297C50.5442 80.454 50.9259 80.7524 51.3689 80.7752H51.8894C53.9976 80.7752 61.8971 80.3124 67.3151 73.7371L69.7328 73.7365L69.733 90.3845ZM91.6971 65.1361C91.7024 66.8551 91.0233 68.5057 89.8103 69.7232C88.5973 70.9408 86.9496 71.6263 85.2308 71.6281H66.8418C66.5177 71.6287 66.2123 71.7779 66.013 72.0332C62.2722 76.8028 56.9501 78.1521 53.8906 78.5252H53.89C54.5148 77.6002 54.875 76.5218 54.9316 75.4073C54.9881 74.2929 54.7392 73.1838 54.2118 72.2005C54.0299 71.8531 53.6714 71.6351 53.2798 71.6345H52.8618C51.1395 71.6362 49.4877 70.9514 48.2717 69.732C47.0559 68.5121 46.3757 66.8585 46.3827 65.1361V55.72C46.3844 54.2576 46.9662 52.8559 47.9996 51.8218C49.0336 50.7884 50.4353 50.2067 51.8978 50.2049H85.0843C86.8375 50.2067 88.5192 50.9038 89.7588 52.1441C90.9992 53.3839 91.6962 55.0654 91.698 56.8187L91.6971 65.1361Z\" fill=\"white\"/>\n        <path d=\"M57.3076 58.9393H56.7679L57.1537 58.5535L57.1531 58.5541C57.5652 58.142 57.5652 57.4746 57.1531 57.0625C56.7416 56.651 56.0737 56.651 55.6622 57.0625L55.2763 57.4484V56.9086C55.2763 56.3264 54.8048 55.8542 54.2225 55.8542C53.6402 55.8542 53.1681 56.3264 53.1681 56.9086V57.4227L52.7823 57.0369H52.7828C52.3708 56.6254 51.7034 56.6254 51.2913 57.0369C50.8798 57.449 50.8798 58.1164 51.2913 58.5284L51.6771 58.9143H51.1374L51.1368 58.9137C50.5551 58.9137 50.083 59.3858 50.083 59.9681C50.083 60.5504 50.5551 61.0219 51.1368 61.0219H51.6766L51.2907 61.4078H51.2913C50.8722 61.814 50.8623 62.4831 51.2691 62.9023C51.6754 63.3214 52.3445 63.3313 52.7631 62.925L53.1489 62.5392V63.0789C53.1489 63.6612 53.621 64.1333 54.2033 64.1333C54.785 64.1333 55.2571 63.6612 55.2571 63.0789V62.5648L55.643 62.9507C56.0545 63.3622 56.7224 63.3622 57.1339 62.9507C57.546 62.5386 57.546 61.8712 57.1339 61.4591L56.7481 61.0733H57.2878L57.2884 61.0738C57.8707 61.0738 58.3422 60.6017 58.3422 60.0194C58.3422 59.4372 57.8707 58.9656 57.2884 58.9656L57.3076 58.9393Z\" fill=\"white\"/>\n        <path d=\"M67.7471 58.9393H67.2074L67.5933 58.5535L67.5927 58.5541C68.0048 58.142 68.0048 57.4746 67.5927 57.0625C67.1812 56.651 66.5132 56.651 66.1017 57.0625L65.7159 57.4484V56.9086C65.7159 56.3264 65.2443 55.8542 64.662 55.8542C64.0798 55.8542 63.6076 56.3264 63.6076 56.9086V57.4227L63.2218 57.0369H63.2224C62.8103 56.6254 62.1429 56.6254 61.7308 57.0369C61.3193 57.449 61.3193 58.1164 61.7308 58.5284L62.1167 58.9143L61.5699 58.9137C60.9882 58.9137 60.5161 59.3858 60.5161 59.9681C60.5161 60.5504 60.9882 61.0219 61.5699 61.0219H62.1097L61.7238 61.4078H61.7244C61.3129 61.8198 61.3129 62.4872 61.7244 62.8993C62.1365 63.3108 62.8039 63.3108 63.2154 62.8993L63.6012 62.5135V63.0532C63.6012 63.6355 64.0733 64.1076 64.6556 64.1076C65.2379 64.1076 65.7094 63.6355 65.7094 63.0532V62.5648L66.0953 62.9506C66.5068 63.3621 67.1748 63.3621 67.5863 62.9506C67.9983 62.5385 67.9983 61.8712 67.5863 61.4591L67.2004 61.0732H67.7401L67.7407 61.0738C68.323 61.0738 68.7951 60.6017 68.7951 60.0194C68.7951 59.4371 68.323 58.9656 67.7407 58.9656L67.7471 58.9393Z\" fill=\"white\"/>\n        <path d=\"M77.8833 58.9393H77.3436L77.7294 58.5535L77.7288 58.5541C78.1409 58.142 78.1409 57.4746 77.7288 57.0625C77.3173 56.651 76.6494 56.651 76.2379 57.0625L75.852 57.4484V56.9086C75.852 56.3264 75.3799 55.8542 74.7976 55.8542C74.2159 55.8542 73.7438 56.3264 73.7438 56.9086V57.4227L73.3579 57.0369C72.9464 56.6254 72.2785 56.6254 71.867 57.0369C71.4549 57.449 71.4549 58.1164 71.867 58.5284L72.2528 58.9143H71.7131L71.7125 58.9137C71.1302 58.9137 70.6587 59.3858 70.6587 59.9681C70.6587 60.5504 71.1302 61.0219 71.7125 61.0219H72.2522L71.8664 61.4078H71.867C71.4479 61.8123 71.4362 62.4802 71.8413 62.8993C72.2458 63.3178 72.9132 63.3295 73.3323 62.925L73.7181 62.5391V63.0788C73.7181 63.6611 74.1897 64.1332 74.772 64.1332C75.3542 64.1332 75.8264 63.6611 75.8264 63.0788V62.5648L76.2122 62.9506H76.2116C76.6237 63.3621 77.2911 63.3621 77.7032 62.9506C78.1147 62.5385 78.1147 61.8711 77.7032 61.4591L77.3173 61.0732H77.8571L77.8576 61.0738C78.4393 61.0738 78.9115 60.6017 78.9115 60.0194C78.9115 59.4371 78.4393 58.9656 77.8576 58.9656L77.8833 58.9393Z\" fill=\"white\"/>\n        <path d=\"M87.7295 58.9393H87.1898L87.5756 58.5535L87.575 58.5541C87.9871 58.142 87.9871 57.4746 87.575 57.0625C87.1635 56.651 86.4961 56.651 86.0841 57.0625L85.6982 57.4484V56.9086C85.6982 56.3264 85.2267 55.8542 84.6444 55.8542C84.0621 55.8542 83.59 56.3264 83.59 56.9086V57.4227L83.2041 57.0369H83.2047C82.7856 56.6184 82.1066 56.6184 81.6875 57.0369C81.2684 57.456 81.2684 58.135 81.6875 58.5541L82.0734 58.9399L81.5593 58.9393C80.977 58.9393 80.5049 59.4115 80.5049 59.9937C80.5049 60.576 80.977 61.0481 81.5593 61.0481H82.099L81.7132 61.434V61.4334C81.3017 61.8455 81.3017 62.5129 81.7132 62.925C82.1252 63.3365 82.7926 63.3365 83.2047 62.925L83.6156 62.5648V63.1045C83.6156 63.6868 84.0878 64.1589 84.67 64.1589C85.2523 64.1589 85.7239 63.6868 85.7239 63.1045V62.5648L86.1097 62.9506C86.5218 63.3621 87.1892 63.3621 87.6013 62.9506C88.0128 62.5385 88.0128 61.8711 87.6013 61.459L87.2154 61.0732H87.7551V61.0738C88.3374 61.0738 88.8095 60.6017 88.8095 60.0194C88.8095 59.4371 88.3374 58.9656 87.7551 58.9656L87.7295 58.9393Z\" fill=\"white\"/>\n        <path d=\"M51.4201 83.2043C50.1157 83.2043 48.8648 83.7225 47.9427 84.6446C47.0206 85.5667 46.5024 86.8174 46.5024 88.1214C46.5024 89.4259 47.0206 90.6761 47.9427 91.5982C48.8648 92.5209 50.1155 93.0385 51.4201 93.0385C52.724 93.0385 53.9748 92.5209 54.8969 91.5982C55.819 90.6761 56.3372 89.4258 56.3372 88.1214C56.3354 86.8181 55.8167 85.5685 54.8952 84.6464C53.9731 83.7249 52.7234 83.2061 51.4201 83.2044L51.4201 83.2043ZM51.4201 90.9173C50.6752 90.9173 49.9606 90.6218 49.4338 90.0949C48.9069 89.568 48.6114 88.8534 48.6114 88.1086C48.6114 87.3637 48.9069 86.6491 49.4338 86.1227C49.9607 85.5958 50.6753 85.2997 51.4201 85.2997C52.165 85.2997 52.8796 85.5958 53.406 86.1227C53.9329 86.649 54.229 87.3636 54.229 88.1086C54.2307 88.8546 53.9352 89.571 53.4083 90.0991C52.8814 90.6272 52.1662 90.9238 51.4202 90.9238L51.4201 90.9173Z\" fill=\"white\"/>\n        </svg>   \n   </ion-col>\n  </ion-row>\n\n  <form [formGroup]=\"ionicForm\" (ngSubmit)=\"updatePhone()\" novalidate>\n  <ion-grid *ngIf=\"USER_INFO\" dir=\"rtl\">\n\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col size=\"11\" >\n       <ion-card class=\" roundedGrid w100 ion-padding\" >\n        \n          <ion-list class=\"w100 mgt10\">\n            <!-- <ion-label> <ion-text color=\"dark\">رقم الجوال </ion-text></ion-label> -->\n            <ion-item class=\"custInput mgt10\" dir=\"ltr\"> \n              <ion-label slot=\"start\">+249</ion-label>\n              <ion-input  formControlName=\"phone\" placeholder=\"رقم الجوال\" [(ngModel)]=\"USER_INFO.phone\"></ion-input>\n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.phone.errors?.pattern\">ادخل ارقام فقط  </ion-note> \n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.phone.errors?.required\">رقم الجوال مطلوب </ion-note>\n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && (errorControl.phone.errors?.minlength || errorControl.phone.errors?.maxlength)\">يجب ان يتكون من 9 أرقام </ion-note> \n            </ion-item>\n\n            <ion-item class=\"custItem mgt10\" color=\"dark\"  [disabled]=\"spinner == true\" button (click)=\"updatePhone()\">\n              <ion-label class=\"ion-text-center\">حفــظ </ion-label> \n              <ion-spinner name=\"lines\" color=\"light\" *ngIf=\"spinner == true\"></ion-spinner>  \n            </ion-item>\n          </ion-list> \n        </ion-card>\n        </ion-col>\n        </ion-row> \n  </ion-grid> \n</form>\n</ion-grid>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_change-phone_change-phone_module_ts.js.map