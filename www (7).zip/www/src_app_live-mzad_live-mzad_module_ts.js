"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_live-mzad_live-mzad_module_ts"],{

/***/ 5360:
/*!*******************************************************!*\
  !*** ./src/app/live-mzad/live-mzad-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LiveMzadPageRoutingModule": () => (/* binding */ LiveMzadPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _live_mzad_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./live-mzad.page */ 3011);




const routes = [
    {
        path: '',
        component: _live_mzad_page__WEBPACK_IMPORTED_MODULE_0__.LiveMzadPage
    }
];
let LiveMzadPageRoutingModule = class LiveMzadPageRoutingModule {
};
LiveMzadPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LiveMzadPageRoutingModule);



/***/ }),

/***/ 98561:
/*!***********************************************!*\
  !*** ./src/app/live-mzad/live-mzad.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LiveMzadPageModule": () => (/* binding */ LiveMzadPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _pipes_date_ago_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../pipes/date-ago.pipe */ 742);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _live_mzad_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./live-mzad-routing.module */ 5360);
/* harmony import */ var _live_mzad_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./live-mzad.page */ 3011);








let LiveMzadPageModule = class LiveMzadPageModule {
};
LiveMzadPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _live_mzad_routing_module__WEBPACK_IMPORTED_MODULE_1__.LiveMzadPageRoutingModule
        ],
        declarations: [_live_mzad_page__WEBPACK_IMPORTED_MODULE_2__.LiveMzadPage, _pipes_date_ago_pipe__WEBPACK_IMPORTED_MODULE_0__.DateAgoPipe],
        exports: [_pipes_date_ago_pipe__WEBPACK_IMPORTED_MODULE_0__.DateAgoPipe]
    })
], LiveMzadPageModule);



/***/ }),

/***/ 3011:
/*!*********************************************!*\
  !*** ./src/app/live-mzad/live-mzad.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LiveMzadPage": () => (/* binding */ LiveMzadPage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _live_mzad_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./live-mzad.page.html?ngResource */ 47443);
/* harmony import */ var _live_mzad_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./live-mzad.page.scss?ngResource */ 48997);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 12378);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/socket-service.service */ 20905);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ 56908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment-timezone */ 92469);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment_timezone__WEBPACK_IMPORTED_MODULE_5__);












let LiveMzadPage = class LiveMzadPage {
  //time$ = timer(0, 1000).pipe(map(() => new Date()));
  constructor(alertController, api, socket, route, loadingController, toast, actionSheetCtl, datePipe, rout, modalController) {
    this.alertController = alertController;
    this.api = api;
    this.socket = socket;
    this.route = route;
    this.loadingController = loadingController;
    this.toast = toast;
    this.actionSheetCtl = actionSheetCtl;
    this.datePipe = datePipe;
    this.rout = rout;
    this.modalController = modalController;
    this.showMore = false;
    this.emptyLog = false;
    this.style = 'style2';
    this.errorLoad = false;
    this.roundsMode = true;
    this.availRounds = 0;
    this.highestBidd = 0;
    this.lastBidd4U = 0;
    this.timeLeft = {
      da: "",
      hr: "",
      mn: "",
      sc: ""
    };
    this.showMe = false;
    this.users = [];
    this.usersLogs = [];
    this.termsArr = [];
    this.showError = false;
    this.msgError = "";
    this.route.queryParams.subscribe(params => {
      console.log('params', params);

      if (params && params.id) {
        this.USER_INFO = JSON.parse(params.user_info);
        this.auction_id = JSON.parse(params.id);
        console.log(this.auction_id);
        this.getAuction();
      }
    });
  }

  tirmString(string, length) {
    return string.substring(0, length) + '...';
  }

  ngOnInit() {
    //notify other when some how join live stream 
    this.socket.userJoinedAuction().subscribe(UserHadJoined => {
      console.log(UserHadJoined);

      if (UserHadJoined.length > 0) {
        this.presentToast(UserHadJoined[1] + "  إنضم", 'success'); //change user status from offline to online 
      }
    }); //notify other when some how add bidding (listing)

    this.socket.userBiddedInAuction().subscribe(logArr => {
      if (logArr.length > 0) {
        console.log('jahsja', logArr);
        this.mzd['logs'].push(logArr[0][0]);
        this.prepareAuc();
        this.presentToast(logArr[1].firstName + " " + logArr[0][0].pay, 'success');
      }
    }); //notify other when some how fucos input and start writting bid price (listing)

    this.socket.userFucosedBiddedInAuction().subscribe(logArr => {
      console.log(logArr);

      if (logArr.length > 0) {// this.presentToast(logArr[0].firstName  ,'success') 
      }
    }); //notify other when some how fucos input and start writting bid price (listing)

    this.socket.userFucosedLostBiddedInAuction().subscribe(logArr => {
      console.log(logArr);

      if (logArr.length > 0) {// this.presentToast(logArr[0].firstName  ,'danger') 
      }
    });
  }

  ionViewDidEnter() {
    ////  
    this.socket.auctionEndOntime().subscribe(ar => {
      console.log('here im', ar); // this.presentToast('holla  auction end on time ' ,'success') 

      if (ar.length > 0) {
        //this.presentToast('holla  auction end on time ' ,'success')
        this.onEndAuction(ar[1], ar[2]);
      }
    });
  }

  reload() {
    this.errorLoad = false;
    this.mzd = undefined;
    this.getAuction();
  }

  handleError(err) {
    this.errorLoad = true; // if (err.error == "No user with this phone found") {
    //   console.log('no user was found') 
    // // this.getsms('new',err) // uncomment it after apply smsgetway 
    // // this.getVirfyCode('new' , err) // comment it after apply smsgetway 
    // }else if(err.error == "another phone"){
    //   // to apply imei check uncmment the line in zoodohapi/controller/user.j function : loginPhone
    //   this.presentToast('seem you use another phone','danger') 
    // } else{ 
    //   this.presentToast('حدث خطأ ما ,حاول مرة اخري','danger')
    //   console.log(err.kind)
    // }
  }

  getAuction() {
    this.api.getAuction(this.auction_id).subscribe(data => {
      console.log(data);
      let res = data['auction'];
      this.mzd = data['auction'];
      this.users = this.mzd['users'];
      console.log('im here baby', this.mzd, 'users', this.users);
      this.prepareAuc();
    }, err => {
      this.handleError(err.error.error);
      console.log(err);
    });
  }

  prepareAuc() {
    this.timeLeft = this.endAfterounter(); //ordering log depend on date desc
    // this.mzd['logs']=this.mzd['logs'].sort((x, y) => +new Date(x.time) > +new Date(y.time));

    if (this.mzd['logs'].length > 0) {
      this.emptyLog = false;
      this.mzd['logs'] = this.mzd['logs'].sort(function (a, b) {
        var dateA = new Date(a.time);
        var dateB = new Date(b.time);
        return dateA < dateB ? 1 : -1; // ? -1 : 1 for ascending/increasing order
      });
      console.log('sorting', this.mzd['logs']); //view time قبل دقيقتين 
      //use dateAgo pipe
      //get heigt price

      this.highestBidd = this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0);
      console.log('highestBidd', this.highestBidd); //  last bidd for you

      let flt = [];
      flt = this.mzd['logs'].filter(x => x._id == this.USER_INFO._id);

      if (flt.length > 0) {
        this.lastBidd4U = flt[0].pay;
        console.log('pay', this.lastBidd4U);
      } else {
        this.lastBidd4U = 0;
      } // prepare users Log


      console.log('prepare users Log', this.mzd['logs'].length);

      if (this.mzd['logs'].length > 2) {
        console.log('less');
        this.getUserinfoLog('less');
      } else {
        console.log('more');
        this.getUserinfoLog('more');
      }
    } else {
      this.emptyLog = true;
    } // prepare terms 


    if (this.mzd['terms'].length > 2) {
      this.getTerms('less');
    } else {
      this.getTerms('more');
    } // rounds preabare


    this.availRounds = this.mzd['rounds'];
    let flt = [];

    if (this.mzd['logs'].length > 0) {
      flt = this.mzd['logs'].filter(x => x.userId == this.USER_INFO._id);
      this.availRounds = this.mzd['rounds'] - +flt.length;
      console.log('rounds preabare', this.mzd['rounds'], flt.length);
      console.log('rounds preabare', this.usersLogs);
    }
  }

  onEndAuction(winnerId, orderId) {
    if (winnerId == this.USER_INFO._id) {
      this.presentAlert('winner', winnerId, orderId);
    } else {
      this.presentAlert();
    }
  }

  presentAlert(stat, winId, orderId) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let msg = "";
      let subHeader = "";
      let header = "";
      let btns = [];

      if (stat == 'winner') {
        subHeader = 'مبروووك ';
        msg = 'لقد ربحت المزاد , اضغط علي متابعة الطلب ';
        btns = [{
          text: 'متابعة الطلب',
          role: 'orders',
          handler: () => {
            _this.goToOrderDetails(orderId);
          }
        }];
      } else {
        subHeader = 'لم تربح المزاد  ';
        msg = 'حظا موفقا في المرة القادمة';
        btns = [{
          text: 'الرئيسية',
          role: 'home',
          handler: () => {
            _this.goHome();
          }
        }];
      }

      const alert = yield _this.alertController.create({
        header: 'تنبيه',
        subHeader: subHeader,
        message: msg,
        mode: 'ios',
        buttons: btns,
        backdropDismiss: false
      });
      yield alert.present();
      const {
        role
      } = yield alert.onDidDismiss(); //  this.roleMessage = `Dismissed with role: ${role}`;
    })();
  }

  goToOrderDetails(orederId) {
    let navigationExtras = {
      queryParams: {
        id: JSON.stringify(orederId),
        user_info: JSON.stringify(this.USER_INFO)
      }
    };
    this.alertController.dismiss();
    this.rout.navigate(['order-details'], navigationExtras);
  }

  goHome() {
    this.rout.navigate(['tabs/home']);
  }

  getUserinfoLog(moreOrLess) {
    let length;

    if (moreOrLess == 'less') {
      length = 2;
      this.view = 0;
    } else if (moreOrLess == 'more') {
      length = this.mzd['logs'].length;
      this.view = 1;
    } else {
      length = this.mzd['logs'].length;
      this.view = 3;
    }

    console.log('length', length);
    this.usersLogs = [];

    for (let index = 0; index < length; index++) {
      const element = this.mzd['logs'][index];
      console.log('element', element);
      let flt = [];
      flt = this.users.filter(x => x.userId == element.userId);
      console.log('flt', flt);

      if (flt.length > 0) {
        this.usersLogs.push({
          "userId": element.userId,
          "time": element.time,
          "pay": +element.pay,
          "lastHighestPay": +element.lastHighestPay,
          "userName": flt[0]['userName'],
          "fullName": flt[0]['fullName'],
          "firstName": flt[0]['firstName'],
          "lastName": flt[0]['lastName'],
          "imgUrl": flt[0]['imgUrl']
        });
      }
    } // this.view = 0  
    // this.mzd['logs'].forEach(element => {
    //    let flt =  this.users.filter(x=>x._id == element.userId)[0].userName
    //    this.usersLogs.push({
    //       "userId": element.userId ,
    //       "time":  element.time,
    //       "pay" : +element.pay,
    //       "lastHighestPay": +element.lastHighestPay,
    //       "userName" : flt 
    //    })
    // }); 

  }

  getTerms(moreOrLess) {
    let length;

    if (moreOrLess == 'less') {
      length = 2;
      this.viewTerms = 0;
    } else if (moreOrLess == 'more') {
      length = this.mzd['terms'].length;
      this.viewTerms = 1;
    } else {
      length = this.mzd['terms'].length;
      this.viewTerms = 3;
    }

    this.termsArr = [];

    for (let index = 0; index < length; index++) {
      const element = this.mzd['terms'][index];
      console.log('element', element);
      this.termsArr.push(element);
    }
  }

  viewMoreLess() {
    console.log(this.view);

    if (this.view == 0) {
      this.getUserinfoLog('more');
      this.view = 1;
    } else {
      this.getUserinfoLog('less');
      this.view = 0;
    }
  }

  viewMoreLessTerms() {
    console.log(this.view);

    if (this.viewTerms == 0) {
      this.getTerms('more');
      this.viewTerms = 1;
    } else {
      this.getTerms('less');
      this.viewTerms = 0;
    }
  }

  startAfterounter(startDate) {
    setInterval(function () {
      const timeLeft = moment__WEBPACK_IMPORTED_MODULE_4__.duration(moment__WEBPACK_IMPORTED_MODULE_4__(startDate).diff(moment__WEBPACK_IMPORTED_MODULE_4__())); // get difference between now and timestamp

      console.log('days', timeLeft.days(), 'hours', timeLeft.hours(), 'min', timeLeft.minutes(), 'econd', timeLeft.seconds());
      return timeLeft;
    }, 1000);
  }

  endAfterounter() {
    let offset = moment_timezone__WEBPACK_IMPORTED_MODULE_5__().utcOffset();
    let newDate = moment__WEBPACK_IMPORTED_MODULE_4__(this.mzd['end']).add();
    console.log('init', this.mzd['end'], 'sdfs', offset, 'newDate', moment__WEBPACK_IMPORTED_MODULE_4__(newDate).format('YYYY-MM-DDTHH:mm:ss.SSSSZ'));
    return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable(observer => {
      setInterval(() => observer.next({
        da: this.memnto(newDate).days().toString(),
        hr: this.memnto(newDate).hours().toString(),
        mn: this.memnto(newDate).minutes().toString(),
        sc: this.memnto(newDate).seconds().toString()
      }), 1000);
    });
  }

  memnto(newDate) {
    return moment__WEBPACK_IMPORTED_MODULE_4__.duration(moment__WEBPACK_IMPORTED_MODULE_4__(newDate).diff(moment__WEBPACK_IMPORTED_MODULE_4__()));
  }

  validationPrice(type) {
    let h = this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0); // not more than oppenning price 

    if (+this.bidPrice == 0 || this.bidPrice == null) {
      this.showError = true;
      this.msgError = ' أقل مبلغ للمزايدة ' + this.highestBidd + 1;
    } else if (this.availRounds == 0) {
      if (type == 'btn') {
        this.showError = true;
        this.msgError = 'انتهي عدد محاولاتك';
      } else {
        this.presentToast('انتهي عدد محاولاتك', 'danger');
        return true;
      }
    } else if (this.bidPrice <= this.mzd['productPrice'] - 0.3 * this.mzd['productPrice']) {
      if (type == 'btn') {
        this.showError = true;
        this.msgError = 'أقل من السعر الإفتتاحي';
      } else {
        this.presentToast('يحب المزايدة باعلي من السعر الإفتتاحي', 'danger');
        return true;
      }
    } else if (this.bidPrice <= h) {
      // not  more than hhiiest bid 
      if (type == 'btn') {
        this.showError = true;
        this.msgError = 'اقل من المطلوب';
      } else {
        this.presentToast('المبلغ اقل من المطلوب', 'danger');
        this.presentToast('', 'danger');
        return false;
      }
    } else if (this.bidPrice >= this.mzd['productPrice']) {
      // not more than product price
      if (type == 'btn') {
        this.showError = true;
        this.msgError = 'اعلي من سعر المنتج';
      } else {
        this.presentToast('المبلغ اعلي من سعر المنتج', 'danger');
        return false;
      }
    } else {
      if (type == 'btn') {
        this.showError = false;
      } else {
        return true;
      }
    }
  }

  bidChange(ev) {
    console.log(ev);
    this.validationPrice('btn');
  }

  increase(bidPrice) {
    this.validationPrice('btn');
    let h = this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0);

    if (bidPrice) {
      this.bidPrice = this.bidPrice + 1;
    } else {
      this.bidPrice = h + 1;
    }
  }

  decrease(bidPrice) {
    this.validationPrice('btn');
    let h = this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0);

    if (bidPrice) {
      this.bidPrice = this.bidPrice - 1;
    } else {
      this.bidPrice = h;
    }
  }

  focusBidding(ev) {
    let h = this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0);
    console.log(ev.target.value, 'h', h);

    if (h == 0 && ev.target.value == 0) {
      this.bidPrice = +this.mzd['productPrice'] - 0.3 * +this.mzd['productPrice'] + 1;
    } else {
      if (ev.target.value > 0) {
        this.bidPrice = this.bidPrice + 1;
      } else {
        this.bidPrice = h + 1;
      }
    }

    this.socket.userFucosBiddingInAuction([this.USER_INFO, this.mzd._id]);
  }

  unCheckFocus() {
    console.log('unCheckFocus');
    this.socket.userFucosLostBiddingInAuction([this.USER_INFO, this.mzd._id]); //  show indicator loader jst like typing...  
  }

  endAuction() {
    let arr = {
      _id: this.mzd['_id'],
      auction: this.mzd
    };
    console.log('auction', arr);
    this.api.endAuctionOntime(arr).subscribe(data => {
      console.log('auction update', data); // نهاي المزاد دالة في الباكند بتنهي المزاد 
      // وتعمل بوش نوتيف بإستخدام السوكيت لكل المساخدمين المتصيلين 
      // push notif for offline users of auction 
      //صفحة اللايف ح تستقبل الأوردور من الباكند وتظهر رسالة للمستخدمين 
      //  خاصة رسالة الفائز  تقوم بتوجيه الي صفحة الطلبات 
      // يتحول المزاد للصفحة الأوردرات
      // صفحة الأوردرات تعامل معاملة السلة 
      // تبرمج بإستخدام behavior subject 
    }, err => {
      console.log(err);
    });
  }

  bidding() {
    if (this.validationPrice('submit') == true) {
      let arr = {
        _id: this.mzd['_id'],
        log: [{
          "userId": this.USER_INFO._id,
          "time": new Date(),
          "pay": +this.bidPrice,
          "lastHighestPay": this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0)
        }]
      }; // let arr  = { 
      //   _id : this.mzd['_id'] ,
      //   users :[{
      //     "userId":"736fc6299c3a4269ace43b7641014af2",
      //     "status":1
      //    },
      //    {
      //     "userId":"700865bcaa934e5ebe956a2013c33395",
      //     "status":1
      //    },
      //    {
      //     "userId":"88a8ff31502e4ad5b43152a4befa4756" ,
      //     "status":1
      //    } ] 
      // }

      this.api.updateAuctionsLog(arr).subscribe(data => {
        console.log('auction update', data);
        this.mzd = data['updatedLogAuction'];
        console.log(this.mzd); // update log and hiegst price and

        this.prepareAuc(); // animate heighst price and hand bidding

        this.animateLogAndprice(); //alert others by new price using socket.io for room

        this.prepareBidding(); // let res = data['auction'][0]
        // this.mzad = res
        // console.log('im here baby',this.mzad)
      }, err => {
        console.log(err);
        this.handelErrorBiding(err.error.error);
      }); // 
      // add record to log 
      // animate input and highest bidding price
      // it done by addedd animation classes
      //show alert for other users using sockit 
      // it done by subiscribe  in ng on it  
    }
  }

  handelErrorBiding(err) {
    // if (err.error == "No user with this phone found") {
    //     console.log('no user was found')  
    //   } else if (err.error == "another phone") { 
    //     this.presentToast('seem you use another phone','danger') 
    //   } else { 
    //     this.presentToast('حدث خطأ ما ,حاول مرة اخري','danger')
    //     console.log(err.kind)
    //   } 
    this.presentToast('حدث خطأ ما ,حاول مرة اخري', 'danger');
  }

  prepareBidding() {
    let log = [{
      "userId": this.USER_INFO._id,
      "time": new Date(),
      "pay": +this.bidPrice,
      "lastHighestPay": this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0)
    }];
    this.socket.userBiddingInAuction([log, this.USER_INFO, this.mzd._id]);
  }

  animateLogAndprice() {
    this.showMe = true;
    setTimeout(() => {
      this.showMe = false;
    }, 3000);
  }

  presentToast(msg, color) {
    var _this2 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this2.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  } //extra fuction


  getOffsetUtc() {
    let time = moment_timezone__WEBPACK_IMPORTED_MODULE_5__().tz('Africa/Cairo').format('HH:mm:ss z');
    let off = moment_timezone__WEBPACK_IMPORTED_MODULE_5__(new Date()).utcOffset();
    let local = moment_timezone__WEBPACK_IMPORTED_MODULE_5__.tz.guess(this.mzd['end']);
    console.log('time', time, 'offset', off, 'local', local);
  }

  updateAuction() {
    // let st : Date = new Date('2022-11-11T21:35:03.976+00:00')
    // let en : Date = new Date('2022-11-11T21:35:03.976+00:00')
    // this.mzd[0].descr = '7ghutyasdadas'
    // this.mzd[0].fee = 19990000
    // this.mzd[0].start = st
    // this.mzd[0].end = en
    // this.mzd[0].logs.push({
    //  "price":123123,
    //  "userId":"kejrhoqieurhoq",
    //  "date":en
    // })
    this.api.updateAuctions(this.mzd[0]).subscribe(data => {
      console.log('auction update', data);
      this.mzd = data['updatedLogAuction'];
      console.log(this.mzd); // update log and hiegst price and
      // animate heighst price and hand bidding
      //alert others by new price using socket.io for room
      // let res = data['auction'][0]
      // this.mzad = res
      // console.log('im here baby',this.mzad)
    }, err => {
      console.log(err);
    });
  }

  updateTerms() {
    let arr = {
      _id: this.mzd['_id'],
      terms: [{
        "descr": "loakajskdfhdlak",
        "orderId": 1
      }, {
        "userId": "loakajskdfhdlak",
        "status": 2
      }, {
        "userId": "loakajskdfhdlak",
        "status": 1
      }]
    };
    this.api.updateAuctionsLog(arr).subscribe(data => {
      console.log('auction update', data); // this.mzd = data['updatedLogAuction']
      // console.log(this.mzd)
    });
  }

};

LiveMzadPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ActionSheetController
}, {
  type: _angular_common__WEBPACK_IMPORTED_MODULE_9__.DatePipe
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController
}];

LiveMzadPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
  selector: 'app-live-mzad',
  template: _live_mzad_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_live_mzad_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], LiveMzadPage);


/***/ }),

/***/ 742:
/*!****************************************!*\
  !*** ./src/app/pipes/date-ago.pipe.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DateAgoPipe": () => (/* binding */ DateAgoPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ 56908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);



moment__WEBPACK_IMPORTED_MODULE_0__.locale("ar"); // set your language
let DateAgoPipe = class DateAgoPipe {
    constructor(changeDetectorRef, ngZone) {
        this.changeDetectorRef = changeDetectorRef;
        this.ngZone = ngZone;
    }
    transform(value) {
        this.removeTimer();
        let d = new Date(value);
        let now = new Date();
        let seconds = Math.round(Math.abs((now.getTime() - d.getTime()) / 1000));
        let timeToUpdate = (Number.isNaN(seconds)) ? 1000 : this.getSecondsUntilUpdate(seconds) * 1000;
        this.timer = this.ngZone.runOutsideAngular(() => {
            if (typeof window !== 'undefined') {
                return window.setTimeout(() => {
                    this.ngZone.run(() => this.changeDetectorRef.markForCheck());
                }, timeToUpdate);
            }
            return null;
        });
        return moment__WEBPACK_IMPORTED_MODULE_0__(d).fromNow();
    }
    ngOnDestroy() {
        this.removeTimer();
    }
    removeTimer() {
        if (this.timer) {
            window.clearTimeout(this.timer);
            this.timer = null;
        }
    }
    getSecondsUntilUpdate(seconds) {
        let min = 60;
        let hr = min * 60;
        let day = hr * 24;
        if (seconds < min) { // less than 1 min, update every 2 secs
            return 2;
        }
        else if (seconds < hr) { // less than an hour, update every 30 secs
            return 30;
        }
        else if (seconds < day) { // less then a day, update every 5 mins
            return 300;
        }
        else { // update every hour
            return 3600;
        }
    }
};
DateAgoPipe.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.ChangeDetectorRef },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone }
];
DateAgoPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'dateAgo',
        pure: true
    })
], DateAgoPipe);



/***/ }),

/***/ 48997:
/*!**********************************************************!*\
  !*** ./src/app/live-mzad/live-mzad.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = ".borderlightbot {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-light-shade);\n}\n\n.flex {\n  display: flex;\n}\n\n.borderbt {\n  border-bottom-style: solid;\n  border-bottom-width: 0.5px;\n}\n\n.pd10 {\n  padding-top: 10px;\n}\n\n.pb0 {\n  padding-bottom: 0px;\n}\n\n.imgContainer {\n  height: 200px;\n}\n\n.fixGadegtStyle2 {\n  background-color: var(--ion-color-dark-tint);\n  height: 100%;\n  position: absolute;\n  border-radius: 10px;\n  display: grid;\n  justify-content: center;\n  align-items: center;\n}\n\n.htx {\n  font-size: 2.5rem;\n  text-align: center;\n  color: var(--ion-color-primary-contrast);\n}\n\n.centerDiv {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.custH {\n  text-align: center;\n  width: 100%;\n}\n\n.lightItem {\n  --backgroun: var(--ion-color-light) ;\n}\n\n.white {\n  color: white;\n}\n\n.custGrid {\n  background-color: var(--ion-color-medium-shade);\n}\n\n.priceText {\n  color: white;\n  font-size: 16px;\n  font-weight: bold;\n}\n\n.po {\n  position: relative;\n}\n\n.fixGadegt {\n  position: absolute;\n  border-radius: 10px;\n  height: 80%;\n  display: grid;\n  justify-content: center;\n  align-items: center;\n}\n\n.colSpic {\n  margin-top: -50px;\n}\n\n.cardStatus {\n  position: absolute;\n  bottom: 0px;\n  background-image: linear-gradient(to right top, var(--ion-color-medium), var(--ion-color-light-shade));\n  border-radius: 10px;\n}\n\n.cardStatus2 {\n  width: 90%;\n  background-image: linear-gradient(to right top, var(--ion-color-medium), var(--ion-color-primary-shade));\n  border-radius: 10px;\n}\n\n.custImg {\n  width: 100%;\n  height: 100%;\n}\n\n.redBorder {\n  border-radius: 20px;\n  border-style: solid;\n  font-weight: bold;\n  text-align: center;\n  border-width: 0.5px;\n  border-color: var(--ion-color-danger);\n}\n\n.lightBorder {\n  border-color: var(--ion-color-light-shade);\n}\n\n.blueBorder {\n  border-radius: 20px;\n  border-style: solid;\n  font-weight: bold;\n  text-align: center;\n  border-width: 0.5px;\n  border-color: var(--ion-color-primary);\n}\n\n.childDiv {\n  position: relative;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.bidAnim {\n  position: fixed;\n  z-index: 1;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  top: 10%;\n  width: 100%;\n  opacity: 0.8;\n  height: 100%;\n}\n\n.animate__animated.animate__fadeOutUp {\n  --animate-duration: 2s;\n}\n\n.bidH {\n  width: 100%;\n  color: var(--ion-color-primary-contrast);\n  font-weight: bolder;\n  position: absolute;\n  top: 19%;\n  text-align: center;\n}\n\n.bidImg {\n  width: 100%;\n  height: 100%;\n}\n\n.paddind {\n  padding: 3px;\n}\n\n.bgc {\n  background-color: var(--ion-color-medium);\n}\n\n.timercol {\n  background-color: var(--ion-color-light-tint);\n  border-bottom-left-radius: 9px;\n  border-bottom-right-radius: 9px;\n}\n\n.footer {\n  border-style: solid;\n  border-width: 0.3px;\n  border-color: var(--ion-color-light-shade);\n  border-top-right-radius: 30px;\n  border-top-left-radius: 30px;\n}\n\n.bgContent {\n  --background:var(--ion-color-dark) ;\n}\n\n.roundedGrid {\n  border-bottom-left-radius: 50px;\n  border-bottom-right-radius: 50px;\n  padding-left: 10px;\n  padding-right: 10px;\n  background-color: var(--ion-color-primary-contrast);\n}\n\n.custItem {\n  --background: none;\n}\n\n.custAva {\n  border-style: solid;\n  border-width: 0.5px;\n  padding: 3px;\n  border-color: var(--ion-color-light);\n}\n\n.fotterStyle2 {\n  background-color: var(--ion-color-dark);\n}\n\n.btStyle2 {\n  border-style: solid;\n  border-color: var(--ion-color-dark);\n  background-color: var(--ion-color-primary-contrast);\n  border-radius: 2rem;\n  height: 84%;\n}\n\n.list {\n  background: transparent;\n}\n\n.detailCard {\n  background: var(--ion-color-dark-tint);\n}\n\n.cardCont {\n  color: var(--ion-color-primary-contrast);\n  font-size: 1.2rem;\n}\n\n.header-md::after {\n  background-image: none;\n}\n\n.custRow {\n  margin-top: 70%;\n  margin-left: 46%;\n}\n\n.footer-md::before {\n  background-image: none;\n}\n\n.totcol {\n  border-right-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-light-shade);\n}\n\n.table {\n  text-align: center;\n  width: 100%;\n  margin: 12px;\n}\n\ntr:nth-child(even) {\n  background-color: #dddddd;\n}\n\ntd, th {\n  border: 1px solid #dddddd;\n  text-align: center;\n  padding: 8px;\n  font-size: 16px;\n  font-weight: bold;\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpdmUtbXphZC5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXGh1c2FtJTIwcHJvalxcem9vZG9oYVNkXFxzcmNcXGFwcFxcbGl2ZS1temFkXFxsaXZlLW16YWQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDBDQUFBO0FDQ0o7O0FEQ0E7RUFBTSxhQUFBO0FDR047O0FEREE7RUFDSSwwQkFBQTtFQUNBLDBCQUFBO0FDSUo7O0FEQUE7RUFDRSxpQkFBQTtBQ0dGOztBREFBO0VBQ0csbUJBQUE7QUNHSDs7QUREQTtFQUNJLGFBQUE7QUNJSjs7QURGQTtFQUNJLDRDQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ0tKOztBREhBO0VBQ0ksaUJBQUE7RUFDQSxrQkFBQTtFQUNBLHdDQUFBO0FDTUo7O0FESEE7RUFDSSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ01KOztBREhBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0FDTUo7O0FESEE7RUFDQSxvQ0FBQTtBQ01BOztBREhBO0VBQ0ksWUFBQTtBQ01KOztBRERBO0VBQ0MsK0NBQUE7QUNJRDs7QURDQTtFQUNJLFlBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUNFSjs7QURDQTtFQUNJLGtCQUFBO0FDRUo7O0FERUE7RUFDSSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FDQ0o7O0FERUE7RUFDSSxpQkFBQTtBQ0NKOztBREVBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0Esc0dBQUE7RUFDQSxtQkFBQTtBQ0NKOztBREVBO0VBR0ksVUFBQTtFQUNBLHdHQUFBO0VBQ0EsbUJBQUE7QUNESjs7QURJQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDREE7O0FETUE7RUFDSSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EscUNBQUE7QUNISjs7QURNQTtFQUVJLDBDQUFBO0FDSko7O0FET0E7RUFDSSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Qsc0NBQUE7QUNKSDs7QURTQTtFQUNJLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNOSjs7QURVQTtFQUNJLGVBQUE7RUFDQSxVQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFFQSxRQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FDUko7O0FEV0E7RUFDSSxzQkFBQTtBQ1JKOztBRFdBO0VBQ0ksV0FBQTtFQUNBLHdDQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxrQkFBQTtBQ1JKOztBRFdBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNSQTs7QURXQTtFQUNJLFlBQUE7QUNSSjs7QURXQTtFQUNJLHlDQUFBO0FDUko7O0FEVUE7RUFDRyw2Q0FBQTtFQUNDLDhCQUFBO0VBQ0EsK0JBQUE7QUNQSjs7QURTQTtFQUNJLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQ0FBQTtFQUNBLDZCQUFBO0VBQ0EsNEJBQUE7QUNOSjs7QURRQTtFQUNJLG1DQUFBO0FDTEo7O0FET0E7RUFDSSwrQkFBQTtFQUNBLGdDQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLG1EQUFBO0FDSko7O0FET0E7RUFDSSxrQkFBQTtBQ0pKOztBRFFBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxvQ0FBQTtBQ0xKOztBRFNBO0VBQ0ksdUNBQUE7QUNOSjs7QURRQTtFQUNJLG1CQUFBO0VBQ0EsbUNBQUE7RUFDQSxtREFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQ0xKOztBRE9BO0VBQ0ksdUJBQUE7QUNKSjs7QURNQTtFQUNJLHNDQUFBO0FDSEo7O0FETUE7RUFDSSx3Q0FBQTtFQUNBLGlCQUFBO0FDSEo7O0FEUUE7RUFDSSxzQkFBQTtBQ0xKOztBRFFBO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0FDTEo7O0FEUUE7RUFDSSxzQkFBQTtBQ0xKOztBRFFBO0VBQ0kseUJBQUE7RUFDQSxtQkFBQTtFQUNBLDBDQUFBO0FDTEo7O0FEU0E7RUFBTyxrQkFBQTtFQUFtQixXQUFBO0VBQWEsWUFBQTtBQ0h2Qzs7QURLRTtFQUFvQix5QkFBQTtBQ0R0Qjs7QURHRTtFQUFRLHlCQUFBO0VBQTBCLGtCQUFBO0VBQW1CLFlBQUE7RUFBYyxlQUFBO0VBQWdCLGlCQUFBO0VBQWtCLFlBQUE7QUNNdkciLCJmaWxlIjoibGl2ZS1temFkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ib3JkZXJsaWdodGJvdHtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IC41cHg7XHJcbiAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XHJcbn1cclxuLmZsZXh7ZGlzcGxheTogZmxleDt9XHJcblxyXG4uYm9yZGVyYnR7XHJcbiAgICBib3JkZXItYm90dG9tLXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci1ib3R0b20td2lkdGg6IC41cHg7XHJcbiAgIFxyXG59XHJcblxyXG4ucGQxMHtcclxuICBwYWRkaW5nLXRvcDogMTBweDtcclxufVxyXG5cclxuLnBiMHtcclxuICAgcGFkZGluZy1ib3R0b206IDBweDtcclxufVxyXG4uaW1nQ29udGFpbmVye1xyXG4gICAgaGVpZ2h0OiAyMDBweDtcclxufVxyXG4uZml4R2FkZWd0U3R5bGUye1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmstdGludCk7XHJcbiAgICBoZWlnaHQ6IDEwMCU7IFxyXG4gICAgcG9zaXRpb246YWJzb2x1dGU7IFxyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDsgXHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcbi5odHh7XHJcbiAgICBmb250LXNpemU6IDIuNXJlbTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XHJcbiAgIH1cclxuXHJcbi5jZW50ZXJEaXYge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICB9XHJcblxyXG4uY3VzdEh7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuLmxpZ2h0SXRlbXtcclxuLS1iYWNrZ3JvdW4gOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpXHJcbn1cclxuXHJcbi53aGl0ZXtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuXHJcblxyXG4uY3VzdEdyaWR7XHJcbiBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXNoYWRlKTtcclxufVxyXG5cclxuXHJcblxyXG4ucHJpY2VUZXh0e1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcbi5wb3tcclxuICAgIHBvc2l0aW9uOnJlbGF0aXZlOyAgXHJcbn1cclxuXHJcblxyXG4uZml4R2FkZWd0e1xyXG4gICAgcG9zaXRpb246YWJzb2x1dGU7IFxyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGhlaWdodDogODAlO1xyXG4gICAgZGlzcGxheTogZ3JpZDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLmNvbFNwaWN7XHJcbiAgICBtYXJnaW4tdG9wOiAtNTBweDtcclxufVxyXG5cclxuLmNhcmRTdGF0dXN7XHJcbiAgICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICAgIGJvdHRvbTogMHB4OyBcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCB0b3AsIHZhcigtLWlvbi1jb2xvci1tZWRpdW0pLCB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbn1cclxuXHJcbi5jYXJkU3RhdHVzMntcclxuICAgIC8vIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gICAgLy8gYm90dG9tOiAwcHg7XHJcbiAgICB3aWR0aDogOTAlO1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0IHRvcCwgdmFyKC0taW9uLWNvbG9yLW1lZGl1bSksIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXNoYWRlKSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG59XHJcblxyXG4uY3VzdEltZ3tcclxud2lkdGg6IDEwMCU7XHJcbmhlaWdodDogMTAwJTtcclxufVxyXG5cclxuXHJcblxyXG4ucmVkQm9yZGVye1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7IFxyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7IFxyXG4gICAgYm9yZGVyLXdpZHRoOiAwLjVweDsgXHJcbiAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYW5nZXIpO1xyXG59XHJcblxyXG4ubGlnaHRCb3JkZXJ7XHJcbiAgXHJcbiAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XHJcbn1cclxuXHJcbi5ibHVlQm9yZGVye1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7IFxyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7IFxyXG4gICAgYm9yZGVyLXdpZHRoOiAwLjVweDsgXHJcbiAgIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG59XHJcblxyXG5cclxuXHJcbi5jaGlsZERpdntcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcblxyXG4uYmlkQW5pbXtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogIGNlbnRlcjtcclxuICAgIC8vYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0IHRvcCwgdmFyKC0taW9uLWNvbG9yLW1lZGl1bSksIHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSkpO1xyXG4gICAgdG9wOiAxMCU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG9wYWNpdHk6IDAuODtcclxuICAgIGhlaWdodDogMTAwJTtcclxufSBcclxuXHJcbi5hbmltYXRlX19hbmltYXRlZC5hbmltYXRlX19mYWRlT3V0VXB7XHJcbiAgICAtLWFuaW1hdGUtZHVyYXRpb246IDJzO1xyXG59XHJcblxyXG4uYmlkSHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkZXI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDE5JTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLmJpZEltZ3tcclxud2lkdGg6IDEwMCU7XHJcbmhlaWdodDogMTAwJTtcclxufVxyXG5cclxuLnBhZGRpbmR7XHJcbiAgICBwYWRkaW5nOiAzcHg7XHJcbn1cclxuXHJcbi5iZ2N7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcclxufVxyXG4udGltZXJjb2x7XHJcbiAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC10aW50KTtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDlweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA5cHg7XHJcbn1cclxuLmZvb3RlcntcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IDAuM3B4O1xyXG4gICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpO1xyXG4gICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDMwcHg7XHJcbiAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAzMHB4O1xyXG59XHJcbi5iZ0NvbnRlbnR7XHJcbiAgICAtLWJhY2tncm91bmQ6dmFyKC0taW9uLWNvbG9yLWRhcmspIDtcclxuICB9XHJcbi5yb3VuZGVkR3JpZHsgXHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1MHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDUwcHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xyXG4gICB9XHJcblxyXG4uY3VzdEl0ZW17XHJcbiAgICAtLWJhY2tncm91bmQ6IG5vbmU7XHJcbn1cclxuXHJcblxyXG4uY3VzdEF2YXtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IDAuNXB4O1xyXG4gICAgcGFkZGluZzogM3B4O1xyXG4gICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG59XHJcblxyXG5cclxuLmZvdHRlclN0eWxlMntcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAgfVxyXG4uYnRTdHlsZTJ7XHJcbiAgICBib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAycmVtOyBcclxuICAgIGhlaWdodDogODQlO1xyXG4gICB9XHJcbi5saXN0e1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbn1cclxuLmRldGFpbENhcmR7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZGFyay10aW50KTtcclxuICAgIFxyXG59XHJcbi5jYXJkQ29udHtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XHJcbiAgICBmb250LXNpemU6IDEuMnJlbTtcclxufVxyXG5cclxuXHJcblxyXG4uaGVhZGVyLW1kOjphZnRlciB7IFxyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTsgXHJcbiAgfVxyXG4gXHJcbi5jdXN0Um93e1xyXG4gICAgbWFyZ2luLXRvcDogNzAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDQ2JTtcclxufVxyXG5cclxuLmZvb3Rlci1tZDo6YmVmb3Jle1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogIG5vbmU7XHJcbn1cclxuXHJcbi50b3Rjb2x7XHJcbiAgICBib3JkZXItcmlnaHQtc3R5bGU6IHNvbGlkO1xyXG4gICAgYm9yZGVyLXdpZHRoOiAwLjVweDtcclxuICAgIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlKTtcclxufVxyXG5cclxuXHJcbi50YWJsZXt0ZXh0LWFsaWduOiBjZW50ZXI7d2lkdGg6IDEwMCU7IG1hcmdpbjogMTJweDt9XHJcblxyXG4gIHRyOm50aC1jaGlsZChldmVuKSB7YmFja2dyb3VuZC1jb2xvcjogI2RkZGRkZDt9XHJcbiAgXHJcbiAgdGQsIHRoIHtib3JkZXI6IDFweCBzb2xpZCAjZGRkZGRkO3RleHQtYWxpZ246IGNlbnRlcjtwYWRkaW5nOiA4cHg7IGZvbnQtc2l6ZTogMTZweDtmb250LXdlaWdodDogYm9sZDtjb2xvcjogYmxhY2s7fSIsIi5ib3JkZXJsaWdodGJvdCB7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGJvcmRlci13aWR0aDogMC41cHg7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlKTtcbn1cblxuLmZsZXgge1xuICBkaXNwbGF5OiBmbGV4O1xufVxuXG4uYm9yZGVyYnQge1xuICBib3JkZXItYm90dG9tLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLWJvdHRvbS13aWR0aDogMC41cHg7XG59XG5cbi5wZDEwIHtcbiAgcGFkZGluZy10b3A6IDEwcHg7XG59XG5cbi5wYjAge1xuICBwYWRkaW5nLWJvdHRvbTogMHB4O1xufVxuXG4uaW1nQ29udGFpbmVyIHtcbiAgaGVpZ2h0OiAyMDBweDtcbn1cblxuLmZpeEdhZGVndFN0eWxlMiB7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrLXRpbnQpO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgZGlzcGxheTogZ3JpZDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5odHgge1xuICBmb250LXNpemU6IDIuNXJlbTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xufVxuXG4uY2VudGVyRGl2IHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5jdXN0SCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5saWdodEl0ZW0ge1xuICAtLWJhY2tncm91bjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KSA7XG59XG5cbi53aGl0ZSB7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmN1c3RHcmlkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XG59XG5cbi5wcmljZVRleHQge1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi5wbyB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLmZpeEdhZGVndCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgaGVpZ2h0OiA4MCU7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uY29sU3BpYyB7XG4gIG1hcmdpbi10b3A6IC01MHB4O1xufVxuXG4uY2FyZFN0YXR1cyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAwcHg7XG4gIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCB0b3AsIHZhcigtLWlvbi1jb2xvci1tZWRpdW0pLCB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpKTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cblxuLmNhcmRTdGF0dXMyIHtcbiAgd2lkdGg6IDkwJTtcbiAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0IHRvcCwgdmFyKC0taW9uLWNvbG9yLW1lZGl1bSksIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXNoYWRlKSk7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5cbi5jdXN0SW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLnJlZEJvcmRlciB7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci13aWR0aDogMC41cHg7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhbmdlcik7XG59XG5cbi5saWdodEJvcmRlciB7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlKTtcbn1cblxuLmJsdWVCb3JkZXIge1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItd2lkdGg6IDAuNXB4O1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuLmNoaWxkRGl2IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmJpZEFuaW0ge1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHotaW5kZXg6IDE7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICB0b3A6IDEwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIG9wYWNpdHk6IDAuODtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uYW5pbWF0ZV9fYW5pbWF0ZWQuYW5pbWF0ZV9fZmFkZU91dFVwIHtcbiAgLS1hbmltYXRlLWR1cmF0aW9uOiAycztcbn1cblxuLmJpZEgge1xuICB3aWR0aDogMTAwJTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcbiAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDE5JTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uYmlkSW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLnBhZGRpbmQge1xuICBwYWRkaW5nOiAzcHg7XG59XG5cbi5iZ2Mge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbn1cblxuLnRpbWVyY29sIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXRpbnQpO1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA5cHg7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA5cHg7XG59XG5cbi5mb290ZXIge1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBib3JkZXItd2lkdGg6IDAuM3B4O1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAzMHB4O1xuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAzMHB4O1xufVxuXG4uYmdDb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOnZhcigtLWlvbi1jb2xvci1kYXJrKSA7XG59XG5cbi5yb3VuZGVkR3JpZCB7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDUwcHg7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1MHB4O1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcbn1cblxuLmN1c3RJdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiBub25lO1xufVxuXG4uY3VzdEF2YSB7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGJvcmRlci13aWR0aDogMC41cHg7XG4gIHBhZGRpbmc6IDNweDtcbiAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xufVxuXG4uZm90dGVyU3R5bGUyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xufVxuXG4uYnRTdHlsZTIge1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xuICBib3JkZXItcmFkaXVzOiAycmVtO1xuICBoZWlnaHQ6IDg0JTtcbn1cblxuLmxpc3Qge1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cblxuLmRldGFpbENhcmQge1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZGFyay10aW50KTtcbn1cblxuLmNhcmRDb250IHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcbiAgZm9udC1zaXplOiAxLjJyZW07XG59XG5cbi5oZWFkZXItbWQ6OmFmdGVyIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn1cblxuLmN1c3RSb3cge1xuICBtYXJnaW4tdG9wOiA3MCU7XG4gIG1hcmdpbi1sZWZ0OiA0NiU7XG59XG5cbi5mb290ZXItbWQ6OmJlZm9yZSB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmU7XG59XG5cbi50b3Rjb2wge1xuICBib3JkZXItcmlnaHQtc3R5bGU6IHNvbGlkO1xuICBib3JkZXItd2lkdGg6IDAuNXB4O1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XG59XG5cbi50YWJsZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgd2lkdGg6IDEwMCU7XG4gIG1hcmdpbjogMTJweDtcbn1cblxudHI6bnRoLWNoaWxkKGV2ZW4pIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2RkZGRkZDtcbn1cblxudGQsIHRoIHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2RkZGRkZDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiA4cHg7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGNvbG9yOiBibGFjaztcbn0iXX0= */";

/***/ }),

/***/ 47443:
/*!**********************************************************!*\
  !*** ./src/app/live-mzad/live-mzad.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar dir=\"rtl\">\n    <ion-buttons slot=\"end\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>\n      <ion-icon name=\"radio-outline\" ></ion-icon>  \n      البث الحي\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content  *ngIf= \"style == 'style1'\">\n  <ion-grid *ngIf=\"!mzd && errorLoad == false\"  class=\"custGrid\"> \n    <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n      <ion-col size=\"12\" class=\"ion-text-center\">\n        <!-- *ngIf=\"spinner == true\" -->\n        <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n      </ion-col>\n      <ion-col size=\"12\">\n        <!-- *ngIf=\"spinner == true\" --> \n      </ion-col>\n    </ion-row> \n  </ion-grid>\n\n  <ion-grid *ngIf=\"errorLoad == true\" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n  </ion-grid>\n \n  \n\n\n\n\n\n<ion-grid class=\"ion-no-margin  ion-no-padding\"  dir=\"rtl\" >  \n    <!--  -->\n    <!--animation of bidding  -->\n    <div class=\"bidAnim \"*ngIf=\"showMe == true\">\n      <div class=\"childDiv animate__animated animate__fadeOutUp animate__delay-0s\">\n        <img class=\"bidImg\" src=\"../../assets/imgs/bidprimary.png\"/> \n        <h2 class=\"bidH\">{{bidPrice}}</h2>\n      </div>\n    </div>\n\n    <ion-row class=\"ion-no-margin  ion-no-padding po\" *ngIf=\"mzd\"> \n      <ion-col size=\"12\" class=\"ion-no-margin imgContainer\"> \n        <img class=\"radus5 custImg\" [src]=\"mzd['imgs'][0]\"/>  \n      </ion-col>     \n \n      <div class=\"fixGadegt\" style=\"background-color: #190b0b27; height: 90%;\">\n        <ion-grid class=\"ion-no-margin pd10 \" dir=\"rtl\">\n          <ion-row>\n            <ion-col class=\"ion-text-center\">\n              <ion-card-content class=\"ion-no-padding pd10\">\n                <ion-text class=\"priceText\"> {{+mzd['productPrice'] - (0.3 * +mzd['productPrice'])}} </ion-text><br>\n                <!-- <ion-text  class=\"white\"> ج.س</ion-text> -->\n                <ion-text class=\"white\"><b> السعر الإفتتاحي</b> </ion-text>\n              </ion-card-content>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n\n\n        <ion-grid class=\"ion-no-margin  ion-no-padding \" dir=\"rtl\">\n          <!-- <ion-row class=\"ion-no-margin  ion-no-padding\"> \n                  </ion-row> -->\n          <ion-row>\n            <ion-col class=\"ion-text-center\">\n              <ion-card-content class=\"ion-no-padding pd10\" [ngClass]=\"{'ion-no-padding pd10 animate__animated animate__zoomIn':showMe == true , 'ion-no-padding pd10':showMe == false}\">\n                <ion-text  class=\"priceText\"> {{highestBidd}} </ion-text><br>\n                <!-- <ion-text  class=\"white\"> ج.س</ion-text>  -->\n                <ion-text class=\"white\"><b>أعلي مزايدة</b> </ion-text>\n              </ion-card-content>\n            </ion-col>\n          </ion-row> \n        </ion-grid>\n      \n        <!-- <ion-grid class=\"ion-no-margin  ion-no-padding \" dir=\"rtl\">\n          <ion-row>\n            <ion-col class=\"ion-text-center\">\n              <ion-card-content class=\"ion-no-padding pd10\">\n                <ion-text class=\"priceText\"> {{lastBidd4U}} </ion-text> <br>\n               \n                <ion-text class=\"white\"><b>اخر مزايدة لك</b> </ion-text>\n              </ion-card-content>\n            </ion-col>\n          </ion-row> \n        </ion-grid> -->\n\n        <ion-grid class=\"ion-no-margin  ion-no-padding \" dir=\"rtl\">\n          <ion-row>\n            <ion-col class=\"ion-text-center\">\n              <ion-card-content class=\"ion-no-padding pd10\">\n                <ion-text class=\"priceText\"> {{availRounds}} </ion-text> <br>\n                <!-- <ion-text  class=\"white\"> ج.س</ion-text>  -->\n                <ion-text class=\"white\"><b> مزايداتك المتبقية </b> </ion-text>\n              </ion-card-content>\n            </ion-col>\n          </ion-row> \n        </ion-grid>\n      \n        <!-- <ion-grid class=\"ion-no-margin  ion-no-padding \" dir=\"rtl\">\n          <ion-row>\n            <ion-col class=\"ion-text-center\">\n              <ion-card-content class=\"ion-no-padding pd10\">\n                <ion-text class=\"priceText\"> 3 </ion-text>\n                <ion-text class=\"white\"> من </ion-text>\n                <ion-text class=\"priceText\"> 3</ion-text><br>\n                <ion-text class=\"white\"><b>مزايداتك المتبقية</b> </ion-text>\n              </ion-card-content>\n            </ion-col>\n          </ion-row>\n        </ion-grid> -->\n      </div> \n    </ion-row> \n\n   \n\n    <ion-row class=\"ion-no-padding\" *ngIf=\"mzd\"> \n      <!-- <ion-col size=\"12\" class=\"colSpic\" *ngIf=\"mzd['end']\"> -->\n        <!-- timeLine  -->\n        <!-- <ion-card class=\"cardStatus2\" *ngIf=\"timeLeft | async as tm\"> \n          <ion-grid>\n            <ion-row> \n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\" >{{tm['da'] }}  </ion-text> <br>\n                  <ion-text class=\"white\"><b> يوم</b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\"> {{tm['hr'] }} </ion-text> <br>\n                  <ion-text class=\"white\"><b> ساعة </b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\">  {{tm['mn'] }} </ion-text> <br>\n                  <ion-text class=\"white\"><b> دقيقة </b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\"> {{tm['sc'] }}  </ion-text> <br>\n                  <ion-text class=\"white\"><b> ثانية </b> </ion-text>\n                </ion-card-content>\n              </ion-col> \n            </ion-row> \n          </ion-grid>\n        </ion-card>   -->\n      <!-- </ion-col> -->\n      <!-- <ion-col size=\"12\"  class=\"borderbt\">\n        <ion-card-header> \n          <ion-card-title>مارسيدس مايباخ 2021</ion-card-title>\n        </ion-card-header> \n        <ion-card-content>\n          تعلن شركة زد للمزادات العقارية عن البيع بالمزاد العلني لمجموعة من العقارات المتنوعة تحت إشراف مركز الاسناد والتصفية «إنفاذ» وبقرار من محكمة التنفيذ\n        </ion-card-content>\n      </ion-col>  -->\n      <!-- <ion-card class=\"w100\"> \n        <ion-card-header>  \n            <ion-card-title>\n              <ion-icon name=\"radio-outline\" color=\"primary\"></ion-icon> \n              الحالة\n            </ion-card-title>\n          </ion-card-header>\n          <ion-grid class=\"ion-no-margin  ion-no-padding ion-padding-bottom\" dir=\"rtl\">\n            <ion-row class=\"ion-no-margin  ion-no-padding\"> \n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                    <ion-text color=\"primary\"><b>أعلي مزايدة</b> </ion-text><br> \n                    <ion-text> 3000 </ion-text>\n                    <ion-text> ج.س</ion-text> \n                  </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                    <ion-text color=\"primary\"><b>اخر مزايدة لك</b> </ion-text><br> \n                    <ion-text> 0 </ion-text>\n                    <ion-text> ج.س</ion-text> \n                  </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content class=\"ion-no-padding ion-padding-top\">  \n                      <ion-text color=\"primary\"><b>مزايداتك المتبقية</b> </ion-text><br> \n                       <ion-text> 3 </ion-text> \n                       <ion-text>  من </ion-text>  \n                       <ion-text>  3</ion-text>  \n                </ion-card-content>\n              </ion-col>\n            </ion-row>\n          </ion-grid> \n      </ion-card>  -->\n    \n\n      <!-- <ion-card class=\"w100 \">\n        <ion-card-header>\n          <ion-card-title>\n            <ion-icon name=\"bookmark-outline\" color=\"primary\"></ion-icon> \n          المشاركين \n          </ion-card-title> \n        </ion-card-header>\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\" >\n              <ion-item *ngFor=\"let per of mazad.users\"> \n                <ion-avatar>\n                  <ion-icon name=\"person\" slot=\"start\"></ion-icon>\n                </ion-avatar>\n                <ion-label>{{per.firstName}}</ion-label>\n              </ion-item>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </ion-card>  -->\n\n      <!-- timing and mzd detail  -->\n      <ion-col size=\"12\">\n        <ion-card-header class=\"pb0\"> \n          <ion-card-title> {{ mzd['title'] }}  </ion-card-title>\n          <ion-label>\n            {{mzd['shortDescr']}}\n          </ion-label>\n          <ion-label *ngIf=\"showMore == false\">{{tirmString(mzd['descr'] ,0)}}\n            <ion-text><ion-button fill=\"clear\" size=\"small\" (click)=\"showMore = true \">المزيد</ion-button></ion-text>\n          </ion-label>\n          <ion-label *ngIf=\"showMore == true\">\n            {{mzd['descr']}}\n            <ion-text><ion-button fill=\"clear\" size=\"small\" (click)=\"showMore = false \">اقل</ion-button></ion-text>\n          </ion-label>\n        </ion-card-header> \n        <!-- timing -->\n        <ion-card class=\"cardStatus2\" *ngIf=\"timeLeft | async as tm\"> \n          <ion-grid>\n            <ion-row> \n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\" >{{tm['da'] }}  </ion-text> <br>\n                  <ion-text class=\"white\"><b> يوم</b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\"> {{tm['hr'] }} </ion-text> <br>\n                  <ion-text class=\"white\"><b> ساعة </b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\">  {{tm['mn'] }} </ion-text> <br>\n                  <ion-text class=\"white\"><b> دقيقة </b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\"> {{tm['sc'] }}  </ion-text> <br>\n                  <ion-text class=\"white\"><b> ثانية </b> </ion-text>\n                </ion-card-content>\n              </ion-col> \n            </ion-row> \n          </ion-grid>\n        </ion-card>\n      </ion-col>\n\n\n       \n\n   <!-- history log  -->\n   <ion-card class=\"w100\">\n    <ion-card-header class=\"pb0\">  \n      <ion-card-title>\n        <ion-icon name=\"time-outline\" color=\"primary\"></ion-icon>\n        المزايدات \n        <!-- <h2 *ngIf=\"time$ | async as time\" >\n          {{time | date:'h:mm:ss'}}\n        </h2>     -->\n      </ion-card-title>\n    </ion-card-header>\n    <ion-grid *ngIf=\"emptyLog == false\">\n      <ion-list  class=\"ion-no-padding\">\n      <ion-item *ngFor=\"let log of usersLogs\">\n        <ion-avatar>\n          <ion-img *ngIf=\"log.imgUrl == ''\"  src=\"../../assets/imgs/bid.png\"></ion-img>\n          <ion-img *ngIf=\"log.imgUrl.length>0\"  [src]=\"log.imgUrl\"></ion-img>\n        </ion-avatar>\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\">\n              <ion-grid>\n                <ion-row>\n                  <ion-col size=\"12\">\n                   <ion-item lines=\"none\">\n                    <ion-label>{{log.fullName}}</ion-label>\n                   </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-label> \n                      <ion-text>{{log.time | dateAgo}} </ion-text> <ion-text>{{log.time | date:'EEE dd-MM' : undefined  : 'ar' }} </ion-text> \n                      </ion-label>\n                  </ion-col> \n                </ion-row>\n              </ion-grid>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n       <ion-badge slot=\"end\">\n        <ion-label><ion-text>{{log.pay}}</ion-text></ion-label>  \n       </ion-badge>\n      </ion-item>\n\n      <ion-item *ngIf=\"mzd['logs'].length > 2\" button (click)=\"viewMoreLess()\" lines=\"none\" class=\"lightItem lightBorder\">\n         <h4 class=\"custH\">\n          <ion-label *ngIf=\"view == 0\">\n            <ion-note >المزيد</ion-note><br>\n            <ion-icon name=\"chevron-down-outline\" color=\"primary\"></ion-icon>\n          </ion-label>\n          <ion-label *ngIf=\"view == 1\">\n            <ion-note >اقل</ion-note><br>\n            <ion-icon   name=\"chevron-up-outline\" color=\"primary\"></ion-icon> \n          </ion-label> \n         </h4> \n      </ion-item> \n\n    </ion-list>\n    </ion-grid>\n\n\n      <ion-grid *ngIf=\"emptyLog == true\">\n        <ion-row>\n          <ion-col size=\"12\"> \n               <div class=\"w100 centerDiv\"><ion-thumbnail><ion-img src=\"../../assets/imgs/bid.png\"></ion-img></ion-thumbnail>  </div>  \n          </ion-col>\n          <ion-col size=\"12\" >  \n            <div  class=\"w100 centerDiv\" ><h2> كن اول من يضع مزايدة  </h2></div> \n          </ion-col>\n        </ion-row>\n       </ion-grid>\n    </ion-card> \n\n\n      <!-- fees  -->\n      <ion-card class=\"w100\" *ngIf=\"mzd\"> \n        <ion-card-header class=\"pb0\">  \n            <ion-card-title>\n               <ion-icon name=\"cash-outline\" color=\"primary\"></ion-icon>\n              رسوم المشاركة\n            </ion-card-title>\n          </ion-card-header>\n          <ion-grid class=\"ion-no-margin  ion-no-padding ion-padding-bottom\" dir=\"rtl\">\n            <!-- <ion-row class=\"ion-no-margin  ion-no-padding\">\n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item>\n                  <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item>\n                  <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n                </ion-item>\n              </ion-col>\n            </ion-row> -->\n          </ion-grid>\n          <ion-grid class=\"ion-no-margin  ion-no-padding ion-padding-bottom\" dir=\"rtl\">\n            <ion-row class=\"ion-no-margin  ion-no-padding\"> \n              <ion-col size=\"4\" class=\"ion-text-center\">\n                <ion-card-content> \n                    <ion-text color=\"primary\"><b>العربون</b> </ion-text><br> \n                    <ion-text> {{mzd['deposit']}} </ion-text>\n                    <ion-text> ج.س</ion-text> \n                  </ion-card-content>\n              </ion-col>\n              <ion-col size=\"4\" class=\"ion-text-center\">\n                <ion-card-content>  \n                      <ion-text color=\"primary\"><b>رسوم دفتر </b> </ion-text><br> \n                       <ion-text> {{mzd['fee']}} </ion-text> \n                       <ion-text>   ج.س</ion-text>  \n                </ion-card-content>\n              </ion-col>\n\n              <ion-col size=\"4\" class=\"ion-text-center totcol\">\n                <ion-card-content> \n                  <ion-text color=\"primary\"><b>المجموع </b>  </ion-text><br>\n                  <ion-text>  {{mzd['deposit'] + mzd['fee']}}  </ion-text>\n                  <ion-text>   ج.س</ion-text> \n                </ion-card-content>\n              </ion-col>\n            </ion-row>\n          </ion-grid> \n      </ion-card> \n      <!-- terms -->\n\n      <ion-card class=\"w100 \">\n        <ion-card-header class=\"pb0\">\n          <ion-card-title>\n            <ion-icon name=\"bookmark-outline\" color=\"primary\"></ion-icon> \n            بنود المزاد\n          </ion-card-title> \n        </ion-card-header>\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\" >\n              <ion-card-content> \n                <ion-label *ngFor=\"let term of termsArr\">\n                  <ion-icon name=\"pin\" color=\"primary\"></ion-icon>\n                  <ion-text>{{term.desc}}</ion-text><br>\n                 </ion-label> \n              </ion-card-content>\n            </ion-col>\n          </ion-row>\n          <ion-row  class=\"ion-justify-content-center\">\n            <ion-item  button (click)=\"viewMoreLessTerms()\" lines=\"none\" class=\"lightItem lightBorder\">\n              <h4 class=\"custH\">\n               <ion-label *ngIf=\"viewTerms == 0\">\n                 <ion-note >المزيد</ion-note><br>\n                 <ion-icon name=\"chevron-down-outline\" color=\"primary\"></ion-icon>\n               </ion-label>\n               <ion-label *ngIf=\"viewTerms == 1\">\n                 <ion-note >اقل</ion-note><br>\n                 <ion-icon   name=\"chevron-up-outline\" color=\"primary\"></ion-icon> \n               </ion-label> \n              </h4> \n           </ion-item>\n          </ion-row>\n          \n        </ion-grid>\n      </ion-card>\n\n    </ion-row>\n\n</ion-grid>\n</ion-content> \n\n<ion-content  *ngIf= \"style == 'style2'\"   class=\"bgContent\" >\n  <ion-grid *ngIf=\"!mzd && errorLoad == false\"  class=\"custGrid\"> \n    <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n      <ion-col size=\"12\" class=\"ion-text-center\">\n        <!-- *ngIf=\"spinner == true\" -->\n        <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n      </ion-col>\n      <ion-col size=\"12\">\n        <!-- *ngIf=\"spinner == true\" --> \n      </ion-col>\n    </ion-row> \n  </ion-grid>\n\n  <ion-grid *ngIf=\"errorLoad == true\" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n  </ion-grid>\n \n  \n\n\n\n\n\n<ion-grid class=\"ion-no-margin  roundedGrid\"  dir=\"rtl\" >  \n    <!--  -->\n    <!--animation of bidding  -->\n    <div class=\"bidAnim \"*ngIf=\"showMe == true\">\n      <div class=\"childDiv animate__animated animate__fadeOutUp animate__delay-0s\">\n        <img class=\"bidImg\" src=\"../../assets/imgs/bidprimary.png\"/> \n        <h2 class=\"bidH\">{{bidPrice}}</h2>\n      </div>\n    </div>\n\n    <ion-row class=\"ion-no-margin  ion-no-padding \" *ngIf=\"mzd\"> \n        \n      <ion-col size=\"4\" class=\"ion-no-margin imgContainer\"> \n        <div class=\"fixGadegtStyle2\">\n          <ion-grid class=\"ion-no-margin pd10 \" dir=\"rtl\">\n            <ion-row>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content class=\"ion-no-padding pd10\">\n                  <ion-text class=\"priceText\"> {{+mzd['productPrice'] - (0.3 * +mzd['productPrice'])}} </ion-text><br>\n                  <!-- <ion-text  class=\"white\"> ج.س</ion-text> -->\n                  <ion-text class=\"white\"><b> السعر الإفتتاحي</b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n  \n  \n          <ion-grid class=\"ion-no-margin  ion-no-padding \" dir=\"rtl\">\n            <!-- <ion-row class=\"ion-no-margin  ion-no-padding\"> \n                    </ion-row> -->\n            <ion-row>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content class=\"ion-no-padding pd10\" [ngClass]=\"{'ion-no-padding pd10 animate__animated animate__zoomIn':showMe == true , 'ion-no-padding pd10':showMe == false}\">\n                  <ion-text  class=\"priceText\"> {{highestBidd}} </ion-text><br>\n                  <!-- <ion-text  class=\"white\"> ج.س</ion-text>  -->\n                  <ion-text class=\"white\"><b>أعلي مزايدة</b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n            </ion-row> \n          </ion-grid>\n        \n          <!-- <ion-grid class=\"ion-no-margin  ion-no-padding \" dir=\"rtl\">\n            <ion-row>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content class=\"ion-no-padding pd10\">\n                  <ion-text class=\"priceText\"> {{lastBidd4U}} </ion-text> <br>\n                 \n                  <ion-text class=\"white\"><b>اخر مزايدة لك</b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n            </ion-row> \n          </ion-grid> -->\n  \n          <ion-grid class=\"ion-no-margin  ion-no-padding \" dir=\"rtl\">\n            <ion-row>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content class=\"ion-no-padding pd10\">\n                  <ion-text class=\"priceText\"> {{availRounds}} </ion-text> <br>\n                  <!-- <ion-text  class=\"white\"> ج.س</ion-text>  -->\n                  <ion-text class=\"white\"><b> مزايداتك المتبقية </b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n            </ion-row> \n          </ion-grid>\n        \n          <!-- <ion-grid class=\"ion-no-margin  ion-no-padding \" dir=\"rtl\">\n            <ion-row>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content class=\"ion-no-padding pd10\">\n                  <ion-text class=\"priceText\"> 3 </ion-text>\n                  <ion-text class=\"white\"> من </ion-text>\n                  <ion-text class=\"priceText\"> 3</ion-text><br>\n                  <ion-text class=\"white\"><b>مزايداتك المتبقية</b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n            </ion-row>\n          </ion-grid> -->\n        </div> \n      </ion-col>  \n      <ion-col size=\"8\" class=\"ion-no-margin imgContainer\"> \n        <img class=\"radus5 custImg\" [src]=\"mzd['imgs'][0]\"/>  \n      </ion-col>  \n    </ion-row> \n    <ion-row class=\"ion-margin-top\" *ngIf=\"mzd\">\n      <ion-col size=\"12\">\n        <ion-card-header class=\"pb0\"> \n          <ion-card-title> {{ mzd['title'] }}  </ion-card-title>\n          <ion-label>\n            {{mzd['shortDescr']}}\n          </ion-label>\n          <ion-label *ngIf=\"showMore == false\">{{tirmString(mzd['descr'] ,0)}}\n            <ion-text><ion-button fill=\"clear\" size=\"small\" (click)=\"showMore = true \">المزيد</ion-button></ion-text>\n          </ion-label>\n          <ion-label *ngIf=\"showMore == true\">\n            {{mzd['descr']}}\n            <ion-text><ion-button fill=\"clear\" size=\"small\" (click)=\"showMore = false \">اقل</ion-button></ion-text>\n          </ion-label>\n        </ion-card-header>\n        </ion-col>\n    </ion-row>\n\n</ion-grid>\n   <ion-grid dir=\"rtl\">\n    <ion-row class=\"ion-no-padding\" *ngIf=\"mzd\">  \n      <!-- timing and mzd detail  -->\n      <ion-col size=\"12\">\n       \n        <!-- timing -->\n       \n          <!-- <ion-grid *ngIf=\"timeLeft | async as tm\">\n            <ion-row> \n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\" >{{tm['da'] }}  </ion-text> <br>\n                  <ion-text class=\"white\"><b> يوم</b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\"> {{tm['hr'] }} </ion-text> <br>\n                  <ion-text class=\"white\"><b> ساعة </b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\">  {{tm['mn'] }} </ion-text> <br>\n                  <ion-text class=\"white\"><b> دقيقة </b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\"> {{tm['sc'] }}  </ion-text> <br>\n                  <ion-text class=\"white\"><b> ثانية </b> </ion-text>\n                </ion-card-content>\n              </ion-col> \n            </ion-row> \n          </ion-grid> -->\n          <ion-row dir=\"rtl\" *ngIf=\"timeLeft | async as tm\">  \n            <ion-col size=\"12\" >\n              <h6 class=\"htx\"> \n                <ion-label><ion-text class=\"paddindStyle2\"><b>{{tm['da'] }}</b> </ion-text> :  </ion-label>\n                <ion-label><ion-text class=\"paddindStyle2\"><b>{{tm['hr'] }}</b> </ion-text>  :  </ion-label>\n                <ion-label><ion-text class=\"paddindStyle2\"><b>{{tm['mn'] }}</b> </ion-text>  :  </ion-label>\n                <ion-label><ion-text class=\"paddindStyle2\"><b>{{tm['sc'] }}</b> </ion-text>  </ion-label>\n              </h6> \n            </ion-col>\n          </ion-row>\n      </ion-col>\n\n\n       \n\n   <!-- history log  -->\n   <ion-card class=\"w100 detailCard\">\n    <ion-card-header class=\"pb0\">  \n      <ion-card-title color=\"light\">\n        <ion-icon name=\"time-outline\" ></ion-icon>\n          المزايدات \n        <!-- <h2 *ngIf=\"time$ | async as time\" >\n          {{time | date:'h:mm:ss'}}\n        </h2>     -->\n      </ion-card-title>\n    </ion-card-header>\n    <ion-grid *ngIf=\"emptyLog == false\">\n      <ion-list  class=\"ion-no-padding list\">\n      <ion-item class=\"custItem\" *ngFor=\"let log of usersLogs\">\n        <ion-avatar class=\"\">\n          <ion-img *ngIf=\"log.imgUrl == ''\"  src=\"../../assets/imgs/bid.png\"></ion-img>\n          <ion-img *ngIf=\"log.imgUrl.length>0\"  [src]=\"log.imgUrl\"></ion-img>\n        </ion-avatar>\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\">\n              <ion-grid>\n                <ion-row>\n                  <ion-col size=\"12\">\n                   <ion-item lines=\"none\" class=\"custItem\">\n                    <ion-label color=\"light\">{{log.fullName}}</ion-label>\n                   </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-label color=\"light\"> \n                      <ion-text>{{log.time | dateAgo}} </ion-text> <ion-text>{{log.time | date:'EEE dd-MM' : undefined  : 'ar' }} </ion-text> \n                      </ion-label>\n                  </ion-col> \n                </ion-row>\n              </ion-grid>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n       <ion-badge slot=\"end\">\n        <ion-label><ion-text>{{log.pay}}</ion-text></ion-label>  \n       </ion-badge>\n      </ion-item>\n\n      <ion-item *ngIf=\"mzd['logs'].length > 2\" button (click)=\"viewMoreLess()\" lines=\"none\" class=\"custItem\">\n         <h4 class=\"custH\">\n          <ion-label *ngIf=\"view == 0\">\n            <ion-note color=\"light\">المزيد</ion-note><br>\n            <ion-icon name=\"chevron-down-outline\" color=\"light\"></ion-icon>\n          </ion-label>\n          <ion-label *ngIf=\"view == 1\">\n            <ion-note color=\"light\">اقل</ion-note><br>\n            <ion-icon   name=\"chevron-up-outline\" color=\"light\"></ion-icon> \n          </ion-label> \n         </h4> \n      </ion-item> \n\n    </ion-list>\n    </ion-grid>\n\n\n      <ion-grid *ngIf=\"emptyLog == true\">\n        <ion-row>\n          <ion-col size=\"12\"> \n               <div class=\"w100 centerDiv\"><ion-thumbnail><ion-img src=\"../../assets/imgs/bid.png\"></ion-img></ion-thumbnail>  </div>  \n          </ion-col>\n          <ion-col size=\"12\" >  \n            <div  class=\"w100 centerDiv\" ><h2 color=\"light\"> كن اول من يضع مزايدة  </h2></div> \n          </ion-col>\n        </ion-row>\n       </ion-grid>\n    </ion-card> \n\n\n      <!-- fees  -->\n      <ion-card class=\"w100 detailCard\" *ngIf=\"mzd\"> \n        <ion-card-header class=\"pb0\">  \n            <ion-card-title color=\"light\">\n               <ion-icon name=\"cash-outline\" ></ion-icon>\n              رسوم المشاركة\n            </ion-card-title>\n          </ion-card-header>\n          <ion-grid class=\"ion-no-margin  ion-no-padding ion-padding-bottom\" dir=\"rtl\">\n            <!-- <ion-row class=\"ion-no-margin  ion-no-padding\">\n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item>\n                  <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item>\n                  <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n                </ion-item>\n              </ion-col>\n            </ion-row> -->\n          </ion-grid>\n          <ion-grid class=\"ion-no-margin  ion-no-padding ion-padding-bottom\" dir=\"rtl\">\n            <ion-row class=\"ion-no-margin  ion-no-padding\"> \n              <ion-col size=\"4\" class=\"ion-text-center\">\n                <ion-card-content> \n                    <ion-text color=\"light\" ><b>العربون</b> </ion-text><br> \n                    <ion-text color=\"light\"> {{mzd['deposit']}} </ion-text>\n                    <ion-text color=\"light\"> ج.س</ion-text> \n                  </ion-card-content>\n              </ion-col>\n              <ion-col size=\"4\" class=\"ion-text-center\">\n                <ion-card-content>  \n                      <ion-text  color=\"light\"><b>رسوم دفتر </b> </ion-text><br> \n                       <ion-text color=\"light\"> {{mzd['fee']}} </ion-text> \n                       <ion-text color=\"light\">   ج.س</ion-text>  \n                </ion-card-content>\n              </ion-col>\n\n              <ion-col size=\"4\" class=\"ion-text-center totcol\">\n                <ion-card-content> \n                  <ion-text color=\"light\"><b>المجموع </b>  </ion-text><br>\n                  <ion-text color=\"light\">  {{mzd['deposit'] + mzd['fee']}}  </ion-text>\n                  <ion-text color=\"light\">   ج.س</ion-text> \n                </ion-card-content>\n              </ion-col>\n            </ion-row>\n          </ion-grid> \n      </ion-card> \n      <!-- terms -->\n\n\n\n      <ion-card class=\"w100 detailCard\">\n        <ion-card-header class=\"pb0\">\n          <ion-card-title color=\"light\">\n            <ion-icon name=\"bookmark-outline\" ></ion-icon> \n            بنود المزاد\n          </ion-card-title> \n        </ion-card-header>\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\" >\n              <ion-card-content> \n                <ion-label color=\"light\" *ngFor=\"let term of termsArr\">\n                  <ion-icon name=\"pin\" color=\"primary\"></ion-icon>\n                  <ion-text>{{term.desc}}</ion-text><br>\n                 </ion-label> \n              </ion-card-content>\n            </ion-col>\n          </ion-row>\n          <ion-row  class=\"ion-justify-content-center\">\n            <ion-item  button (click)=\"viewMoreLessTerms()\" lines=\"none\" class=\" custItem  \">\n              <h4 class=\"custH\">\n               <ion-label *ngIf=\"viewTerms == 0\">\n                 <ion-note color=\"light\">المزيد</ion-note><br>\n                 <ion-icon name=\"chevron-down-outline\" color=\"light\"></ion-icon>\n               </ion-label>\n               <ion-label *ngIf=\"viewTerms == 1\">\n                 <ion-note color=\"light\">اقل</ion-note><br>\n                 <ion-icon   name=\"chevron-up-outline\" color=\"light\"></ion-icon> \n               </ion-label> \n              </h4> \n           </ion-item>\n          </ion-row>\n          \n        </ion-grid>\n      </ion-card>\n\n    </ion-row>\n\n</ion-grid>\n</ion-content>\n\n\n\n<ion-footer class=\"fotterStyle2\" *ngIf=\"mzd && style=='style2'\">\n  <ion-grid>\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col size=\"8\" class=\"flex\">\n        <ion-button size=\"small\" (click)=\"decrease(bidPrice)\">\n          <ion-icon name=\"remove-circle\" color=\"light\"></ion-icon>\n        </ion-button>\n        <ion-input color=\"light\" (ionFocus)=\"focusBidding($event)\" (ionBlur)=\"unCheckFocus()\" (ionChange)=\"bidChange($event)\" type=\"number\"\n          class=\"blueBorder\" [(ngModel)]=\"bidPrice\"\n          [ngClass]=\"{'redBorder': showError == true ,'blueBorder': showError == false}\"> \n        </ion-input><br>\n        <ion-button size=\"small\" (click)=\"increase(bidPrice)\">\n          <ion-icon name=\"add-circle\" color=\"light\"></ion-icon>\n        </ion-button>   \n      </ion-col>\n      <ion-col size=\"8\" *ngIf=\"showError == true\" class=\"ion-no-margin ion-no-padding ion-text-center\">\n        <ion-note color=\"danger\">{{msgError}}</ion-note>\n      </ion-col> \n      <ion-col size=\"8\">\n        <ion-button  expand=\"block\" fill=\"clear\" class= \"btStyle2\" color=\"dark\" [disabled]=\"showError == true\" (click)=\"bidding()\">\n          <h5>مزايدة</h5>\n          <ion-icon name=\"hand-right-outline\" color=\"dark\" slot=\"end\"></ion-icon>\n        </ion-button> \n        <!-- <ion-button expand=\"block\"  (click)=\"endAuction()\">\n          <h5>end it</h5>\n          <ion-icon name=\"hand-right-outline\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  -->\n      </ion-col>\n      <!-- <ion-col size=\"6\" class=\"ion-text-center\">\n        <h4 class=\"ion-no-margin\">\n        <ion-text color=\"primary\">\n            أعلي مزايدة\n        </ion-text> <br>  \n        <ion-text> 3000 </ion-text>\n         <ion-text> ج.س</ion-text>\n       </h4>  \n      </ion-col>  -->\n    </ion-row>\n  </ion-grid>\n</ion-footer>\n\n\n\n\n<ion-footer class=\"footer\" *ngIf=\"mzd && style=='style1'\">\n  <ion-grid>\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col size=\"8\" class=\"flex\">\n        <ion-button size=\"small\" (click)=\"decrease(bidPrice)\">\n          <ion-icon name=\"remove-circle\" color=\"light\"></ion-icon>\n        </ion-button>\n        <ion-input (ionFocus)=\"focusBidding($event)\" (ionBlur)=\"unCheckFocus()\" (ionChange)=\"bidChange($event)\" type=\"number\"\n          class=\"blueBorder\" [(ngModel)]=\"bidPrice\"\n          [ngClass]=\"{'redBorder': showError == true ,'blueBorder': showError == false}\"> \n        </ion-input><br>\n        <ion-button size=\"small\" (click)=\"increase(bidPrice)\">\n          <ion-icon name=\"add-circle\" color=\"light\"></ion-icon>\n        </ion-button>   \n      </ion-col>\n      <ion-col size=\"8\" *ngIf=\"showError == true\" class=\"ion-no-margin ion-no-padding ion-text-center\">\n        <ion-note color=\"danger\">{{msgError}}</ion-note>\n      </ion-col> \n      <ion-col size=\"8\">\n        <ion-button expand=\"block\" [disabled]=\"showError == true\" (click)=\"bidding()\">\n          <h5>مزايدة</h5>\n          <ion-icon name=\"hand-right-outline\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button> \n        <!-- <ion-button expand=\"block\"  (click)=\"endAuction()\">\n          <h5>end it</h5>\n          <ion-icon name=\"hand-right-outline\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  -->\n      </ion-col>\n      <!-- <ion-col size=\"6\" class=\"ion-text-center\">\n        <h4 class=\"ion-no-margin\">\n        <ion-text color=\"primary\">\n            أعلي مزايدة\n        </ion-text> <br>  \n        <ion-text> 3000 </ion-text>\n         <ion-text> ج.س</ion-text>\n       </h4>  \n      </ion-col>  -->\n    </ion-row>\n  </ion-grid>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_live-mzad_live-mzad_module_ts.js.map