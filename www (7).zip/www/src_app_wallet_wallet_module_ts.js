"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_wallet_wallet_module_ts"],{

/***/ 42576:
/*!*************************************************!*\
  !*** ./src/app/wallet/wallet-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletPageRoutingModule": () => (/* binding */ WalletPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _wallet_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./wallet.page */ 5911);




const routes = [
    {
        path: '',
        component: _wallet_page__WEBPACK_IMPORTED_MODULE_0__.WalletPage
    }
];
let WalletPageRoutingModule = class WalletPageRoutingModule {
};
WalletPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], WalletPageRoutingModule);



/***/ }),

/***/ 49555:
/*!*****************************************!*\
  !*** ./src/app/wallet/wallet.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletPageModule": () => (/* binding */ WalletPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _wallet_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./wallet-routing.module */ 42576);
/* harmony import */ var _wallet_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./wallet.page */ 5911);







let WalletPageModule = class WalletPageModule {
};
WalletPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _wallet_routing_module__WEBPACK_IMPORTED_MODULE_0__.WalletPageRoutingModule
        ],
        declarations: [_wallet_page__WEBPACK_IMPORTED_MODULE_1__.WalletPage]
    })
], WalletPageModule);



/***/ }),

/***/ 5911:
/*!***************************************!*\
  !*** ./src/app/wallet/wallet.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WalletPage": () => (/* binding */ WalletPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 42321);
/* harmony import */ var _wallet_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./wallet.page.html?ngResource */ 66936);
/* harmony import */ var _wallet_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./wallet.page.scss?ngResource */ 90798);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 80190);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/socket-service.service */ 20905);









let WalletPage = class WalletPage {
    constructor(api, socket, route, storage, loadingController, toast, actionSheetCtl, datePipe, rout, modalController) {
        this.api = api;
        this.socket = socket;
        this.route = route;
        this.storage = storage;
        this.loadingController = loadingController;
        this.toast = toast;
        this.actionSheetCtl = actionSheetCtl;
        this.datePipe = datePipe;
        this.rout = rout;
        this.modalController = modalController;
        this.errorLoadBalance = false;
        this.errorLoad = false;
        this.showEmpty = false;
        this.showSkelton = false;
        this.transactions = undefined;
        this.walletBalance = undefined;
        this.storage.get('user_info').then((response) => {
            if (response) {
                this.USER_INFO = response.user;
                console.log('kkkkkkkkkk', this.USER_INFO);
                this.getWalletBalance();
            }
        });
    }
    getWalletBalance() {
        this.api.getBalance(this.USER_INFO._id).subscribe(data => {
            console.log(data);
            let res = data['transaction'][0];
            this.walletBalance = +res.balance;
            this.getTransactions();
        }, (err) => {
            console.log(err);
            this.errorLoad = true;
        }, () => {
        });
    }
    getTransactions() {
        this.api.getAllTransaction(this.USER_INFO._id).subscribe(data => {
            console.log(data);
            let res = data['transaction'];
            this.transactions = res;
        }, (err) => {
            console.log(err);
            this.errorLoad = true;
        }, () => {
        });
    }
    reload() {
        this.errorLoad = false;
        this.errorLoadBalance = false;
        this.transactions = undefined;
        this.walletBalance = undefined;
        this.getWalletBalance();
    }
    ngOnInit() {
    }
};
WalletPage.ctorParameters = () => [
    { type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService },
    { type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ActionSheetController },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_6__.DatePipe },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController }
];
WalletPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-wallet',
        template: _wallet_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_wallet_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], WalletPage);



/***/ }),

/***/ 90798:
/*!****************************************************!*\
  !*** ./src/app/wallet/wallet.page.scss?ngResource ***!
  \****************************************************/
/***/ ((module) => {

module.exports = ".custGrid {\n  height: 100%;\n  display: flex;\n  align-items: center;\n}\n\n.f30 {\n  font-size: 30px;\n}\n\n.float {\n  position: fixed;\n  bottom: 5%;\n  right: 3%;\n}\n\n.bg {\n  background-color: var(--ion-color-primary);\n}\n\n.bgtool {\n  background-image: url('bgtoolbar2.png');\n  background-blend-mode: soft-light;\n  background-color: var(--ion-color-primary-tint);\n}\n\nion-toolbar {\n  --opacity:0 ;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndhbGxldC5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXGh1c2FtJTIwcHJvalxcem9vZG9oYVNkXFxzcmNcXGFwcFxcd2FsbGV0XFx3YWxsZXQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksWUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQ0FKOztBREVBO0VBQ0ksZUFBQTtBQ0NKOztBRENBO0VBQ0ksZUFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0FDRUo7O0FEQUE7RUFDSSwwQ0FBQTtBQ0dKOztBRERBO0VBQ0ksdUNBQUE7RUFDQSxpQ0FBQTtFQUNBLCtDQUFBO0FDSUo7O0FEREE7RUFDSSxZQUFBO0FDSUoiLCJmaWxlIjoid2FsbGV0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiBcclxuLmN1c3RHcmlke1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLmYzMHtcclxuICAgIGZvbnQtc2l6ZTogMzBweDtcclxufVxyXG4uZmxvYXR7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBib3R0b206IDUlO1xyXG4gICAgcmlnaHQ6IDMlO1xyXG59XHJcbi5iZ3tcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxufVxyXG4uYmd0b29se1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvaW1ncy9iZ3Rvb2xiYXIyLnBuZycpOyBcclxuICAgIGJhY2tncm91bmQtYmxlbmQtbW9kZTogc29mdC1saWdodDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXRpbnQpO1xyXG59XHJcblxyXG5pb24tdG9vbGJhcntcclxuICAgIC0tb3BhY2l0eVx0OjBcclxufSIsIi5jdXN0R3JpZCB7XG4gIGhlaWdodDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmYzMCB7XG4gIGZvbnQtc2l6ZTogMzBweDtcbn1cblxuLmZsb2F0IHtcbiAgcG9zaXRpb246IGZpeGVkO1xuICBib3R0b206IDUlO1xuICByaWdodDogMyU7XG59XG5cbi5iZyB7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuLmJndG9vbCB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4uLy4uL2Fzc2V0cy9pbWdzL2JndG9vbGJhcjIucG5nXCIpO1xuICBiYWNrZ3JvdW5kLWJsZW5kLW1vZGU6IHNvZnQtbGlnaHQ7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXRpbnQpO1xufVxuXG5pb24tdG9vbGJhciB7XG4gIC0tb3BhY2l0eTowIDtcbn0iXX0= */";

/***/ }),

/***/ 66936:
/*!****************************************************!*\
  !*** ./src/app/wallet/wallet.page.html?ngResource ***!
  \****************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar dir=\"rtl\"> \n    <ion-title>\n      <ion-icon name=\"wallet-outline\"></ion-icon>\n      المحفظة</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n\n\n\n<ion-content> \n  <ion-grid *ngIf=\"errorLoad == true \" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n  </ion-grid>\n \n    <ion-grid *ngIf=\"!transactions  && errorLoad == false \"  class=\"custGrid\"> \n      <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <!-- *ngIf=\"spinner == true\" -->\n          <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n        </ion-col>\n        <ion-col size=\"12\">\n          <!-- *ngIf=\"spinner == true\" --> \n        </ion-col>\n      </ion-row> \n    </ion-grid>\n\n\n  <ion-grid class=\"ion-no-margin  ion-no-padding\"  dir=\"rtl\"  *ngIf=\"transactions \">\n    \n    <ion-header class=\"bgtool \">\n      <ion-toolbar dir=\"rtl\"  class=\" ion-margin-bottom ion-margin-top\" >\n        <ion-title class=\"ion-text-center\" color=\"light\">\n          <h2 color=\"light\"><b>الرصيــد</b></h2>\n        </ion-title>\n        <ion-title class=\"ion-text-center\" color=\"light\">\n          <h2 ><b>{{walletBalance}}</b>\n            <ion-text>ج.س </ion-text>\n          </h2>  \n        </ion-title>\n      </ion-toolbar> \n    \n    </ion-header> \n    <ion-row class=\"ion-no-padding\">\n      <!-- <ion-card class=\"w100\"> \n        <ion-list>\n          <ion-item class=\"w100\">\n            <ion-icon name=\"card-outline\"  color=\"primary\"></ion-icon> \n           <ion-label> حساباتي </ion-label> \n          </ion-item> \n          <ion-item lines=\"none\"   class=\"ion-margin-top\">\n            <ion-icon name=\"logo-google\"></ion-icon> \n            <ion-label>قوقل باي</ion-label>\n            <ion-icon slot=\"end\" name=\"chevron-back-outline\"></ion-icon>\n          </ion-item>\n           <ion-item lines=\"none\" > \n            <ion-icon name=\"logo-apple\"></ion-icon>\n            <ion-label>ابل باي</ion-label>\n            <ion-icon slot=\"end\" name=\"chevron-back-outline\"></ion-icon> \n          </ion-item>\n        </ion-list> \n       \n         \n      </ion-card>  -->\n      <ion-card class=\"w100\"> \n        <ion-list>\n          <ion-item class=\"w100\">\n            <ion-icon name=\"receipt-outline\"  color=\"primary\"></ion-icon> \n           <ion-label>معاملات حديثة </ion-label> \n            <ion-button slot=\"end\"  fill=\"clear\" color=\"primary\">عرض الكل\n              <ion-icon name=\"arrow-back-outline\"></ion-icon>\n            </ion-button> \n          </ion-item> \n\n          <ion-accordion-group>\n            <ion-accordion   *ngFor=\"let trans of transactions ; let i = index\" [value]=\"i\">\n              <ion-item slot=\"header\" color=\"light\">\n                  <ion-icon name=\"arrow-up-outline\" color=\"danger\" *ngIf=\"trans.typee == 1\"></ion-icon> \n                  <ion-icon name=\"arrow-down-outline\" color=\"success\" *ngIf=\"trans.typee == 2\"></ion-icon> \n                  <ion-label> {{trans.details}}</ion-label>\n                  <ion-badge slot=\"end\" outline=\"true\" color=\"danger\" *ngIf=\"trans.typee == 1\"><b>-{{trans.pay}}</b><ion-text> ج.س </ion-text></ion-badge>\n                  <ion-badge slot=\"end\" outline=\"true\" color=\"success\" *ngIf=\"trans.typee == 2\"><b>-{{trans.pay}}</b><ion-text> ج.س </ion-text></ion-badge>\n                \n              </ion-item>\n              <div class=\"ion-padding\" slot=\"content\">\n                <ion-grid>\n                  <ion-row class=\"ion-margin\">\n                    <ion-col size=\"3\">رقم العملية:</ion-col>\n                    <ion-col size=\"9\" class=\"ion-text-end\">{{trans._id}}</ion-col>\n                  </ion-row>\n                  <ion-row class=\"ion-margin\">\n                    <ion-col size=\"3\">التفاصيل:</ion-col>\n                    <ion-col size=\"9\" class=\"ion-text-end\">{{trans.details}}</ion-col>\n                  </ion-row>\n                  <ion-row class=\"ion-margin\">\n                    <ion-col size=\"3\">التاريخ</ion-col>\n                    <ion-col size=\"9\"  class=\"ion-text-end\">{{trans.createdAt | date:'EEE dd-MM-yyyy hh:mm a' : undefined  : 'ar'}}</ion-col>\n                  </ion-row> \n                  <ion-row class=\"ion-margin\"> \n                    <ion-col size=\"3\">نوع العملية</ion-col>\n                    <ion-col size=\"9\"  class=\"ion-text-end\">\n                      <ion-label  *ngIf=\"trans.typee == 1\">سحب</ion-label>\n                      <ion-label  *ngIf=\"trans.typee == 2\">ايداع</ion-label>\n                    </ion-col>\n                  </ion-row>\n                  <ion-row class=\"ion-margin\">\n                    <ion-col size=\"3\"><ion-label>المبلغ</ion-label></ion-col>\n                    <ion-col size=\"9\"  class=\"ion-text-end\"><ion-label>{{trans.pay}} ج.س</ion-label></ion-col>\n                  </ion-row>\n                  <ion-row class=\"ion-margin\">\n                    <ion-col size=\"3\"> <ion-label>من حساب</ion-label>  </ion-col>\n                   \n                    <ion-col size=\"9\"  class=\"ion-text-end\">   <ion-label><ion-text>{{trans.fromAccountTitle}} </ion-text>,{{trans.fromAccount}}</ion-label></ion-col>\n                  </ion-row>\n                  <ion-row class=\"ion-margin\">\n                    \n                    <ion-col size=\"3\"> <ion-label>الي حساب</ion-label>  </ion-col>\n                    <ion-col size=\"9\"  class=\"ion-text-end\">  <ion-label><ion-text>{{trans.toAccountTitle}}  </ion-text>,{{trans.toAccount}}</ion-label> </ion-col>\n                  </ion-row>\n                  <ion-row class=\"ion-margin\">\n                    <ion-col size=\"3\"><ion-label>تعليق</ion-label>   </ion-col>\n                    <ion-col size=\"9\"  class=\"ion-text-end\">   <ion-label><ion-text>{{trans.toAccountTitle}}  </ion-text>,{{trans.toAccount}}</ion-label></ion-col>\n                  </ion-row>\n                </ion-grid>\n               \n              </div>\n            </ion-accordion>\n          \n          </ion-accordion-group>\n\n\n\n          <!-- <ion-item  lines=\"none\"   class=\"ion-margin-top\" *ngFor=\"let trans of transactions\">\n            <ion-icon name=\"arrow-up-outline\" color=\"danger\" *ngIf=\"trans.currentStatus == 1\"></ion-icon> \n            <ion-icon name=\"arrow-down-outline\" color=\"success\" *ngIf=\"trans.currentStatus == 2\"></ion-icon> \n            <ion-label> {{trans.details}}</ion-label>\n            <ion-badge slot=\"end\" outline=\"true\" color=\"danger\"><b>-{{trans.pay}}</b><ion-text> ج.س </ion-text></ion-badge>\n            <ion-icon slot=\"end\" name=\"chevron-back-outline\"></ion-icon>  \n          </ion-item> -->\n           <!-- <ion-item lines=\"none\"   class=\"ion-margin-bottom\"  > \n            <ion-label> شحن رصيد عن طريق مدي</ion-label>\n            <ion-badge slot=\"end\" outline=\"true\" color=\"success\"><b>+3000</b><ion-text>ر.س</ion-text></ion-badge>\n            <ion-icon slot=\"end\" name=\"chevron-back-outline\"></ion-icon>  \n          </ion-item> -->\n        </ion-list> \n       \n         \n      </ion-card> \n      </ion-row>\n    </ion-grid>\n    <!-- <ion-fab slot=\"fixed\" class=\"float\">\n      <ion-chip class=\"ion-padding\" class=\"bg\">\n        <ion-label color=\"light\">شحن المحفظة</ion-label> \n       <ion-icon name=\"add-circle\"  color=\"light\" class=\"f30\" ></ion-icon>\n       \n     </ion-chip>\n   </ion-fab> -->\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_wallet_wallet_module_ts.js.map