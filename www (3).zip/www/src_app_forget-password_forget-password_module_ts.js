"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_forget-password_forget-password_module_ts"],{

/***/ 8733:
/*!*******************************************************************!*\
  !*** ./src/app/forget-password/forget-password-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgetPasswordPageRoutingModule": () => (/* binding */ ForgetPasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _forget_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forget-password.page */ 3694);




const routes = [
    {
        path: '',
        component: _forget_password_page__WEBPACK_IMPORTED_MODULE_0__.ForgetPasswordPage
    }
];
let ForgetPasswordPageRoutingModule = class ForgetPasswordPageRoutingModule {
};
ForgetPasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ForgetPasswordPageRoutingModule);



/***/ }),

/***/ 4845:
/*!***********************************************************!*\
  !*** ./src/app/forget-password/forget-password.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgetPasswordPageModule": () => (/* binding */ ForgetPasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _forget_password_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forget-password-routing.module */ 8733);
/* harmony import */ var _forget_password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forget-password.page */ 3694);







let ForgetPasswordPageModule = class ForgetPasswordPageModule {
};
ForgetPasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _forget_password_routing_module__WEBPACK_IMPORTED_MODULE_0__.ForgetPasswordPageRoutingModule
        ],
        declarations: [_forget_password_page__WEBPACK_IMPORTED_MODULE_1__.ForgetPasswordPage]
    })
], ForgetPasswordPageModule);



/***/ }),

/***/ 3694:
/*!*********************************************************!*\
  !*** ./src/app/forget-password/forget-password.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgetPasswordPage": () => (/* binding */ ForgetPasswordPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _forget_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forget-password.page.html?ngResource */ 3285);
/* harmony import */ var _forget_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forget-password.page.scss?ngResource */ 715);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 124);





let ForgetPasswordPage = class ForgetPasswordPage {
    constructor(rout) {
        this.rout = rout;
    }
    ngOnInit() {
    }
    newPassword() {
        this.rout.navigate(['new-password']);
    }
};
ForgetPasswordPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
ForgetPasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-forget-password',
        template: _forget_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_forget_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ForgetPasswordPage);



/***/ }),

/***/ 715:
/*!**********************************************************************!*\
  !*** ./src/app/forget-password/forget-password.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = ".header-md::after {\n  background-image: none;\n}\n\n.bordernon {\n  border: none;\n}\n\n.newHeight {\n  height: 375px;\n}\n\n.custH {\n  border-bottom-style: solid;\n  padding: 10px;\n  width: 120px;\n  text-align: center;\n}\n\n.custGrid {\n  position: relative;\n  top: -181px;\n}\n\n.footer-md::before {\n  background-image: none;\n}\n\n.borderNone {\n  border-radius: 0px;\n}\n\n.padd13 {\n  padding-top: 13%;\n}\n\n.padd1 {\n  padding: 1%;\n}\n\n.logoSvg {\n  position: absolute;\n  top: 30%;\n  left: 50%;\n  margin-right: 50%;\n  transform: translate(-50%, -50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcmdldC1wYXNzd29yZC5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXGh1c2FtJTIwcHJvalxcem9vZG9oYVNkXFxzcmNcXGFwcFxcZm9yZ2V0LXBhc3N3b3JkXFxmb3JnZXQtcGFzc3dvcmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0JBQUE7QUNDSjs7QURDQTtFQUNJLFlBQUE7QUNFSjs7QURDQTtFQUNJLGFBQUE7QUNFSjs7QURBQTtFQUNJLDBCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQ0dKOztBRERBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0FDSUo7O0FERkE7RUFDSSxzQkFBQTtBQ0tKOztBREhBO0VBQ0ksa0JBQUE7QUNNSjs7QURKQTtFQUNJLGdCQUFBO0FDT0o7O0FETEE7RUFDSSxXQUFBO0FDUUo7O0FETkE7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQ0FBQTtBQ1NKIiwiZmlsZSI6ImZvcmdldC1wYXNzd29yZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyLW1kOjphZnRlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOm5vbmU7XHJcbn1cclxuLmJvcmRlcm5vbntcclxuICAgIGJvcmRlcjogbm9uZTtcclxufVxyXG5cclxuLm5ld0hlaWdodHtcclxuICAgIGhlaWdodDogMzc1cHg7XHJcbn1cclxuLmN1c3RIe1xyXG4gICAgYm9yZGVyLWJvdHRvbS1zdHlsZTogc29saWQ7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgd2lkdGg6IDEyMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5jdXN0R3JpZHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRvcDogLTE4MXB4O1xyXG59XHJcbi5mb290ZXItbWQ6OmJlZm9yZXtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6ICBub25lO1xyXG59XHJcbi5ib3JkZXJOb25le1xyXG4gICAgYm9yZGVyLXJhZGl1czogMHB4O1xyXG59XHJcbi5wYWRkMTN7XHJcbiAgICBwYWRkaW5nLXRvcDoxMyVcclxufVxyXG4ucGFkZDF7XHJcbiAgICBwYWRkaW5nOiAxJTtcclxufVxyXG4ubG9nb1N2Z3tcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMzAlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxufSIsIi5oZWFkZXItbWQ6OmFmdGVyIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn1cblxuLmJvcmRlcm5vbiB7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuLm5ld0hlaWdodCB7XG4gIGhlaWdodDogMzc1cHg7XG59XG5cbi5jdXN0SCB7XG4gIGJvcmRlci1ib3R0b20tc3R5bGU6IHNvbGlkO1xuICBwYWRkaW5nOiAxMHB4O1xuICB3aWR0aDogMTIwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmN1c3RHcmlkIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IC0xODFweDtcbn1cblxuLmZvb3Rlci1tZDo6YmVmb3JlIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn1cblxuLmJvcmRlck5vbmUge1xuICBib3JkZXItcmFkaXVzOiAwcHg7XG59XG5cbi5wYWRkMTMge1xuICBwYWRkaW5nLXRvcDogMTMlO1xufVxuXG4ucGFkZDEge1xuICBwYWRkaW5nOiAxJTtcbn1cblxuLmxvZ29Tdmcge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMzAlO1xuICBsZWZ0OiA1MCU7XG4gIG1hcmdpbi1yaWdodDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbn0iXX0= */";

/***/ }),

/***/ 3285:
/*!**********************************************************************!*\
  !*** ./src/app/forget-password/forget-password.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n     <ion-button fill=\"clear\" >\n       <ion-icon name=\"arrow-back-outline\" color=\"light\"></ion-icon>\n     </ion-button>\n    </ion-buttons>\n     <ion-title>forget Password</ion-title>\n   </ion-toolbar>\n</ion-header>\n \n\n<ion-content>\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col size=\"12\" class=\"head3 newHeight ion-text-center \">  \n        <svg class=\"logoSvg\" width=\"119\" height=\"119\" viewBox=\"0 0 119 119\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <circle opacity=\"0.27\" cx=\"59.5\" cy=\"59.5\" r=\"59.5\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M87.5908 52.4474C88.1575 53.3924 88.3464 54.5259 88.3464 55.6598V81.925C88.3464 86.0818 84.9451 89.4831 80.9771 89.4831H37.3273C33.3593 89.4831 29.958 86.0818 29.958 81.925V55.6598C29.958 54.5259 30.1469 53.3924 30.7137 52.4474L52.8219 70.777C56.2231 73.6115 61.8918 73.6115 65.482 70.777L87.5902 52.4474H87.5908Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M40.1623 55.6605L32.9819 49.6136L55.0901 31.4732C57.1686 29.5836 60.9476 29.3947 63.2154 31.2842L85.3236 49.6139L78.1433 55.6608V51.1256C78.1433 48.8583 76.4426 47.1576 74.3641 47.1576H43.942C41.8635 47.1576 40.1628 48.8583 40.1628 51.1256V55.6608L40.1623 55.6605Z\" fill=\"white\"/>\n          <path d=\"M49.4223 53.2042C48.0995 53.2042 48.0995 51.3147 49.4223 51.3147H68.8849C70.2077 51.3147 70.2077 53.2042 68.8849 53.2042H49.4223Z\" fill=\"white\"/>\n          <path d=\"M49.4223 60.9505C48.0995 60.9505 48.0995 59.061 49.4223 59.061H68.8849C70.2077 59.061 70.2077 60.9505 68.8849 60.9505H49.4223Z\" fill=\"white\"/>\n          <path d=\"M49.4223 57.172C48.0995 57.172 48.0995 55.2825 49.4223 55.2825H68.8849C70.2077 55.2825 70.2077 57.172 68.8849 57.172H49.4223Z\" fill=\"white\"/>\n        </svg>\n     </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid class=\"custGrid ion-margin-bottom\">\n     <ion-row class=\"ion-justify-content-center\">\n    <ion-col size=\"10\" >\n     <ion-card class=\"bordernon w100\" >\n      <ion-card-header>\n        <ion-card-title>\n         <h3 ><b>Forgot your Password?</b></h3> \n        </ion-card-title>\n        <ion-card-subtitle>\n          Enter your Registered email below to creat new password\n        </ion-card-subtitle>\n      </ion-card-header>\n       <ion-grid>\n        <ion-row class=\"ion-margin\">\n          <ion-list class=\"w100\"> \n            <ion-item >\n              <ion-label position=\"floating\">Email</ion-label> \n              <ion-input></ion-input>\n              <!-- <ion-icon name=\"eye-outline\"></ion-icon> -->\n              <ion-icon slot=\"end\" name=\"checkmark-outline\" color=\"success\"></ion-icon>\n            </ion-item> \n          </ion-list>\n        </ion-row> \n        <ion-row class=\"ion-margin\">\n          <ion-col size=\"12\">\n            <ion-item color=\"primary\" button (click)=\"newPassword()\">\n              <ion-label class=\"ion-text-center\">NEXT</ion-label> \n            </ion-item>\n          </ion-col>\n        </ion-row> \n       </ion-grid> \n      </ion-card>\n    </ion-col>\n    </ion-row>\n  </ion-grid>\n \n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_forget-password_forget-password_module_ts.js.map