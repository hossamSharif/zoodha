"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_login_login_module_ts"],{

/***/ 5393:
/*!***********************************************!*\
  !*** ./src/app/login/login-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page */ 6825);




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_0__.LoginPage
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 107:
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login-routing.module */ 5393);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page */ 6825);







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_0__.LoginPageRoutingModule
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_1__.LoginPage]
    })
], LoginPageModule);



/***/ }),

/***/ 6825:
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPage": () => (/* binding */ LoginPage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page.html?ngResource */ 1729);
/* harmony import */ var _login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login.page.scss?ngResource */ 7047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/socket-service.service */ 905);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ 190);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);










let LoginPage = class LoginPage {
  constructor(formBuilder, toast, storage, rout, api) {
    this.formBuilder = formBuilder;
    this.toast = toast;
    this.storage = storage;
    this.rout = rout;
    this.api = api;
    this.mode = 'phone';
    this.spinner = false;
    this.isSubmitted = false;
    this.isSubmitted2 = false;
    this.ionicForm = this.formBuilder.group({
      phone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.minLength(9), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.maxLength(9), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.pattern('^[0-9]+$')]]
    });
    this.ionic2Form = this.formBuilder.group({
      email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
      password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]
    });
  }

  ngOnInit() {}

  get errorControl() {
    return this.ionicForm.controls;
  }

  get error2Control() {
    return this.ionic2Form.controls;
  }

  getInfo(type) {}

  login() {
    if (this.mode == 'phone') {
      this.isSubmitted = true;

      if (this.ionicForm.valid == false) {
        console.log('Please provide all the required values!');
      } else if (this.phone[0] != 9 && +this.phone[0] != 1) {
        console.log(this.phone[0]);
        this.presentToast('رقم الجوال غير صحيح', 'danger');
      } else {
        this.loginPhone();
      }
    } else if (this.mode == 'google') {
      if (this.ionic2Form.valid == false) {
        console.log('Please provide all the required values!');
      } else {
        this.loginEmail();
      }
    }
  }

  genrateime() {
    let seq = (Math.floor(Math.random() * 10000) + 10000).toString().substring(1);
    return seq;
  }

  loginEmail() {
    this.spinner = true;
    this.api.loginEmail(this.email, this.password).subscribe(data => {
      console.log(data);
      let res = data; // this.getsms('exist', res) // uncomment it after apply smsgetway 
      // this.getVirfyCode('exist' , res) // comment it after apply smsgetway

      let jsd = data['user']; // this.api.loginEmit(jsd._id) 

      this.USER_INFO = data['user'];
      this.storage.set('user_info', data).then(response => {});
      this.storage.set('token', data['token']).then(response => {
        this.rout.navigate(['tabs/home']);
      });
    }, err => {
      console.log(err.error.error);
      this.handleError(err.error.error);
      this.spinner = false;
    }, () => {
      this.spinner = false; // move this line to send sms function when you enable it
    });
  }

  loginPhone() {
    this.spinner = true;
    this.api.loginPhone(this.phone, this.genrateime()).subscribe(data => {
      console.log(data);
      let res = data; // this.getsms('exist', res) // uncomment it after apply smsgetway 

      this.getVirfyCode('exist', res); // comment it after apply smsgetway 
    }, err => {
      console.log(err.error.error);
      this.handleError(err.error.error);
      this.spinner = false;
    }, () => {
      this.spinner = false; // move this line to send sms function when you enable it
    });
  }

  getsms(type, resdata) {
    this.api.sendsms(this.phone, resdata['code']).subscribe(data => {
      console.log('sms req', data);
      let res = data;

      if (type == 'new') {
        this.getVirfyCode('new', resdata);
      } else if (type == 'exist') {
        this.getVirfyCode('exist', resdata);
      }
    }, err => {
      console.log(err);
      this.presentToast('Sms getway down', 'danger');
    });
  }

  handleError(err) {
    if (err.error == "No user with this phone found") {
      console.log('no user was found'); // this.getsms('new',err) // uncomment it after apply smsgetway 

      this.getVirfyCode('new', err); // comment it after apply smsgetway 
    } else if (err.error == "another phone") {
      // to apply imei check uncmment the line in zoodohapi/controller/user.j function : loginPhone
      this.presentToast('seem you use another phone', 'danger');
    } else {
      this.presentToast('حدث خطأ ما ,حاول مرة اخري', 'danger');
      console.log(err.kind);
    }
  }

  getVirfyCode(type, sendData) {
    if (type == 'new') {
      let navigationExtras = {
        queryParams: {
          type: JSON.stringify('new'),
          code: JSON.stringify(sendData.code),
          phone: JSON.stringify(this.phone)
        }
      };
      this.rout.navigate(['verify'], navigationExtras);
    } else if (type == 'exist') {
      let navigationExtras = {
        queryParams: {
          type: JSON.stringify('exist'),
          data: JSON.stringify(sendData)
        }
      };
      this.rout.navigate(['verify'], navigationExtras);
    }
  } //  loginPhone2(){
  //   let logphoneApi = this.api.loginPhone(this.phone , this.genrateime()).pipe(
  //     map((data) => { 
  //       return data;          // <-- return `data`
  //     }),
  //     catchError((error) => {
  //       console.log("error");
  //       this.handleError(error.error.error)
  //       return of(error);     // <-- remember you must return an observable from `catchError` operator
  //     })
  //   );
  //   let smsApi =  this.api.sendsms(this.phone , this.genrateime()).pipe(
  //     map((data) => {
  //       return data;          // <-- return `data`
  //     }),
  //     catchError((error) => {
  //       console.log("error");
  //       return of(error);     // <-- remember you must return an observable from `catchError` operator
  //     })
  //   );
  //   forkJoin([logphoneApi, smsApi]).subscribe((res) => {
  //    this.handl1(res[0],res[1])
  //   }, () => {
  //       // when observable is completed
  //   });
  // }
  // handl1(data1,data2){
  //   console.log(data1,data2);
  // }


  presentToast(msg, color) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  }

  signUp() {
    this.rout.navigate(['sign-up']);
  }

  froget() {
    this.rout.navigate(['forget-password']);
  }

};

LoginPage.ctorParameters = () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController
}, {
  type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__.Storage
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService
}];

LoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-login',
  template: _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], LoginPage);


/***/ }),

/***/ 7047:
/*!**************************************************!*\
  !*** ./src/app/login/login.page.scss?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = ".header-md::after {\n  background-image: none;\n}\n\n.bordernon {\n  border: none;\n}\n\n.custH {\n  border-bottom-style: solid;\n  padding: 10px;\n  width: 100px;\n  text-align: center;\n}\n\n.custGrid2 {\n  position: relative;\n  top: -130px;\n}\n\n.footer-md::before {\n  background-image: none;\n}\n\n.borderNone {\n  border-radius: 0px;\n}\n\n.padd13 {\n  padding-top: 13%;\n}\n\n.padd1 {\n  padding: 1%;\n}\n\n.logoSvg {\n  position: absolute;\n  top: 30%;\n  left: 50%;\n  margin-right: 50%;\n  transform: translate(-50%, -50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLnBhZ2Uuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcaHVzYW0lMjBwcm9qXFx6b29kb2hhU2RcXHNyY1xcYXBwXFxsb2dpblxcbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksc0JBQUE7QUNBSjs7QURFQTtFQUNJLFlBQUE7QUNDSjs7QURDQTtFQUNJLDBCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQ0VKOztBREVBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0FDQ0o7O0FERUE7RUFDSSxzQkFBQTtBQ0NKOztBRENBO0VBQ0ksa0JBQUE7QUNFSjs7QURBQTtFQUNJLGdCQUFBO0FDR0o7O0FEREE7RUFDSSxXQUFBO0FDSUo7O0FERkE7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQ0FBQTtBQ0tKIiwiZmlsZSI6ImxvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4uaGVhZGVyLW1kOjphZnRlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOm5vbmU7XHJcbn1cclxuLmJvcmRlcm5vbntcclxuICAgIGJvcmRlcjogbm9uZTtcclxufVxyXG4uY3VzdEh7XHJcbiAgICBib3JkZXItYm90dG9tLXN0eWxlOiBzb2xpZDtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICB3aWR0aDogMTAwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcblxyXG4uY3VzdEdyaWQye1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgdG9wOiAtMTMwcHg7XHJcbn1cclxuXHJcbi5mb290ZXItbWQ6OmJlZm9yZXtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6ICBub25lO1xyXG59XHJcbi5ib3JkZXJOb25le1xyXG4gICAgYm9yZGVyLXJhZGl1czogMHB4O1xyXG59XHJcbi5wYWRkMTN7XHJcbiAgICBwYWRkaW5nLXRvcDoxMyVcclxufVxyXG4ucGFkZDF7XHJcbiAgICBwYWRkaW5nOiAxJTtcclxufVxyXG4ubG9nb1N2Z3tcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMzAlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxufVxyXG4iLCIuaGVhZGVyLW1kOjphZnRlciB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmU7XG59XG5cbi5ib3JkZXJub24ge1xuICBib3JkZXI6IG5vbmU7XG59XG5cbi5jdXN0SCB7XG4gIGJvcmRlci1ib3R0b20tc3R5bGU6IHNvbGlkO1xuICBwYWRkaW5nOiAxMHB4O1xuICB3aWR0aDogMTAwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmN1c3RHcmlkMiB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdG9wOiAtMTMwcHg7XG59XG5cbi5mb290ZXItbWQ6OmJlZm9yZSB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmU7XG59XG5cbi5ib3JkZXJOb25lIHtcbiAgYm9yZGVyLXJhZGl1czogMHB4O1xufVxuXG4ucGFkZDEzIHtcbiAgcGFkZGluZy10b3A6IDEzJTtcbn1cblxuLnBhZGQxIHtcbiAgcGFkZGluZzogMSU7XG59XG5cbi5sb2dvU3ZnIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDMwJTtcbiAgbGVmdDogNTAlO1xuICBtYXJnaW4tcmlnaHQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59Il19 */";

/***/ }),

/***/ 1729:
/*!**************************************************!*\
  !*** ./src/app/login/login.page.html?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n   <ion-buttons slot=\"start\">\n    <ion-button fill=\"clear\" >\n      <ion-icon name=\"arrow-back-outline\" color=\"light\"></ion-icon>\n    </ion-button>\n   </ion-buttons>\n    <ion-title>login</ion-title>\n  </ion-toolbar>\n  \n\n</ion-header>\n\n<ion-content dir=\"rtl\"> \n   \n  <ion-grid class=\"ion-no-padding\" >\n    <ion-row> \n      <ion-col size=\"12\" class=\"head2 ion-text-center \">  \n        <svg class=\"logoSvg\" width=\"157\" height=\"75\" viewBox=\"0 0 157 75\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M47.2954 26.3206L52.6937 20.954H61.6309L51.4418 31.1114L47.2954 26.3206Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M82.3263 0H5.51448H0L2.79949 4.75915L37.6506 63.8707L41.2371 57.5534L17.8111 17.8217H64.2035L67.7319 11.4991H14.0873L11.0342 6.32263H76.8118L76.8065 6.32792H84.1169L85.0465 4.75915L87.846 0H82.3263Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M56.3647 41.0311L38.9656 20.954H30.5513L52.9842 46.7727L47.1951 56.6027L40.397 68.5771L41.2052 69.9504L43.9202 74.5617L46.6404 69.9504L81.0689 11.5044H73.7586L56.3647 41.0311Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M33.4248 40.355L38.9234 34.83L43.1068 39.5838L36.7419 45.9804L33.4248 40.355Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M94.3589 15.4447V26.1039H96.9101V21.6511H105.002V19.5277H96.9101V17.5628H105.251V15.4447H94.3589Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M110.533 18.5189H107.981V26.1039H110.533V18.5189ZM107.981 15.4447V17.5628H110.533V15.4447H107.981Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M115.889 18.5189H113.337V26.104H115.889V22.3431C115.889 20.9909 116.628 20.2673 117.917 20.2673H119.174C120.479 20.2673 120.97 20.8219 120.97 22.1424V26.104H123.521V21.6353C123.521 19.6704 122.386 18.5189 120.141 18.5189H118.081C116.486 18.5189 116.005 19.3007 115.883 19.5965V18.5189H115.889Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M133.869 26.1039H136.42V15.4447H133.869V19.6704C133.805 19.5489 133.288 18.5189 131.671 18.5189H129.4C127.329 18.5189 126.099 19.6862 126.099 21.5455V23.1248C126.099 24.8732 127.129 26.1039 129.4 26.1039H131.671C133.082 26.1039 133.869 25.1215 133.869 25.1215V26.1039ZM132.12 20.2672C133.208 20.2672 133.869 20.9275 133.869 21.7092V22.9241C133.869 23.7059 133.208 24.3503 132.12 24.3503H130.398C129.141 24.3503 128.65 23.859 128.65 22.9241V21.7251C128.65 20.8166 129.109 20.2672 130.398 20.2672H132.12Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M94.3218 30.4775L99.8045 37.5397V41.1367H102.356V37.5397L107.839 30.4775H104.627L101.067 35.4374L97.5333 30.4775H94.3218Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M111.769 33.5148C109.529 33.5148 108.436 34.8828 108.436 36.5572V38.1418C108.436 39.8902 109.635 41.1368 111.769 41.1368H115.334C117.5 41.1368 118.651 39.9061 118.651 38.1735V36.5625C118.651 34.8723 117.547 33.52 115.318 33.52H111.769V33.5148ZM116.1 36.758V37.9728C116.1 38.987 115.577 39.3831 114.457 39.3831H112.719C111.536 39.3831 110.981 38.9394 110.981 37.9834V36.7368C110.981 35.7544 111.536 35.2631 112.719 35.2631H114.457C115.577 35.2684 116.1 35.8653 116.1 36.758Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M121.229 33.5464V37.9252C121.229 40.1701 122.597 41.1367 124.53 41.1367H126.97C128.058 41.1367 128.798 40.7194 129.167 40.1701V41.1367H131.719V33.5517H129.167V37.3125C129.167 38.6489 128.259 39.3831 126.97 39.3831H125.972C124.498 39.3831 123.774 38.7545 123.774 37.3125V33.5517H121.229V33.5464Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M136.848 33.5464H134.296V41.1314H136.848V37.1223C136.848 36.0923 137.571 35.2947 138.596 35.2947H139.531C140.667 35.2947 140.899 35.8652 141.068 36.6311H143.619C143.619 35.0201 143.033 33.5464 140.302 33.5464H139.029C137.967 33.5464 137.466 33.8686 136.848 34.6503V33.5464Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M89.5997 51.5107H84.529C84.529 50.7712 84.8195 50.1268 85.8178 50.1268H88.1683C89.267 50.1321 89.5997 50.7765 89.5997 51.5107ZM92.0453 52.9263V51.6375C92.0453 50.1162 91.2953 48.5527 88.7916 48.5527H85.1681C82.8968 48.5527 81.9883 50.0106 81.9883 51.3469V53.2643C81.9883 54.9229 82.9866 56.1695 85.1205 56.1695H88.855C91.422 56.1695 92.0506 55.018 92.0506 53.6816H89.6103C89.6103 54.2785 89.3198 54.5848 88.7018 54.5848H85.7544C84.7085 54.5848 84.5395 53.877 84.5395 53.2168V52.9263H92.0453Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M94.3747 45.505L99.2923 50.6814L93.7778 56.1642H97.5228L101.305 51.9597L105.081 56.1642H108.832L103.317 50.6814L108.23 45.505H104.775L101.305 49.3926L97.8345 45.505H94.3747Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M113.253 48.5792H110.702V59.2384H113.253V55.1237C113.528 55.5674 114.341 56.1695 115.466 56.1695H117.753C120.025 56.1695 121.07 54.849 121.07 53.1905V51.5319C121.07 49.5987 119.887 48.5845 117.753 48.5845H115.45C114.283 48.5845 113.686 49.0916 113.253 49.493V48.5792ZM118.519 52.9898C118.519 53.9564 117.949 54.4159 116.739 54.4159H114.911C113.792 54.4159 113.253 53.9088 113.253 52.9898V51.759C113.253 50.8505 113.792 50.3329 114.911 50.3329H116.739C117.954 50.3329 118.519 50.8241 118.519 51.759V52.9898Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M131.265 51.5107H126.199C126.199 50.7712 126.49 50.1268 127.488 50.1268H129.839C130.927 50.1321 131.265 50.7765 131.265 51.5107ZM133.705 52.9263V51.6375C133.705 50.1162 132.955 48.5527 130.451 48.5527H126.828C124.556 48.5527 123.648 50.0106 123.648 51.3469V53.2643C123.648 54.9229 124.646 56.1695 126.78 56.1695H130.515C133.082 56.1695 133.71 55.018 133.71 53.6816H131.27C131.27 54.2785 130.979 54.5848 130.361 54.5848H127.414C126.368 54.5848 126.199 53.877 126.199 53.2168V52.9263H133.705Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M138.76 48.5792H136.208V56.1643H138.76V52.1552C138.76 51.1252 139.483 50.3276 140.508 50.3276H141.443C142.579 50.3276 142.811 50.898 142.98 51.6639H145.531C145.531 50.0529 144.945 48.5792 142.214 48.5792H140.941C139.88 48.5792 139.378 48.9014 138.76 49.6832V48.5792Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M148.368 47.1055V48.5792H147.443V50.3275H148.368V53.3383C148.368 55.0867 149.472 56.1642 151.442 56.1642H153.053C156.307 56.1642 156.74 54.6588 156.74 53.0636H154.189C154.189 53.8295 153.93 54.4158 153.19 54.4158H152.129C151.389 54.4158 150.914 54.0144 150.914 53.0636V50.3275H155.673V48.5792H150.914V47.1055H148.368Z\" fill=\"white\"/>\n        </svg>\n     </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n  \n  <ion-grid class=\"custGrid2\" *ngIf=\"mode == 'default'\">\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col size=\"10\" >\n       <ion-card class=\"bordernon w100\" >\n        <ion-card-header>\n          <ion-card-title>\n           <h3 class=\"custH\"><b>Login</b></h3> \n          </ion-card-title>\n        </ion-card-header>\n         <ion-grid>\n          <ion-row class=\"ion-text-center\">\n            <ion-col size=\"6\">\n              <ion-item button  color=\"light\">\n                <!-- <ion-icon name=\"logo-google\" color=\"red\"></ion-icon>  -->\n                <svg width=\"69\" height=\"20\" viewBox=\"0 0 69 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                  <path d=\"M14.5372 8.69437H14.0002V8.66671H8.00016V11.3334H11.7678C11.2182 12.8857 9.74116 14 8.00016 14C5.79116 14 4.00016 12.209 4.00016 10C4.00016 7.79104 5.79116 6.00004 8.00016 6.00004C9.01983 6.00004 9.9475 6.38471 10.6538 7.01304L12.5395 5.12737C11.3488 4.01771 9.75616 3.33337 8.00016 3.33337C4.3185 3.33337 1.3335 6.31837 1.3335 10C1.3335 13.6817 4.3185 16.6667 8.00016 16.6667C11.6818 16.6667 14.6668 13.6817 14.6668 10C14.6668 9.55304 14.6208 9.11671 14.5372 8.69437Z\" fill=\"#FFC107\"/>\n                  <path d=\"M2.10205 6.89704L4.29238 8.50337C4.88505 7.03604 6.32038 6.00004 8.00005 6.00004C9.01972 6.00004 9.94738 6.38471 10.6537 7.01304L12.5394 5.12737C11.3487 4.01771 9.75605 3.33337 8.00005 3.33337C5.43938 3.33337 3.21872 4.77904 2.10205 6.89704Z\" fill=\"#FF3D00\"/>\n                  <path d=\"M7.99994 16.6667C9.72194 16.6667 11.2866 16.0077 12.4696 14.936L10.4063 13.19C9.71445 13.7161 8.86909 14.0007 7.99994 14C6.26594 14 4.79361 12.8943 4.23894 11.3513L2.06494 13.0263C3.16827 15.1853 5.40894 16.6667 7.99994 16.6667Z\" fill=\"#4CAF50\"/>\n                  <path d=\"M14.537 8.69429H14V8.66663H8V11.3333H11.7677C11.5047 12.0721 11.0311 12.7177 10.4053 13.1903L10.4063 13.1896L12.4697 14.9356C12.3237 15.0683 14.6667 13.3333 14.6667 9.99996C14.6667 9.55296 14.6207 9.11663 14.537 8.69429Z\" fill=\"#1976D2\"/>\n                  <path d=\"M32.5107 10.0439V13.6875C32.3877 13.8698 32.1917 14.0749 31.9229 14.3027C31.654 14.526 31.2826 14.722 30.8086 14.8906C30.3392 15.0547 29.7331 15.1367 28.9902 15.1367C28.3841 15.1367 27.8258 15.0319 27.3154 14.8223C26.8096 14.6081 26.3698 14.2982 25.9961 13.8926C25.627 13.4824 25.3398 12.9857 25.1348 12.4023C24.9342 11.8145 24.834 11.1491 24.834 10.4062V9.63379C24.834 8.89095 24.9206 8.22786 25.0938 7.64453C25.2715 7.0612 25.5312 6.56673 25.873 6.16113C26.2148 5.75098 26.6341 5.44108 27.1309 5.23145C27.6276 5.01725 28.1973 4.91016 28.8398 4.91016C29.6009 4.91016 30.2367 5.04232 30.7471 5.30664C31.262 5.56641 31.6631 5.92643 31.9502 6.38672C32.2419 6.84701 32.4287 7.37109 32.5107 7.95898H31.1914C31.1322 7.59896 31.0137 7.27083 30.8359 6.97461C30.6628 6.67839 30.4144 6.44141 30.0908 6.26367C29.7673 6.08138 29.3503 5.99023 28.8398 5.99023C28.3796 5.99023 27.9808 6.07454 27.6436 6.24316C27.3063 6.41178 27.0283 6.65332 26.8096 6.96777C26.5908 7.28223 26.4268 7.66276 26.3174 8.10938C26.2126 8.55599 26.1602 9.05957 26.1602 9.62012V10.4062C26.1602 10.9805 26.2262 11.4932 26.3584 11.9443C26.4951 12.3955 26.6888 12.7806 26.9395 13.0996C27.1901 13.4141 27.4886 13.6533 27.835 13.8174C28.1859 13.9814 28.5732 14.0635 28.9971 14.0635C29.4665 14.0635 29.847 14.0247 30.1387 13.9473C30.4303 13.8652 30.6582 13.7695 30.8223 13.6602C30.9863 13.5462 31.1117 13.4391 31.1982 13.3389V11.1104H28.8945V10.0439H32.5107ZM34.1719 11.3838V11.2266C34.1719 10.6934 34.2493 10.1989 34.4043 9.74316C34.5592 9.28288 34.7826 8.88411 35.0742 8.54688C35.3659 8.20508 35.7191 7.94076 36.1338 7.75391C36.5485 7.5625 37.0133 7.4668 37.5283 7.4668C38.0479 7.4668 38.515 7.5625 38.9297 7.75391C39.349 7.94076 39.7044 8.20508 39.9961 8.54688C40.2923 8.88411 40.5179 9.28288 40.6729 9.74316C40.8278 10.1989 40.9053 10.6934 40.9053 11.2266V11.3838C40.9053 11.917 40.8278 12.4115 40.6729 12.8672C40.5179 13.3229 40.2923 13.7217 39.9961 14.0635C39.7044 14.4007 39.3512 14.665 38.9365 14.8564C38.5264 15.0433 38.0615 15.1367 37.542 15.1367C37.0225 15.1367 36.5553 15.0433 36.1406 14.8564C35.7259 14.665 35.3704 14.4007 35.0742 14.0635C34.7826 13.7217 34.5592 13.3229 34.4043 12.8672C34.2493 12.4115 34.1719 11.917 34.1719 11.3838ZM35.4365 11.2266V11.3838C35.4365 11.7529 35.4798 12.1016 35.5664 12.4297C35.653 12.7533 35.7829 13.0404 35.9561 13.291C36.1338 13.5417 36.3548 13.7399 36.6191 13.8857C36.8835 14.027 37.1911 14.0977 37.542 14.0977C37.8883 14.0977 38.1914 14.027 38.4512 13.8857C38.7155 13.7399 38.9342 13.5417 39.1074 13.291C39.2806 13.0404 39.4105 12.7533 39.4971 12.4297C39.5882 12.1016 39.6338 11.7529 39.6338 11.3838V11.2266C39.6338 10.862 39.5882 10.5179 39.4971 10.1943C39.4105 9.86621 39.2783 9.57682 39.1006 9.32617C38.9274 9.07096 38.7087 8.87044 38.4443 8.72461C38.1846 8.57878 37.8792 8.50586 37.5283 8.50586C37.182 8.50586 36.8766 8.57878 36.6123 8.72461C36.3525 8.87044 36.1338 9.07096 35.9561 9.32617C35.7829 9.57682 35.653 9.86621 35.5664 10.1943C35.4798 10.5179 35.4365 10.862 35.4365 11.2266ZM42.1562 11.3838V11.2266C42.1562 10.6934 42.2337 10.1989 42.3887 9.74316C42.5436 9.28288 42.7669 8.88411 43.0586 8.54688C43.3503 8.20508 43.7035 7.94076 44.1182 7.75391C44.5329 7.5625 44.9977 7.4668 45.5127 7.4668C46.0322 7.4668 46.4993 7.5625 46.9141 7.75391C47.3333 7.94076 47.6888 8.20508 47.9805 8.54688C48.2767 8.88411 48.5023 9.28288 48.6572 9.74316C48.8122 10.1989 48.8896 10.6934 48.8896 11.2266V11.3838C48.8896 11.917 48.8122 12.4115 48.6572 12.8672C48.5023 13.3229 48.2767 13.7217 47.9805 14.0635C47.6888 14.4007 47.3356 14.665 46.9209 14.8564C46.5107 15.0433 46.0459 15.1367 45.5264 15.1367C45.0068 15.1367 44.5397 15.0433 44.125 14.8564C43.7103 14.665 43.3548 14.4007 43.0586 14.0635C42.7669 13.7217 42.5436 13.3229 42.3887 12.8672C42.2337 12.4115 42.1562 11.917 42.1562 11.3838ZM43.4209 11.2266V11.3838C43.4209 11.7529 43.4642 12.1016 43.5508 12.4297C43.6374 12.7533 43.7673 13.0404 43.9404 13.291C44.1182 13.5417 44.3392 13.7399 44.6035 13.8857C44.8678 14.027 45.1755 14.0977 45.5264 14.0977C45.8727 14.0977 46.1758 14.027 46.4355 13.8857C46.6999 13.7399 46.9186 13.5417 47.0918 13.291C47.265 13.0404 47.3949 12.7533 47.4814 12.4297C47.5726 12.1016 47.6182 11.7529 47.6182 11.3838V11.2266C47.6182 10.862 47.5726 10.5179 47.4814 10.1943C47.3949 9.86621 47.2627 9.57682 47.085 9.32617C46.9118 9.07096 46.693 8.87044 46.4287 8.72461C46.1689 8.57878 45.8636 8.50586 45.5127 8.50586C45.1663 8.50586 44.861 8.57878 44.5967 8.72461C44.3369 8.87044 44.1182 9.07096 43.9404 9.32617C43.7673 9.57682 43.6374 9.86621 43.5508 10.1943C43.4642 10.5179 43.4209 10.862 43.4209 11.2266ZM55.2676 7.60352H56.416V14.8428C56.416 15.4945 56.2839 16.0505 56.0195 16.5107C55.7552 16.971 55.3861 17.3197 54.9121 17.5566C54.4427 17.7982 53.9004 17.9189 53.2852 17.9189C53.0299 17.9189 52.7292 17.8779 52.3828 17.7959C52.041 17.7184 51.7038 17.584 51.3711 17.3926C51.043 17.2057 50.7673 16.9528 50.5439 16.6338L51.207 15.8818C51.5169 16.2555 51.8405 16.5153 52.1777 16.6611C52.5195 16.807 52.8568 16.8799 53.1895 16.8799C53.5905 16.8799 53.9368 16.8047 54.2285 16.6543C54.5202 16.5039 54.7458 16.2806 54.9053 15.9844C55.0693 15.6927 55.1514 15.3327 55.1514 14.9043V9.23047L55.2676 7.60352ZM50.1748 11.3838V11.2402C50.1748 10.6751 50.2409 10.1624 50.373 9.70215C50.5098 9.2373 50.7035 8.83854 50.9541 8.50586C51.2093 8.17318 51.5169 7.91797 51.877 7.74023C52.237 7.55794 52.6426 7.4668 53.0938 7.4668C53.5586 7.4668 53.9642 7.54883 54.3105 7.71289C54.6615 7.8724 54.9577 8.1071 55.1992 8.41699C55.4453 8.72233 55.639 9.09147 55.7803 9.52441C55.9215 9.95736 56.0195 10.4473 56.0742 10.9941V11.623C56.0241 12.1654 55.9261 12.653 55.7803 13.0859C55.639 13.5189 55.4453 13.888 55.1992 14.1934C54.9577 14.4987 54.6615 14.7334 54.3105 14.8975C53.9596 15.057 53.5495 15.1367 53.0801 15.1367C52.638 15.1367 52.237 15.0433 51.877 14.8564C51.5215 14.6696 51.2161 14.4076 50.9609 14.0703C50.7057 13.7331 50.5098 13.3366 50.373 12.8809C50.2409 12.4206 50.1748 11.9215 50.1748 11.3838ZM51.4395 11.2402V11.3838C51.4395 11.7529 51.4759 12.0993 51.5488 12.4229C51.6263 12.7464 51.7425 13.0312 51.8975 13.2773C52.057 13.5234 52.2598 13.7171 52.5059 13.8584C52.752 13.9951 53.0459 14.0635 53.3877 14.0635C53.807 14.0635 54.1533 13.9746 54.4268 13.7969C54.7002 13.6191 54.9167 13.3844 55.0762 13.0928C55.2402 12.8011 55.3678 12.4844 55.459 12.1426V10.4951C55.4089 10.2445 55.3314 10.0029 55.2266 9.77051C55.1263 9.53353 54.9941 9.32389 54.8301 9.1416C54.6706 8.95475 54.4723 8.80664 54.2354 8.69727C53.9984 8.58789 53.7204 8.5332 53.4014 8.5332C53.055 8.5332 52.7565 8.60612 52.5059 8.75195C52.2598 8.89323 52.057 9.08919 51.8975 9.33984C51.7425 9.58594 51.6263 9.87305 51.5488 10.2012C51.4759 10.5247 51.4395 10.8711 51.4395 11.2402ZM59.7109 4.5V15H58.4395V4.5H59.7109ZM64.8105 15.1367C64.2956 15.1367 63.8285 15.0501 63.4092 14.877C62.9945 14.6992 62.6367 14.4508 62.3359 14.1318C62.0397 13.8128 61.8118 13.4346 61.6523 12.9971C61.4928 12.5596 61.4131 12.0811 61.4131 11.5615V11.2744C61.4131 10.6729 61.502 10.1374 61.6797 9.66797C61.8574 9.19401 62.099 8.79297 62.4043 8.46484C62.7096 8.13672 63.056 7.88835 63.4434 7.71973C63.8307 7.55111 64.2318 7.4668 64.6465 7.4668C65.1751 7.4668 65.6309 7.55794 66.0137 7.74023C66.401 7.92253 66.7178 8.17773 66.9639 8.50586C67.21 8.82943 67.3923 9.21224 67.5107 9.6543C67.6292 10.0918 67.6885 10.5703 67.6885 11.0898V11.6572H62.165V10.625H66.4238V10.5293C66.4056 10.2012 66.3372 9.88216 66.2188 9.57227C66.1048 9.26237 65.9225 9.00716 65.6719 8.80664C65.4212 8.60612 65.0794 8.50586 64.6465 8.50586C64.3594 8.50586 64.0951 8.56738 63.8535 8.69043C63.612 8.80892 63.4046 8.98665 63.2314 9.22363C63.0583 9.46061 62.9238 9.75 62.8281 10.0918C62.7324 10.4336 62.6846 10.8278 62.6846 11.2744V11.5615C62.6846 11.9124 62.7324 12.2428 62.8281 12.5527C62.9284 12.8581 63.0719 13.127 63.2588 13.3594C63.4502 13.5918 63.6803 13.7741 63.9492 13.9062C64.2227 14.0384 64.5326 14.1045 64.8789 14.1045C65.3255 14.1045 65.7038 14.0133 66.0137 13.8311C66.3236 13.6488 66.5947 13.4049 66.8271 13.0996L67.5928 13.708C67.4333 13.9495 67.2305 14.1797 66.9844 14.3984C66.7383 14.6172 66.4352 14.7949 66.0752 14.9316C65.7197 15.0684 65.2982 15.1367 64.8105 15.1367Z\" fill=\"#475569\"/>\n                  </svg>\n              </ion-item>\n            </ion-col>\n            <ion-col size=\"6\">\n              <ion-item button color=\"light\">\n                <!-- <ion-icon name=\"logo-facebook\"></ion-icon> -->\n                <svg width=\"85\" height=\"20\" viewBox=\"0 0 85 20\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                  <g clip-path=\"url(#clip0_42_52)\">\n                  <path d=\"M6.66667 17.9111C2.88889 17.2444 0 13.9556 0 10C0 5.6 3.6 2 8 2C12.4 2 16 5.6 16 10C16 13.9556 13.1111 17.2444 9.33333 17.9111L8.88889 17.5556H7.11111L6.66667 17.9111Z\" fill=\"url(#paint0_linear_42_52)\"/>\n                  <path d=\"M11.1109 12.2222L11.4665 9.99997H9.33317V8.44442C9.33317 7.8222 9.55539 7.33331 10.5332 7.33331H11.5554V5.28886C10.9776 5.19997 10.3554 5.11108 9.77762 5.11108C7.95539 5.11108 6.6665 6.2222 6.6665 8.2222V9.99997H4.6665V12.2222H6.6665V17.8666C7.11095 17.9555 7.55539 18 7.99984 18C8.44428 18 8.88873 17.9555 9.33317 17.8666V12.2222H11.1109Z\" fill=\"white\"/>\n                  </g>\n                  <path d=\"M26.4746 5.04688V15H25.1553V5.04688H26.4746ZM30.6445 9.52441V10.6045H26.1875V9.52441H30.6445ZM31.3213 5.04688V6.12695H26.1875V5.04688H31.3213ZM36.8311 13.7354V9.92773C36.8311 9.63607 36.7718 9.38314 36.6533 9.16895C36.5394 8.9502 36.3662 8.78158 36.1338 8.66309C35.9014 8.5446 35.6143 8.48535 35.2725 8.48535C34.9535 8.48535 34.6732 8.54004 34.4316 8.64941C34.1947 8.75879 34.0078 8.90234 33.8711 9.08008C33.7389 9.25781 33.6729 9.44922 33.6729 9.6543H32.4082C32.4082 9.38997 32.4766 9.12793 32.6133 8.86816C32.75 8.6084 32.946 8.3737 33.2012 8.16406C33.4609 7.94987 33.7708 7.78125 34.1309 7.6582C34.4954 7.5306 34.901 7.4668 35.3477 7.4668C35.8854 7.4668 36.3594 7.55794 36.7695 7.74023C37.1842 7.92253 37.5078 8.19824 37.7402 8.56738C37.9772 8.93197 38.0957 9.38997 38.0957 9.94141V13.3867C38.0957 13.6328 38.1162 13.8949 38.1572 14.1729C38.2028 14.4508 38.2689 14.6901 38.3555 14.8906V15H37.0361C36.9723 14.8542 36.9222 14.6605 36.8857 14.4189C36.8493 14.1729 36.8311 13.945 36.8311 13.7354ZM37.0498 10.5156L37.0635 11.4043H35.7852C35.4251 11.4043 35.1038 11.4339 34.8213 11.4932C34.5387 11.5479 34.3018 11.6322 34.1104 11.7461C33.9189 11.86 33.7731 12.0036 33.6729 12.1768C33.5726 12.3454 33.5225 12.5436 33.5225 12.7715C33.5225 13.0039 33.5749 13.2158 33.6797 13.4072C33.7845 13.5986 33.9417 13.7513 34.1514 13.8652C34.3656 13.9746 34.6276 14.0293 34.9375 14.0293C35.3249 14.0293 35.6667 13.9473 35.9629 13.7832C36.2591 13.6191 36.4938 13.4186 36.667 13.1816C36.8447 12.9447 36.9404 12.7145 36.9541 12.4912L37.4941 13.0996C37.4622 13.291 37.3757 13.5029 37.2344 13.7354C37.0931 13.9678 36.904 14.1911 36.667 14.4053C36.4346 14.6149 36.1566 14.7904 35.833 14.9316C35.514 15.0684 35.154 15.1367 34.7529 15.1367C34.2516 15.1367 33.8118 15.0387 33.4336 14.8428C33.0599 14.6468 32.7682 14.3848 32.5586 14.0566C32.3535 13.724 32.251 13.3525 32.251 12.9424C32.251 12.5459 32.3285 12.1973 32.4834 11.8965C32.6383 11.5911 32.8617 11.3382 33.1533 11.1377C33.445 10.9326 33.7959 10.7777 34.2061 10.6729C34.6162 10.568 35.0742 10.5156 35.5801 10.5156H37.0498ZM43.0449 14.0977C43.3457 14.0977 43.6237 14.0361 43.8789 13.9131C44.1341 13.79 44.3438 13.6214 44.5078 13.4072C44.6719 13.1885 44.7653 12.9401 44.7881 12.6621H45.9912C45.9684 13.0996 45.8203 13.5075 45.5469 13.8857C45.278 14.2594 44.9248 14.5625 44.4873 14.7949C44.0498 15.0228 43.569 15.1367 43.0449 15.1367C42.4889 15.1367 42.0036 15.0387 41.5889 14.8428C41.1787 14.6468 40.8369 14.3779 40.5635 14.0361C40.2946 13.6943 40.0918 13.3024 39.9551 12.8604C39.8229 12.4137 39.7568 11.9421 39.7568 11.4453V11.1582C39.7568 10.6615 39.8229 10.1921 39.9551 9.75C40.0918 9.30339 40.2946 8.90918 40.5635 8.56738C40.8369 8.22559 41.1787 7.95671 41.5889 7.76074C42.0036 7.56478 42.4889 7.4668 43.0449 7.4668C43.6237 7.4668 44.1296 7.58529 44.5625 7.82227C44.9954 8.05469 45.335 8.3737 45.5811 8.7793C45.8317 9.18034 45.9684 9.63607 45.9912 10.1465H44.7881C44.7653 9.84115 44.6787 9.56543 44.5283 9.31934C44.3825 9.07324 44.182 8.87728 43.9268 8.73145C43.6761 8.58105 43.3822 8.50586 43.0449 8.50586C42.6576 8.50586 42.3317 8.58333 42.0674 8.73828C41.8076 8.88867 41.6003 9.09375 41.4453 9.35352C41.2949 9.60872 41.1855 9.89355 41.1172 10.208C41.0534 10.5179 41.0215 10.8346 41.0215 11.1582V11.4453C41.0215 11.7689 41.0534 12.0879 41.1172 12.4023C41.181 12.7168 41.2881 13.0016 41.4385 13.2568C41.5934 13.512 41.8008 13.7171 42.0605 13.8721C42.3249 14.0225 42.653 14.0977 43.0449 14.0977ZM50.4824 15.1367C49.9674 15.1367 49.5003 15.0501 49.0811 14.877C48.6663 14.6992 48.3086 14.4508 48.0078 14.1318C47.7116 13.8128 47.4837 13.4346 47.3242 12.9971C47.1647 12.5596 47.085 12.0811 47.085 11.5615V11.2744C47.085 10.6729 47.1738 10.1374 47.3516 9.66797C47.5293 9.19401 47.7708 8.79297 48.0762 8.46484C48.3815 8.13672 48.7279 7.88835 49.1152 7.71973C49.5026 7.55111 49.9036 7.4668 50.3184 7.4668C50.847 7.4668 51.3027 7.55794 51.6855 7.74023C52.0729 7.92253 52.3896 8.17773 52.6357 8.50586C52.8818 8.82943 53.0641 9.21224 53.1826 9.6543C53.3011 10.0918 53.3604 10.5703 53.3604 11.0898V11.6572H47.8369V10.625H52.0957V10.5293C52.0775 10.2012 52.0091 9.88216 51.8906 9.57227C51.7767 9.26237 51.5944 9.00716 51.3438 8.80664C51.0931 8.60612 50.7513 8.50586 50.3184 8.50586C50.0312 8.50586 49.7669 8.56738 49.5254 8.69043C49.2839 8.80892 49.0765 8.98665 48.9033 9.22363C48.7301 9.46061 48.5957 9.75 48.5 10.0918C48.4043 10.4336 48.3564 10.8278 48.3564 11.2744V11.5615C48.3564 11.9124 48.4043 12.2428 48.5 12.5527C48.6003 12.8581 48.7438 13.127 48.9307 13.3594C49.1221 13.5918 49.3522 13.7741 49.6211 13.9062C49.8945 14.0384 50.2044 14.1045 50.5508 14.1045C50.9974 14.1045 51.3757 14.0133 51.6855 13.8311C51.9954 13.6488 52.2666 13.4049 52.499 13.0996L53.2646 13.708C53.1051 13.9495 52.9023 14.1797 52.6562 14.3984C52.4102 14.6172 52.1071 14.7949 51.7471 14.9316C51.3916 15.0684 50.9701 15.1367 50.4824 15.1367ZM54.8301 4.5H56.1016V13.5645L55.9922 15H54.8301V4.5ZM61.0986 11.2402V11.3838C61.0986 11.9215 61.0348 12.4206 60.9072 12.8809C60.7796 13.3366 60.5928 13.7331 60.3467 14.0703C60.1006 14.4076 59.7998 14.6696 59.4443 14.8564C59.0889 15.0433 58.681 15.1367 58.2207 15.1367C57.7513 15.1367 57.3389 15.057 56.9834 14.8975C56.6325 14.7334 56.3363 14.4987 56.0947 14.1934C55.8532 13.888 55.6595 13.5189 55.5137 13.0859C55.3724 12.653 55.2744 12.1654 55.2197 11.623V10.9941C55.2744 10.4473 55.3724 9.95736 55.5137 9.52441C55.6595 9.09147 55.8532 8.72233 56.0947 8.41699C56.3363 8.1071 56.6325 7.8724 56.9834 7.71289C57.3343 7.54883 57.7422 7.4668 58.207 7.4668C58.6719 7.4668 59.0843 7.55794 59.4443 7.74023C59.8044 7.91797 60.1051 8.17318 60.3467 8.50586C60.5928 8.83854 60.7796 9.2373 60.9072 9.70215C61.0348 10.1624 61.0986 10.6751 61.0986 11.2402ZM59.8271 11.3838V11.2402C59.8271 10.8711 59.793 10.5247 59.7246 10.2012C59.6562 9.87305 59.5469 9.58594 59.3965 9.33984C59.2461 9.08919 59.0479 8.89323 58.8018 8.75195C58.5557 8.60612 58.2526 8.5332 57.8926 8.5332C57.5736 8.5332 57.2956 8.58789 57.0586 8.69727C56.8262 8.80664 56.6279 8.95475 56.4639 9.1416C56.2998 9.32389 56.1654 9.53353 56.0605 9.77051C55.9603 10.0029 55.8851 10.2445 55.835 10.4951V12.1426C55.9079 12.4616 56.0264 12.7692 56.1904 13.0654C56.359 13.3571 56.5824 13.5964 56.8604 13.7832C57.1429 13.9701 57.4915 14.0635 57.9062 14.0635C58.248 14.0635 58.5397 13.9951 58.7812 13.8584C59.0273 13.7171 59.2256 13.5234 59.376 13.2773C59.5309 13.0312 59.6449 12.7464 59.7178 12.4229C59.7907 12.0993 59.8271 11.7529 59.8271 11.3838ZM62.3633 11.3838V11.2266C62.3633 10.6934 62.4408 10.1989 62.5957 9.74316C62.7507 9.28288 62.974 8.88411 63.2656 8.54688C63.5573 8.20508 63.9105 7.94076 64.3252 7.75391C64.7399 7.5625 65.2048 7.4668 65.7197 7.4668C66.2393 7.4668 66.7064 7.5625 67.1211 7.75391C67.5404 7.94076 67.8958 8.20508 68.1875 8.54688C68.4837 8.88411 68.7093 9.28288 68.8643 9.74316C69.0192 10.1989 69.0967 10.6934 69.0967 11.2266V11.3838C69.0967 11.917 69.0192 12.4115 68.8643 12.8672C68.7093 13.3229 68.4837 13.7217 68.1875 14.0635C67.8958 14.4007 67.5426 14.665 67.1279 14.8564C66.7178 15.0433 66.2529 15.1367 65.7334 15.1367C65.2139 15.1367 64.7467 15.0433 64.332 14.8564C63.9173 14.665 63.5618 14.4007 63.2656 14.0635C62.974 13.7217 62.7507 13.3229 62.5957 12.8672C62.4408 12.4115 62.3633 11.917 62.3633 11.3838ZM63.6279 11.2266V11.3838C63.6279 11.7529 63.6712 12.1016 63.7578 12.4297C63.8444 12.7533 63.9743 13.0404 64.1475 13.291C64.3252 13.5417 64.5462 13.7399 64.8105 13.8857C65.0749 14.027 65.3825 14.0977 65.7334 14.0977C66.0798 14.0977 66.3828 14.027 66.6426 13.8857C66.9069 13.7399 67.1257 13.5417 67.2988 13.291C67.472 13.0404 67.6019 12.7533 67.6885 12.4297C67.7796 12.1016 67.8252 11.7529 67.8252 11.3838V11.2266C67.8252 10.862 67.7796 10.5179 67.6885 10.1943C67.6019 9.86621 67.4697 9.57682 67.292 9.32617C67.1188 9.07096 66.9001 8.87044 66.6357 8.72461C66.376 8.57878 66.0706 8.50586 65.7197 8.50586C65.3734 8.50586 65.068 8.57878 64.8037 8.72461C64.5439 8.87044 64.3252 9.07096 64.1475 9.32617C63.9743 9.57682 63.8444 9.86621 63.7578 10.1943C63.6712 10.5179 63.6279 10.862 63.6279 11.2266ZM70.3477 11.3838V11.2266C70.3477 10.6934 70.4251 10.1989 70.5801 9.74316C70.735 9.28288 70.9583 8.88411 71.25 8.54688C71.5417 8.20508 71.8949 7.94076 72.3096 7.75391C72.7243 7.5625 73.1891 7.4668 73.7041 7.4668C74.2236 7.4668 74.6908 7.5625 75.1055 7.75391C75.5247 7.94076 75.8802 8.20508 76.1719 8.54688C76.4681 8.88411 76.6937 9.28288 76.8486 9.74316C77.0036 10.1989 77.0811 10.6934 77.0811 11.2266V11.3838C77.0811 11.917 77.0036 12.4115 76.8486 12.8672C76.6937 13.3229 76.4681 13.7217 76.1719 14.0635C75.8802 14.4007 75.527 14.665 75.1123 14.8564C74.7021 15.0433 74.2373 15.1367 73.7178 15.1367C73.1982 15.1367 72.7311 15.0433 72.3164 14.8564C71.9017 14.665 71.5462 14.4007 71.25 14.0635C70.9583 13.7217 70.735 13.3229 70.5801 12.8672C70.4251 12.4115 70.3477 11.917 70.3477 11.3838ZM71.6123 11.2266V11.3838C71.6123 11.7529 71.6556 12.1016 71.7422 12.4297C71.8288 12.7533 71.9587 13.0404 72.1318 13.291C72.3096 13.5417 72.5306 13.7399 72.7949 13.8857C73.0592 14.027 73.3669 14.0977 73.7178 14.0977C74.0641 14.0977 74.3672 14.027 74.627 13.8857C74.8913 13.7399 75.11 13.5417 75.2832 13.291C75.4564 13.0404 75.5863 12.7533 75.6729 12.4297C75.764 12.1016 75.8096 11.7529 75.8096 11.3838V11.2266C75.8096 10.862 75.764 10.5179 75.6729 10.1943C75.5863 9.86621 75.4541 9.57682 75.2764 9.32617C75.1032 9.07096 74.8844 8.87044 74.6201 8.72461C74.3604 8.57878 74.055 8.50586 73.7041 8.50586C73.3577 8.50586 73.0524 8.57878 72.7881 8.72461C72.5283 8.87044 72.3096 9.07096 72.1318 9.32617C71.9587 9.57682 71.8288 9.86621 71.7422 10.1943C71.6556 10.5179 71.6123 10.862 71.6123 11.2266ZM79.9385 4.5V15H78.667V4.5H79.9385ZM84.457 7.60352L81.2305 11.0557L79.4258 12.9287L79.3232 11.582L80.6152 10.0371L82.9121 7.60352H84.457ZM83.3018 15L80.6631 11.4727L81.3193 10.3447L84.792 15H83.3018Z\" fill=\"#475569\"/>\n                  <defs>\n                  <linearGradient id=\"paint0_linear_42_52\" x1=\"8\" y1=\"17.4462\" x2=\"8\" y2=\"2\" gradientUnits=\"userSpaceOnUse\">\n                  <stop stop-color=\"#0062E0\"/>\n                  <stop offset=\"1\" stop-color=\"#19AFFF\"/>\n                  </linearGradient>\n                  <clipPath id=\"clip0_42_52\">\n                  <rect width=\"16\" height=\"16\" fill=\"white\" transform=\"translate(0 2)\"/>\n                  </clipPath>\n                  </defs>\n                  </svg>\n              </ion-item>\n            </ion-col>\n          </ion-row>\n          <ion-row class=\"ion-margin\">\n            <ion-col size=\"3\" class=\"padd1\">\n              <svg width=\"100\" height=\"1\" viewBox=\"0 0 93 1\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                <rect opacity=\"0.4\" width=\"93\" height=\"1\" fill=\"#191B1D\"/>\n              </svg>\n            </ion-col>\n            <ion-col size=\"5\" class=\"ion-text-center padd1\" >\n               <ion-label>Or login with</ion-label>\n            </ion-col>\n            <ion-col size=\"3\" class=\"padd1\">\n              <svg width=\"100\" height=\"1\" viewBox=\"0 0 93 1\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                <rect opacity=\"0.4\" width=\"93\" height=\"1\" fill=\"#191B1D\"/>\n              </svg>\n            </ion-col>\n          </ion-row>\n          \n          <ion-row class=\"ion-margin\">\n            <ion-list class=\"w100\">\n              <ion-item >\n                <ion-label position=\"floating\">E-mail</ion-label> \n                <ion-input></ion-input>\n                <!-- <ion-icon name=\"eye-outline\"></ion-icon> -->\n                <ion-icon slot=\"end\" name=\"checkmark-outline\" ></ion-icon>\n              </ion-item>\n              <ion-item>\n                <ion-label position=\"floating\">Password</ion-label> \n                <ion-input></ion-input>\n                <ion-icon  slot=\"end\"  color=\"success\" name=\"eye-off-outline\"></ion-icon>\n              </ion-item>\n              <ion-row class=\"ion-justify-content-end\">\n                <ion-button fill=\"clear\" (click)=\"froget()\">\n                  <ion-label><ion-text color=\"primary\"><b>Forget?</b></ion-text></ion-label>\n                </ion-button>\n              </ion-row> \n            </ion-list>\n          </ion-row> \n          <ion-row class=\"ion-margin\">\n            <ion-col size=\"12\">\n              <ion-item color=\"primary\" button (click)=\"login()\">\n                <ion-label class=\"ion-text-center\">LOGIN</ion-label>\n                \n              </ion-item>\n            </ion-col>\n          </ion-row> \n         </ion-grid> \n        </ion-card>\n      </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"mode == 'google'\">\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <ion-button fill=\"clear\" (click)=\"signUp()\">\n            <ion-label color=\"medium\">Don't have account? <ion-text color=\"dark\"><strong>Sign Up</strong> </ion-text></ion-label>\n  \n          </ion-button>\n        </ion-col>\n      </ion-row>\n  </ion-grid>\n \n\n  <ion-grid class=\"custGrid2 \" *ngIf=\"mode == 'phone'\">\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col size=\"10\" >\n       <ion-card class=\"bordernon w100\" >\n        <ion-card-header>\n          <ion-card-title  >\n           <h3 class=\"ion-text-center\"><b>تسجيل دخول</b></h3> \n          </ion-card-title>\n        </ion-card-header>\n         <ion-grid>\n          <form [formGroup]=\"ionicForm\" (ngSubmit)=\"login()\" novalidate>\n          <ion-row class=\"ion-margin\">\n            <ion-list class=\"w100\">\n              <ion-label> <ion-text color=\"dark\">رقم الجوال </ion-text></ion-label>\n              <ion-item dir=\"ltr\">  \n                <ion-input   formControlName=\"phone\"  type=\"tel\" placeholder=\"912238433\"  [(ngModel)]=\"phone\">\n                  <ion-label slot=\"start\">+966</ion-label>\n                </ion-input>\n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.phone.errors?.pattern\">ادخل ارقام فقط  </ion-note> \n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.phone.errors?.required\">رقم الجوال مطلوب </ion-note>\n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && (errorControl.phone.errors?.minlength || errorControl.phone.errors?.maxlength)\">يجب ان يتكون من 9 أرقام </ion-note> \n              </ion-item> \n              <!-- <ion-row class=\"ion-justify-content-end\">\n                <ion-button fill=\"clear\" (click)=\"froget()\">\n                  <ion-label><ion-text color=\"primary\"><b>Forget?</b></ion-text></ion-label>\n                </ion-button>\n              </ion-row>  -->\n            </ion-list>\n          </ion-row> \n          <ion-row class=\"ion-margin\">\n            <ion-col size=\"12\">\n              <ion-item [disabled]=\"spinner == true\" color=\"primary\" button (click)=\"login()\"> \n                <ion-label class=\"ion-text-center\">دخــول</ion-label>\n                <ion-spinner name=\"lines\" color=\"light\" *ngIf=\"spinner == true\"></ion-spinner> \n              </ion-item>\n            </ion-col>\n          </ion-row> \n          </form>\n         </ion-grid> \n        </ion-card>\n      </ion-col>\n    </ion-row>\n       <!-- <ion-row>\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <ion-button fill=\"clear\" (click)=\"signUp()\">\n            <ion-label color=\"medium\">Don't have account? <ion-text color=\"dark\"><strong>Sign Up</strong> </ion-text></ion-label>\n  \n          </ion-button>\n        </ion-col>\n      </ion-row>  -->\n  </ion-grid>\n\n\n  <!-- login with google -->\n\n  <ion-grid class=\"custGrid2\" *ngIf=\"mode == 'google'\">\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col size=\"10\" >\n       <ion-card class=\"bordernon w100\" >\n        <ion-card-header>\n          <ion-card-title  >\n           <h3 class=\"ion-text-center\"><b>تسجيل دخول</b></h3> \n          </ion-card-title>\n        </ion-card-header>\n         <ion-grid>\n          <form [formGroup]=\"ionic2Form\" (ngSubmit)=\"login()\" novalidate>\n\n          <ion-row class=\"ion-margin\">\n            <ion-list class=\"w100\"> \n              <ion-item>  \n                <!-- <ion-label  position=\"floating\"> <ion-text color=\"dark\"> </ion-text></ion-label> -->\n                <ion-input   formControlName=\"email\"  type=\"email\" placeholder=\"البريد الإلكتروني \"  [(ngModel)]=\"email\">\n                 \n                </ion-input>\n                <ion-note slot=\"error\" *ngIf=\"isSubmitted2 == true && error2Control.email.errors?.required\"> الحقل مطلوب </ion-note> \n                <ion-note slot=\"error\" *ngIf=\"isSubmitted2 == true && error2Control.email.errors?.pattern\">    خطأ في صيغة البريد  </ion-note>\n              </ion-item> \n\n              \n              <ion-item> \n                <!-- <ion-label position=\"floating\"> <ion-text color=\"dark\"> </ion-text></ion-label>  -->\n                <ion-input   formControlName=\"password\" type=\"password\" placeholder=\"المرور كلمة\"  [(ngModel)]=\"password\">\n                </ion-input>\n                <ion-note slot=\"error\" *ngIf=\"isSubmitted2 == true && error2Control.password.errors?.required\"> الحقل مطلوب </ion-note> \n\n              </ion-item>\n            </ion-list>\n          </ion-row> \n          <ion-row>\n            <ion-col size=\"12\">\n              <ion-item [disabled]=\"spinner == true\" color=\"primary\" button (click)=\"login()\"> \n                <ion-label class=\"ion-text-center\">دخــول</ion-label>\n                <ion-spinner name=\"lines\" color=\"light\" *ngIf=\"spinner == true\"></ion-spinner> \n              </ion-item>\n            </ion-col>\n          </ion-row> \n           <ion-row class=\"ion-justify-content-start\">\n                <ion-button fill=\"clear\" (click)=\"froget()\">\n                  <ion-label><ion-text color=\"primary\"><b>نسيت كلمة السر؟</b></ion-text></ion-label>\n                </ion-button>\n          </ion-row>\n        </form> \n        <ion-row class=\" ion-justify-content-center\"> \n          <ion-col size=\"3\" class=\"ion-text-center\">\n            <ion-label><h3>أو</h3></ion-label>\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col size=\"6\">\n            <ion-item [disabled]=\"spinner == true\" color=\"primary\" button (click)=\"getInfo('google')\"> \n              <ion-label class=\"ion-text-center\">google</ion-label>\n              <ion-icon name=\"logo-google\" color=\"danger\"></ion-icon>\n            </ion-item>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-item [disabled]=\"spinner == true\" color=\"primary\" button (click)=\"getInfo('apple')\"> \n              <ion-label class=\"ion-text-center\">Apple</ion-label>\n              <ion-icon name=\"logo-apple\" ></ion-icon>\n            </ion-item>\n          </ion-col>\n        </ion-row>\n        <ion-footer>\n          <ion-grid>\n            <ion-row class=\"ion-justify-content-center\"> \n              <ion-col size=\"12\">\n                <ion-button fill=\"clear\" (click)=\"signUp()\">\n                  <ion-label><ion-text>ليس لديك حساب ؟ </ion-text>\n                    \n                  <ion-text color=\"success\">انشاء حساب</ion-text>\n                </ion-label>\n                </ion-button>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-footer>\n         </ion-grid> \n        </ion-card>\n      </ion-col>\n    </ion-row>\n      <!-- <ion-row>\n        <ion-col size=\"12\" class=\"ion-text-center\">\n          <ion-button fill=\"clear\" (click)=\"signUp()\">\n            <ion-label color=\"medium\">Don't have account? <ion-text color=\"dark\"><strong>Sign Up</strong> </ion-text></ion-label>\n  \n          </ion-button>\n        </ion-col>\n      </ion-row> -->\n  </ion-grid>\n</ion-content>\n \n";

/***/ })

}]);
//# sourceMappingURL=src_app_login_login_module_ts.js.map