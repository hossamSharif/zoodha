"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_profile_profile_module_ts"],{

/***/ 6829:
/*!***************************************************!*\
  !*** ./src/app/profile/profile-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageRoutingModule": () => (/* binding */ ProfilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile.page */ 2919);




const routes = [
    {
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_0__.ProfilePage
    }
];
let ProfilePageRoutingModule = class ProfilePageRoutingModule {
};
ProfilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProfilePageRoutingModule);



/***/ }),

/***/ 4523:
/*!*******************************************!*\
  !*** ./src/app/profile/profile.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageModule": () => (/* binding */ ProfilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile-routing.module */ 6829);
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.page */ 2919);







let ProfilePageModule = class ProfilePageModule {
};
ProfilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProfilePageRoutingModule
        ],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_1__.ProfilePage]
    })
], ProfilePageModule);



/***/ }),

/***/ 2919:
/*!*****************************************!*\
  !*** ./src/app/profile/profile.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePage": () => (/* binding */ ProfilePage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.page.html?ngResource */ 8907);
/* harmony import */ var _profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./profile.page.scss?ngResource */ 6611);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/socket-service.service */ 905);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ 190);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);










let ProfilePage = class ProfilePage {
  constructor(formBuilder, toast, api, storage, rout) {
    this.formBuilder = formBuilder;
    this.toast = toast;
    this.api = api;
    this.storage = storage;
    this.rout = rout;
    this.errorLoad = false;
    this.spinner = false;
    this.isSubmitted = false;
    this.isOpen = false;
    this.ionicForm = this.formBuilder.group({
      firstName: [''],
      lastName: [''],
      fullName: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.minLength(4), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.pattern('[a-zA-Z][a-zA-Z ]+')]],
      email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
      birth: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required],
      gender: [''],
      phone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.minLength(9), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.maxLength(9), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.pattern('^[0-9]+$')]]
    });
  }

  ngOnInit() {
    this.getProfile();
  }

  presentPopover(e) {
    this.popover.event = e;
    this.isOpen = true;
  }

  getProfile() {
    console.log('im here bro');
    this.storage.get('token').then(response => {
      if (response) {
        console.log('token', response);
        this.api.auth(response).subscribe(data => {
          console.log('authservices', data);
          this.USER_INFO = data['user'];
          console.log(this.USER_INFO);
        }, err => {
          console.log(err);
          this.errorLoad = true;
        });
      } else {
        this.rout.navigate(['login']);
      }
    });
  }

  reload() {
    this.errorLoad = false;
    this.USER_INFO = undefined;
    this.getProfile();
  }

  get errorControl() {
    return this.ionicForm.controls;
  }

  dateChange(ev) {
    console.log(ev.target.value);
    this.isOpen = false;
  }

  genderChange(ev) {
    console.log(ev);
  }

  validate() {
    this.isSubmitted = true;

    if (this.ionicForm.valid == false) {
      console.log('Please provide all the required values!');
      return false;
    } else {
      return true;
    }
  }

  update() {
    if (this.validate() == true) {
      this.spinner = true;
      this.api.updateUser(this.USER_INFO).subscribe(data => {
        console.log('user was updated', data);
        let res = data;
        console.log('user was created', res['token']);
        this.storage.set('token', res['token']).then(response => {
          this.rout.navigate(['tabs/home']);
        });
      }, err => {
        console.log();
        this.spinner = false;
        this.handleError(err.error.error);
      }, () => {
        this.spinner = false;
      });
    }
  }

  handleError(msg) {
    if (msg == "duplicate phone") {
      this.presentToast('رقم الهاتف موجود مسبقا , قم بتسجيل الدخول', 'danger');
      return false;
    } else if (msg == "duplicate email") {
      this.presentToast("البريد موجود مسبقا", 'danger');
      return false;
    }
  }

  presentToast(msg, color) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  }

  changePhone() {
    console.log('asdhlaks');
    this.rout.navigate(['change-phone']);
  }

};

ProfilePage.ctorParameters = () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService
}, {
  type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__.Storage
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}];

ProfilePage.propDecorators = {
  popover: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: ['popover']
  }]
};
ProfilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-profile',
  template: _profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ProfilePage);


/***/ }),

/***/ 6611:
/*!******************************************************!*\
  !*** ./src/app/profile/profile.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = ".custIcon {\n  font-size: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2ZpbGUucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFxodXNhbSUyMHByb2pcXHpvb2RvaGFTZFxcc3JjXFxhcHBcXHByb2ZpbGVcXHByb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBQTtBQ0NKIiwiZmlsZSI6InByb2ZpbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmN1c3RJY29ue1xyXG4gICAgZm9udC1zaXplIDogMzBweCA7XHJcbn0iLCIuY3VzdEljb24ge1xuICBmb250LXNpemU6IDMwcHg7XG59Il19 */";

/***/ }),

/***/ 8907:
/*!******************************************************!*\
  !*** ./src/app/profile/profile.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar dir=\"rtl\">\n    <ion-title>\n      <ion-icon name=\"person-outline\"></ion-icon>\n      الملف الشخصي   \n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <!-- <ion-grid class=\"ion-margin-bottom\">\n    <ion-row class=\"ion-justify-content-center\"> \n      <ion-col size=\"8\" class=\"ion-align-items-center\">\n        <ion-avatar> \n          <ion-icon name=\"person-circle-outline\" color=\"primary\" class=\"custIcon\"></ion-icon>\n        </ion-avatar>\n        <p>{{USER_INFO.fullName}}</p>\n      </ion-col>\n    </ion-row>\n  </ion-grid> -->\n  <ion-grid *ngIf=\"errorLoad == true\" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n</ion-grid>\n\n\n<ion-grid *ngIf=\"!USER_INFO && errorLoad == false\"  class=\"custGrid\"> \n  <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n    <ion-col size=\"12\" class=\"ion-text-center\">\n      <!-- *ngIf=\"spinner == true\" -->\n      <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n    </ion-col>\n    <ion-col size=\"12\">\n      <!-- *ngIf=\"spinner == true\" --> \n    </ion-col>\n  </ion-row> \n</ion-grid>\n\n<ion-grid *ngIf=\"USER_INFO\"> \n  <form [formGroup]=\"ionicForm\" (ngSubmit)=\"update()\" novalidate>\n  <ion-list class=\"w100\"  dir=\"rtl\"> \n    <ion-item class=\"ion-margin-top\" >\n     <ion-label>الجوال: </ion-label>  \n      <ion-input readonly=\"true\" formControlName=\"phone\" [(ngModel)]=\"USER_INFO.phone\"></ion-input> \n      <ion-button slot=\"end\" size=\"small\" (click)=\"changePhone()\">تغيير</ion-button>\n    </ion-item>\n    <ion-item>\n      <ion-label > الإسم:  </ion-label> \n      <ion-input  formControlName=\"fullName\" [(ngModel)]=\"USER_INFO.fullName\" ></ion-input> \n      <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.fullName.errors?.required\"> الحقل مطلوب</ion-note>\n      <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.fullName.errors?.pattern\"> حروف فقط </ion-note>\n\n    </ion-item> \n    <ion-item>\n      <ion-label>البريد الإلكتروني: </ion-label> \n      <ion-input formControlName=\"email\" [(ngModel)]=\"USER_INFO.email\" ></ion-input> \n      <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.email.errors?.required\"> الحقل مطلوب </ion-note> \n      <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.email.errors?.pattern\">    خطأ في صيغة البريد  </ion-note>\n    </ion-item>\n    <ion-item>\n      <ion-label>تاريخ الميلاد: </ion-label> \n      <ion-input  value=\"{{ USER_INFO.birthDate | date: 'dd MMM yyyy' }}\" id=\"date\" (click)=\"presentPopover($event)\"></ion-input>\n      <ion-popover #popover [isOpen]=\"isOpen\" trigger=\"date\">\n          <ng-template>\n              <ion-datetime max=\"2004-01-01T00:00:00\"  min=\"1960-12-30T23:59:59\" formControlName=\"birth\" presentation=\"date\" [(ngModel)]=\"USER_INFO.birthDate\" locale=\"en-US\" (ionChange)=\"dateChange($event)\"></ion-datetime>\n          </ng-template>\n      </ion-popover>\n    </ion-item>\n    <ion-radio-group formControlName=\"gender\"  [(ngModel)]=\"USER_INFO.gender\" (ionChange)=\"genderChange($event)\">\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"6\">\n              <ion-item>\n                <ion-label>ذكـر</ion-label>\n                <ion-radio slot=\"start\" value=0>  </ion-radio>\n              </ion-item> \n            </ion-col>\n            <ion-col size=\"6\">\n              <ion-item>\n                <ion-label>انثي</ion-label>\n                <ion-radio slot=\"start\" value=1></ion-radio> \n              </ion-item> \n            </ion-col>\n          </ion-row>\n        </ion-grid> \n    </ion-radio-group> \n  \n   \n    <!-- <ion-item>\n      <ion-label position=\"floating\">Password</ion-label> \n      <ion-input [(ngModel)]=\"USER_INFO.password\" type=\"password\"></ion-input>\n      <ion-icon  slot=\"end\"  name=\"eye-off-outline\" ></ion-icon>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"floating\">Confirm Password</ion-label> \n      <ion-input [(ngModel)]=\"confirmPass\" type=\"password\"></ion-input>\n      <ion-icon  slot=\"end\"   name=\"eye-off-outline\" ></ion-icon>\n    </ion-item> -->\n    \n  </ion-list>\n\n  <ion-row class=\"ion-margin\" dir=\"rtl\">\n    <ion-col size=\"12\">\n      <ion-item color=\"primary\" [disabled]=\"spinner == true\" button (click)=\"update()\">\n        <ion-label class=\"ion-text-center\">حفــظ </ion-label>\n        <ion-spinner name=\"lines\" color=\"light\" *ngIf=\"spinner == true\"></ion-spinner>  \n      </ion-item>\n    </ion-col>\n  </ion-row> \n  </form>\n  </ion-grid>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_profile_profile_module_ts.js.map