"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_home_home_module_ts"],{

/***/ 2003:
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 2267);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage,
        children: [
            {
                path: 'mazad-details',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_mzad-subescribe_mzad-subescribe_page_ts"), __webpack_require__.e("default-src_app_mzad-details_mzad-details_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../mzad-details/mzad-details.module */ 3702)).then(m => m.MzadDetailsPageModule)
            },
            {
                path: '',
                redirectTo: '/tabs/home',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: '/tabs/home',
        pathMatch: 'full'
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HomePageRoutingModule);



/***/ }),

/***/ 3467:
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home-routing.module */ 2003);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page */ 2267);







let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_0__.HomePageRoutingModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_1__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 2267:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page.html?ngResource */ 3853);
/* harmony import */ var _home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss?ngResource */ 1020);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 2378);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/socket-service.service */ 905);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ 6908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment-timezone */ 2469);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment_timezone__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ 190);











let HomePage = class HomePage {
  // (alias) timer(dueTime?: number | Date, periodOrScheduler?: number | SchedulerLike, scheduler?: SchedulerLike): Observable<number>
  // import timer
  // Creates an Observable that starts emitting after an dueTime and emits ever increasing numbers after each period of time thereafter.
  // Its like index /interval, but you can specify when should the emissions start.
  // timer returns an Observable that emits an infinite sequence of ascending integers, with a constant interval of time, period of your choosing between those emissions. The first emission happens after the specified dueTime. The initial delay may be a Date. By default, this operator uses the asyncScheduler SchedulerLike to provide a notion of time, but you may pass any SchedulerLike to it. If period is not specified, the output Observable emits only one value, 0. Otherwise, it emits an infinite sequence.
  // Examples
  // Emits ascending numbers, one every second (1000ms), starting after 3 seconds
  // import { timer } from 'rxjs';
  // const numbers = timer(3000, 1000);
  // numbers.subscribe(x => console.log(x));
  // Emits one number after five seconds
  // import { timer } from 'rxjs';
  // const numbers = timer(5000);
  // numbers.subscribe(x => console.log(x))
  constructor(storage, api, datePipe, rout, socket) {
    //  this.socket.getNewAuction()
    this.storage = storage;
    this.api = api;
    this.datePipe = datePipe;
    this.rout = rout;
    this.socket = socket;
    this.mobSlideOpt = {
      zoom: false,
      slidesPerView: 1.2,
      spaceBetween: 10,
      centeredSlides: true,
      speed: 400
    }; //style : any = 'style1'

    this.style = 'style2';
    this.errorLoad = false;
    this.timeLeftArr = [{
      da: String,
      hr: String,
      mn: String,
      sc: String
    }];
    this.auctionsArray = [];
    this.segment = 'upcoming';
    this.slideOpts = {
      slidesPerView: 3,
      nitialSlide: 0
    };
  }

  ngOnInit() {
    this.storage.get('user_info').then(response => {
      if (response) {
        this.USER_INFO = response.user;
        console.log('kkkkkkkkkk', this.USER_INFO);
        this.getAllAuction();
      }
    });
  }

  ionViewWillEnter() {}

  segmentChange(ev) {
    console.log('sg', ev);
  }

  getAllAuction() {
    this.api.getAllAuction().subscribe(data => {
      console.log(data);
      let res = data['auctions'];
      this.auctionsArray = res;
      console.log(this.auctionsArray);
      this.prepareAuc();
    }, err => {
      console.log(err);
      this.handleError(err.error.error);
    });
  }

  reload() {
    this.errorLoad = false;
    this.auctionsArray = undefined;
    this.getAllAuction();
  }

  handleError(err) {
    this.errorLoad = true; // if (err.error == "No user with this phone found") {
    //   console.log('no user was found') 
    // // this.getsms('new',err) // uncomment it after apply smsgetway 
    // // this.getVirfyCode('new' , err) // comment it after apply smsgetway 
    // }else if(err.error == "another phone"){
    //   // to apply imei check uncmment the line in zoodohapi/controller/user.j function : loginPhone
    //   this.presentToast('seem you use another phone','danger') 
    // } else{ 
    //   this.presentToast('حدث خطأ ما ,حاول مرة اخري','danger')
    //   console.log(err.kind)
    // }
  }

  prepareAuc() {
    //set count down for auctions
    for (let index = 0; index < this.auctionsArray.length; index++) {
      const element = this.auctionsArray[index];

      if (element.currentStatus == 1) {
        element.timeLeft = this.startAfterounter(index);
      } else if (element.currentStatus == 2) {
        //edit here
        element.timeLeft = this.endAfterounter(index);
      } else if (element.currentStatus == 3) {
        //edit here
        element.timeLeft = this.endSinceAfterounter(index);
      } // userIn


      let fltuse = [];
      fltuse = element.users.filter(x => x.userId == this.USER_INFO._id);
      console.log('fltuse' + index, fltuse);

      if (fltuse.length > 0 && element.currentStatus < 3 && fltuse[0].cancel == 0) {
        element.userIn = true;
      } else if (fltuse.length > 0 && fltuse[0].cancel == 1) {
        element.userOut = true;
      } else if (element.logs.length > 0 && fltuse.length > 0 && element.currentStatus == 3) {
        // userWin
        let mx = element.logs.reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0);
        let flt = element.logs.filter(x => x.pay == mx);
        console.log('userWin', mx, flt);

        if (flt[0].userId == this.USER_INFO._id) {
          element.userWin = true;
        }
      } //duration


      let du = moment__WEBPACK_IMPORTED_MODULE_3__.duration(moment__WEBPACK_IMPORTED_MODULE_3__(element.end).diff(moment__WEBPACK_IMPORTED_MODULE_3__(element.start)));
      let hr = "";
      let day = "";
      let con = "";

      if (du.days() > 0) {
        day = du.days().toString() + " يوم";
      }

      if (du.hours() > 0) {
        hr = du.hours().toString() + " ساعة";
      }

      if (du.hours() > 0 && du.hours() > 0) {
        con = " , ";
      }

      element.duration = day + con + hr;
    }

    console.log(this.auctionsArray);
  }

  endAfterounter(index) {
    let offset = moment_timezone__WEBPACK_IMPORTED_MODULE_4__().utcOffset();
    let newDate = moment__WEBPACK_IMPORTED_MODULE_3__(this.auctionsArray[index]['end']).add();
    console.log('init', this.auctionsArray[index]['end'], 'sdfs', offset, 'newDate', moment__WEBPACK_IMPORTED_MODULE_3__(newDate).format('YYYY-MM-DDTHH:mm:ss.SSSSZ'));
    return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable(observer => {
      setInterval(() => observer.next({
        da: this.memntoEnd(newDate).asDays().toFixed(0).toString(),
        hr: this.memntoEnd(newDate).hours().toString(),
        mn: this.memntoEnd(newDate).minutes().toString(),
        sc: this.memntoEnd(newDate).seconds().toString()
      }), 1000);
    });
  }

  memntoEnd(newDate) {
    return moment__WEBPACK_IMPORTED_MODULE_3__.duration(moment__WEBPACK_IMPORTED_MODULE_3__(newDate).diff(moment__WEBPACK_IMPORTED_MODULE_3__()));
  }

  startAfterounter(index) {
    let offset = moment_timezone__WEBPACK_IMPORTED_MODULE_4__().utcOffset();
    let newDate = moment__WEBPACK_IMPORTED_MODULE_3__(this.auctionsArray[index]['start']).add();
    console.log(moment__WEBPACK_IMPORTED_MODULE_3__(), 'init', this.auctionsArray[index]['start'], 'sdfs', offset, 'newDate', moment__WEBPACK_IMPORTED_MODULE_3__(newDate).format('YYYY-MM-DDTHH:mm:ss.SSSSZ'));
    return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable(observer => {
      setInterval(() => observer.next({
        da: this.memntoStart(newDate).asDays().toFixed(0).toString(),
        hr: this.memntoStart(newDate).hours().toString(),
        mn: this.memntoStart(newDate).minutes().toString(),
        sc: this.memntoStart(newDate).seconds().toString()
      }), 1000);
    });
  }

  memntoStart(newDate) {
    let today = new Date();
    return moment__WEBPACK_IMPORTED_MODULE_3__.duration(moment__WEBPACK_IMPORTED_MODULE_3__(newDate).diff(moment__WEBPACK_IMPORTED_MODULE_3__(today)));
  }

  endSinceAfterounter(index) {
    let offset = moment_timezone__WEBPACK_IMPORTED_MODULE_4__().utcOffset();
    let newDate = moment__WEBPACK_IMPORTED_MODULE_3__(this.auctionsArray[index]['end']).add();
    console.log(moment__WEBPACK_IMPORTED_MODULE_3__(), 'init', this.auctionsArray[index]['end'], 'sdfs', offset, 'newDate', moment__WEBPACK_IMPORTED_MODULE_3__(newDate).format('YYYY-MM-DDTHH:mm:ss.SSSSZ'));
    return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable(observer => {
      setInterval(() => observer.next({
        da: this.memnSinceEnd(newDate).asDays().toFixed(0).toString(),
        hr: this.memnSinceEnd(newDate).hours().toString(),
        mn: this.memnSinceEnd(newDate).minutes().toString(),
        sc: this.memnSinceEnd(newDate).seconds().toString()
      }), 1000);
    });
  }

  memnSinceEnd(newDate) {
    return moment__WEBPACK_IMPORTED_MODULE_3__.duration(moment__WEBPACK_IMPORTED_MODULE_3__().diff(moment__WEBPACK_IMPORTED_MODULE_3__(newDate)));
  }

  mazdDetails(auct) {
    let navigationExtras = {
      queryParams: {
        id: JSON.stringify(auct._id),
        user_info: JSON.stringify(this.USER_INFO)
      }
    };

    if (auct.userIn == true && auct.currentStatus == 2) {
      this.rout.navigate(['live-mzad'], navigationExtras);
    } else if (auct.userWin == true) {
      // redirect to tabs/cart and pass _id to present details modal 
      this.rout.navigate(['order-details'], navigationExtras);
    } else if (auct.userOut == true && auct.currentStatus == 1) {
      this.rout.navigate(['mazad-details'], navigationExtras);
    } else {
      this.rout.navigate(['mazad-details'], navigationExtras);
    }
  }

};

HomePage.ctorParameters = () => [{
  type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__.Storage
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_2__.SocketServiceService
}, {
  type: _angular_common__WEBPACK_IMPORTED_MODULE_7__.DatePipe
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_2__.SocketServiceService
}];

HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-home',
  template: _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
  styles: [_home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
})], HomePage);


/***/ }),

/***/ 1020:
/*!************************************************!*\
  !*** ./src/app/home/home.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --background-color: transparent;\n  --ion-color-base: transparent !important;\n}\n\n.header-md::after {\n  background-image: none;\n}\n\n.background-image {\n  background-size: cover;\n  height: 100%;\n  width: 100%;\n}\n\n.product-card {\n  border-radius: 29px;\n  width: 110%;\n  padding-top: 15px;\n  padding-bottom: 15px;\n  padding-right: 5px;\n  padding-left: 5px;\n  background: linear-gradient(180deg, rgba(255, 255, 255, 0.16), rgba(255, 255, 255, 0.85));\n  position: relative;\n}\n\n.product-img {\n  width: 100%;\n  height: 200px;\n}\n\n.product-details {\n  display: flex;\n  flex-direction: column;\n}\n\n.product-details div {\n  font-weight: bold;\n}\n\n.product-details .price {\n  margin-top: 10px;\n}\n\n.product-details .rounded-button {\n  margin-top: auto;\n  margin-left: auto;\n  margin-right: auto;\n  display: block;\n}\n\n.radus5 {\n  border-radius: 4%;\n}\n\n.borderlight {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-light-shade);\n}\n\n.badge {\n  padding-top: 4px;\n  padding-bottom: 5px;\n  padding-right: 13px;\n  padding-left: 14px;\n}\n\n.mgt10 {\n  margin-top: 10px;\n}\n\n.f18 {\n  font-size: 18px;\n  font-weight: bold;\n}\n\n.f20 {\n  font-size: 20px;\n  font-weight: bold;\n}\n\n.segCont {\n  height: 80px;\n}\n\nion-segment {\n  --background: var(--ion-color-dark);\n  height: 60%;\n}\n\nion-segment ion-segment-button {\n  color: var(--ion-color-light) !important;\n}\n\nion-segment .segment-button-checked {\n  color: var(--ion-color-light-shade) !important;\n  font-size: x-large;\n  font-weight: bolder;\n}\n\n.bgContent {\n  --background: #cdd8e1 ;\n}\n\n.topSeg {\n  top: -16px;\n  --indicator-height: 0px;\n}\n\n.f16 {\n  font-size: 16px;\n  font-weight: bold;\n}\n\n.padding5 {\n  padding-top: 5px;\n}\n\n--ion-padding {\n  padding-left: unset;\n  padding-right: unset;\n  padding-inline-start: var(--ion-padding, 9px);\n  padding-inline-end: var(--ion-padding, 9px);\n}\n\n.timercol {\n  background-color: var(--ion-color-light-tint);\n  border-bottom-left-radius: 9px;\n  border-bottom-right-radius: 9px;\n}\n\n.htext {\n  text-align: center;\n  margin-top: 3px;\n  margin-bottom: 1px;\n}\n\n.hnom {\n  text-align: center;\n  margin-top: 1px;\n}\n\n.img {\n  height: 135px;\n  width: 153px;\n}\n\n.Status {\n  position: absolute;\n  float: right;\n  right: 3px;\n  top: 3px;\n}\n\n.Status2 {\n  /* position: absolute; */\n  float: left;\n  right: 10px;\n  top: 10px;\n  margin-left: 5px;\n  margin-top: 5px;\n  border-style: solid;\n  border-radius: 30px;\n  background-color: var(--ion-color-dark);\n}\n\n.pos {\n  position: relative;\n}\n\n.trnsItem {\n  --ion-item-background: transparent;\n}\n\n.container {\n  position: relative;\n  width: 100px;\n  height: 100px;\n}\n\n.number {\n  position: absolute;\n  top: 0;\n  right: 0;\n  background-color: #000;\n  color: #fff;\n  padding: 5px;\n}\n\n.text {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFxodXNhbSUyMHByb2pcXHpvb2RvaGFTZFxcc3JjXFxhcHBcXGhvbWVcXGhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0UsK0JBQUE7RUFDQSx3Q0FBQTtBQ0FGOztBRE1JO0VBQ0Usc0JBQUE7QUNITjs7QURNTTtFQUVJLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUNKVjs7QURPTTtFQUNFLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EseUZBQUE7RUFDQSxrQkFBQTtBQ0pSOztBRE9NO0VBQ0UsV0FBQTtFQUNBLGFBQUE7QUNKUjs7QURPTTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtBQ0pSOztBRE9NO0VBQ0UsaUJBQUE7QUNKUjs7QURPTTtFQUNFLGdCQUFBO0FDSlI7O0FET0U7RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FDSko7O0FET0E7RUFDSSxpQkFBQTtBQ0pKOztBRE9BO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDBDQUFBO0FDSko7O0FET0E7RUFDSSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQ0pKOztBRE9BO0VBQ0ksZ0JBQUE7QUNKSjs7QURPQTtFQUNFLGVBQUE7RUFDRSxpQkFBQTtBQ0pKOztBRE9BO0VBQ0UsZUFBQTtFQUNFLGlCQUFBO0FDSko7O0FET0E7RUFDQSxZQUFBO0FDSkE7O0FEYUE7RUFDRSxtQ0FBQTtFQUNFLFdBQUE7QUNWSjs7QURXSTtFQUNFLHdDQUFBO0FDVE47O0FEWUk7RUFDRSw4Q0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUNWTjs7QURnQkE7RUFDRSxzQkFBQTtBQ2JGOztBRGlCQTtFQUNDLFVBQUE7RUFDQSx1QkFBQTtBQ2REOztBRGtCQTtFQUNFLGVBQUE7RUFDRSxpQkFBQTtBQ2ZKOztBRGtCQTtFQUNBLGdCQUFBO0FDZkE7O0FEaUJBO0VBQ0ksbUJBQUE7RUFDQSxvQkFBQTtFQUNBLDZDQUFBO0VBQ0EsMkNBQUE7QUNkSjs7QURpQkE7RUFDSSw2Q0FBQTtFQUNBLDhCQUFBO0VBQ0EsK0JBQUE7QUNkSjs7QURnQkE7RUFDSSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ2JKOztBRGVBO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0FDWko7O0FEZUE7RUFDSSxhQUFBO0VBQ0EsWUFBQTtBQ1pKOztBRGNDO0VBQ0csa0JBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFFBQUE7QUNYSjs7QURhRztFQUNHLHdCQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLHVDQUFBO0FDVk47O0FEWUc7RUFDQyxrQkFBQTtBQ1RKOztBRFlDO0VBQ0Msa0NBQUE7QUNURjs7QURZRztFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNUSjs7QURZRTtFQUNFLGtCQUFBO0VBQ0EsTUFBQTtFQUNBLFFBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDVEo7O0FEWUU7RUFDRSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxPQUFBO0FDVEoiLCJmaWxlIjoiaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIgXHJcbmlvbi10b29sYmFyIHtcclxuICAtLWJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gIC0taW9uLWNvbG9yLWJhc2U6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbn1cclxuICAgIC8vIGlvbi1oZWFkZXJ7XHJcbiAgICAvLyAgIC5oZWFkZXI6OmFmdGVyIHtcclxuICAgIC8vICAgfSAgXHJcbiAgICAvLyB9XHJcbiAgICAuaGVhZGVyLW1kOjphZnRlciB7IFxyXG4gICAgICBiYWNrZ3JvdW5kLWltYWdlOiBub25lO1xyXG5cclxuICAgIH1cclxuICAgICAgLmJhY2tncm91bmQtaW1hZ2Uge1xyXG4gICAgICAgICAgLy8gYmFja2dyb3VuZC1pbWFnZTogdXJsKCdwYXRoL3RvL2ltYWdlJyk7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgfVxyXG4gIFxyXG4gICAgICAucHJvZHVjdC1jYXJkIHtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAyOXB4O1xyXG4gICAgICAgIHdpZHRoOiAxMTAlO1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAxNXB4O1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAxNXB4O1xyXG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDVweDtcclxuICAgICAgICBwYWRkaW5nLWxlZnQ6IDVweDtcclxuICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoMTgwZGVnLCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMTYpLCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuODUpKTtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5wcm9kdWN0LWltZyB7XHJcbiAgICAgICAgd2lkdGg6MTAwJTsgXHJcbiAgICAgICAgaGVpZ2h0OjIwMHB4XHJcbiAgICAgIH1cclxuICBcclxuICAgICAgLnByb2R1Y3QtZGV0YWlscyB7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICB9XHJcbiAgXHJcbiAgICAgIC5wcm9kdWN0LWRldGFpbHMgZGl2IHtcclxuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgfVxyXG4gIFxyXG4gICAgICAucHJvZHVjdC1kZXRhaWxzIC5wcmljZSB7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgfVxyXG4gIFxyXG4gIC5wcm9kdWN0LWRldGFpbHMgLnJvdW5kZWQtYnV0dG9uIHtcclxuICAgIG1hcmdpbi10b3A6IGF1dG87XHJcbiAgICBtYXJnaW4tbGVmdDogYXV0bztcclxuICAgIG1hcmdpbi1yaWdodDogYXV0bztcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gIH1cclxuXHJcbi5yYWR1czV7XHJcbiAgICBib3JkZXItcmFkaXVzOiA0JTtcclxufVxyXG5cclxuLmJvcmRlcmxpZ2h0e1xyXG4gICAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci13aWR0aDogLjVweDtcclxuICAgIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlKTtcclxufVxyXG5cclxuLmJhZGdle1xyXG4gICAgcGFkZGluZy10b3A6IDRweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiA1cHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxM3B4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxNHB4O1xyXG59XHJcblxyXG4ubWd0MTB7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG4uZjE4e1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcblxyXG4uZjIwe1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcblxyXG4uc2VnQ29udHtcclxuaGVpZ2h0OiA4MHB4O1xyXG5cclxufVxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5pb24tc2VnbWVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgICBoZWlnaHQ6IDYwJTsgIFxyXG4gICAgaW9uLXNlZ21lbnQtYnV0dG9uIHtcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCkhaW1wb3J0YW50IDsgIFxyXG4gICAgfVxyXG5cclxuICAgIC5zZWdtZW50LWJ1dHRvbi1jaGVja2VkIHtcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSkgIWltcG9ydGFudCA7XHJcbiAgICAgIGZvbnQtc2l6ZTogeC1sYXJnZTtcclxuICAgICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxuICAgICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiAjMDIzYjIxZGUgIWltcG9ydGFudDsgXHJcbiAgICBcclxuICAgIH1cclxufVxyXG5cclxuLmJnQ29udGVudHtcclxuICAtLWJhY2tncm91bmQ6ICNjZGQ4ZTEgO1xyXG59XHJcblxyXG5cclxuLnRvcFNlZ3tcclxuIHRvcDotMTZweCA7XHJcbiAtLWluZGljYXRvci1oZWlnaHQ6IDBweDtcclxufVxyXG5cclxuXHJcbi5mMTZ7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcbi5wYWRkaW5nNXtcclxucGFkZGluZy10b3A6IDVweDtcclxufVxyXG4tLWlvbi1wYWRkaW5ne1xyXG4gICAgcGFkZGluZy1sZWZ0OiB1bnNldDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IHVuc2V0O1xyXG4gICAgcGFkZGluZy1pbmxpbmUtc3RhcnQ6IHZhcigtLWlvbi1wYWRkaW5nLCA5cHgpO1xyXG4gICAgcGFkZGluZy1pbmxpbmUtZW5kOiB2YXIoLS1pb24tcGFkZGluZywgOXB4KTtcclxufVxyXG5cclxuLnRpbWVyY29se1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXRpbnQpO1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogOXB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDlweDtcclxufVxyXG4uaHRleHR7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tdG9wOiAzcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxcHg7XHJcbn1cclxuLmhub217XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tdG9wOiAxcHg7XHJcbn1cclxuXHJcbi5pbWd7XHJcbiAgICBoZWlnaHQ6IDEzNXB4O1xyXG4gICAgd2lkdGg6IDE1M3B4O1xyXG59XHJcbiAuU3RhdHVze1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgcmlnaHQ6IDNweDtcclxuICAgIHRvcDogM3B4O1xyXG4gICB9XHJcbiAgIC5TdGF0dXMye1xyXG4gICAgICAvKiBwb3NpdGlvbjogYWJzb2x1dGU7ICovXHJcbiAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICByaWdodDogMTBweDtcclxuICAgICAgdG9wOiAxMHB4O1xyXG4gICAgICBtYXJnaW4tbGVmdDogNXB4O1xyXG4gICAgICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAgfSBcclxuICAgLnBvc3tcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgfVxyXG5cclxuIC50cm5zSXRlbXtcclxuICAtLWlvbi1pdGVtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gfVxyXG4gICAvL1xyXG4gICAuY29udGFpbmVyIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHdpZHRoOiAxMDBweDtcclxuICAgIGhlaWdodDogMTAwcHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5udW1iZXIge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwO1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC50ZXh0IHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgfVxyXG4gXHJcblxyXG4iLCJpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIC0taW9uLWNvbG9yLWJhc2U6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG59XG5cbi5oZWFkZXItbWQ6OmFmdGVyIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn1cblxuLmJhY2tncm91bmQtaW1hZ2Uge1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4ucHJvZHVjdC1jYXJkIHtcbiAgYm9yZGVyLXJhZGl1czogMjlweDtcbiAgd2lkdGg6IDExMCU7XG4gIHBhZGRpbmctdG9wOiAxNXB4O1xuICBwYWRkaW5nLWJvdHRvbTogMTVweDtcbiAgcGFkZGluZy1yaWdodDogNXB4O1xuICBwYWRkaW5nLWxlZnQ6IDVweDtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDE4MGRlZywgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjE2KSwgcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjg1KSk7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLnByb2R1Y3QtaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMjAwcHg7XG59XG5cbi5wcm9kdWN0LWRldGFpbHMge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xufVxuXG4ucHJvZHVjdC1kZXRhaWxzIGRpdiB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4ucHJvZHVjdC1kZXRhaWxzIC5wcmljZSB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5wcm9kdWN0LWRldGFpbHMgLnJvdW5kZWQtYnV0dG9uIHtcbiAgbWFyZ2luLXRvcDogYXV0bztcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XG4gIG1hcmdpbi1yaWdodDogYXV0bztcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5yYWR1czUge1xuICBib3JkZXItcmFkaXVzOiA0JTtcbn1cblxuLmJvcmRlcmxpZ2h0IHtcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXdpZHRoOiAwLjVweDtcbiAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpO1xufVxuXG4uYmFkZ2Uge1xuICBwYWRkaW5nLXRvcDogNHB4O1xuICBwYWRkaW5nLWJvdHRvbTogNXB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxM3B4O1xuICBwYWRkaW5nLWxlZnQ6IDE0cHg7XG59XG5cbi5tZ3QxMCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5mMTgge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4uZjIwIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLnNlZ0NvbnQge1xuICBoZWlnaHQ6IDgwcHg7XG59XG5cbmlvbi1zZWdtZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG4gIGhlaWdodDogNjAlO1xufVxuaW9uLXNlZ21lbnQgaW9uLXNlZ21lbnQtYnV0dG9uIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCkgIWltcG9ydGFudDtcbn1cbmlvbi1zZWdtZW50IC5zZWdtZW50LWJ1dHRvbi1jaGVja2VkIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSkgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiB4LWxhcmdlO1xuICBmb250LXdlaWdodDogYm9sZGVyO1xufVxuXG4uYmdDb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjY2RkOGUxIDtcbn1cblxuLnRvcFNlZyB7XG4gIHRvcDogLTE2cHg7XG4gIC0taW5kaWNhdG9yLWhlaWdodDogMHB4O1xufVxuXG4uZjE2IHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLnBhZGRpbmc1IHtcbiAgcGFkZGluZy10b3A6IDVweDtcbn1cblxuLS1pb24tcGFkZGluZyB7XG4gIHBhZGRpbmctbGVmdDogdW5zZXQ7XG4gIHBhZGRpbmctcmlnaHQ6IHVuc2V0O1xuICBwYWRkaW5nLWlubGluZS1zdGFydDogdmFyKC0taW9uLXBhZGRpbmcsIDlweCk7XG4gIHBhZGRpbmctaW5saW5lLWVuZDogdmFyKC0taW9uLXBhZGRpbmcsIDlweCk7XG59XG5cbi50aW1lcmNvbCB7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC10aW50KTtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogOXB4O1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogOXB4O1xufVxuXG4uaHRleHQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDNweDtcbiAgbWFyZ2luLWJvdHRvbTogMXB4O1xufVxuXG4uaG5vbSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogMXB4O1xufVxuXG4uaW1nIHtcbiAgaGVpZ2h0OiAxMzVweDtcbiAgd2lkdGg6IDE1M3B4O1xufVxuXG4uU3RhdHVzIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBmbG9hdDogcmlnaHQ7XG4gIHJpZ2h0OiAzcHg7XG4gIHRvcDogM3B4O1xufVxuXG4uU3RhdHVzMiB7XG4gIC8qIHBvc2l0aW9uOiBhYnNvbHV0ZTsgKi9cbiAgZmxvYXQ6IGxlZnQ7XG4gIHJpZ2h0OiAxMHB4O1xuICB0b3A6IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG4gIG1hcmdpbi10b3A6IDVweDtcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXJhZGl1czogMzBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xufVxuXG4ucG9zIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4udHJuc0l0ZW0ge1xuICAtLWlvbi1pdGVtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuXG4uY29udGFpbmVyIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB3aWR0aDogMTAwcHg7XG4gIGhlaWdodDogMTAwcHg7XG59XG5cbi5udW1iZXIge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgcmlnaHQ6IDA7XG4gIGJhY2tncm91bmQtY29sb3I6ICMwMDA7XG4gIGNvbG9yOiAjZmZmO1xuICBwYWRkaW5nOiA1cHg7XG59XG5cbi50ZXh0IHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDA7XG4gIGxlZnQ6IDA7XG59Il19 */";

/***/ }),

/***/ 3853:
/*!************************************************!*\
  !*** ./src/app/home/home.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar dir=\"rtl\">\n    <ion-title>\n      <ion-icon name=\"home-outline\"></ion-icon>\n      الرئيسية\n    </ion-title>\n    <ion-buttons slot=\"end\" *ngIf= \"USER_INFO\"> \n        <ion-avatar>\n          <ion-img *ngIf= \"USER_INFO.imgUrl.lenght > 0\" [src]= \"USER_INFO.imgUrl\"></ion-img> \n          <ion-icon *ngIf= \"USER_INFO.imgUrl.lenght == 0\" name=\"home-outline\"></ion-icon> \n        </ion-avatar> \n    </ion-buttons>\n    \n    \n  </ion-toolbar>\n</ion-header>\n\n<ion-content  *ngIf= \"style == 'style1'\">\n  <ion-grid> \n    <ion-row class=\"ion-margin-top ion-justify-content-center\">\n      <!-- <ion-col size=\"10\" class=\"ion-text-center\">\n        <ion-chip>\n          <ion-icon color= \"dark\" name=\"chevron-down\"></ion-icon> \n          <ion-label>الحالة</ion-label>\n        </ion-chip>  \n        <ion-chip>\n          <ion-icon  color= \"dark\" name=\"chevron-down\"></ion-icon> \n          <ion-label>التصنيف</ion-label>\n        </ion-chip>\n        <ion-chip>\n          <ion-icon  color= \"dark\" name=\"chevron-down\"></ion-icon> \n          <ion-label>الدولة</ion-label>\n        </ion-chip>\n      </ion-col> -->\n       \n       \n      <!-- <ion-slides  [options]=\"slideOpts\">\n        <ion-slide (click)=\"options()\">\n          <ion-select value=\"brown\" okText=\"موافق\" cancelText=\"إلغاء\" [multiple]=\"true\">\n            <ion-select-option>\n              بدون\n            </ion-select-option>\n            <ion-select-option>\n              إلكترويات\n            </ion-select-option>\n            <ion-select-option>\n              عقارات\n            </ion-select-option>\n            <ion-select-option>\n              رحلات سياحة\n            </ion-select-option>\n            <ion-select-option>\n              أخري\n            </ion-select-option>\n          </ion-select>\n\n         \n         \n        </ion-slide>\n        <ion-slide>\n          <ion-select value=\"dark\" okText=\"موافق\" cancelText=\"إلغاء\">\n            <ion-select-option>\n              مزاد قادم\n            </ion-select-option>\n            <ion-select-option>\n              مزاد جاري\n            </ion-select-option>\n            <ion-select-option>\n              مزاد منتهي\n            </ion-select-option> \n          </ion-select>\n         \n        </ion-slide>\n       <ion-slide>\n          <ion-select value=\"yall\" okText=\"موافق\" cancelText=\"إلغاء\" [multiple]=\"true\">\n            <ion-select-option>\n              بدون\n            </ion-select-option>\n            <ion-select-option>\n              إلكترويات\n            </ion-select-option>\n            <ion-select-option>\n              عقارات\n            </ion-select-option>\n            <ion-select-option>\n              رحلات سياحة\n            </ion-select-option>\n            <ion-select-option>\n              أخري\n            </ion-select-option>\n          </ion-select>\n          \n        </ion-slide>  \n      </ion-slides> -->\n     \n    </ion-row>\n</ion-grid>\n<!-- \n  <ion-icon name=\"chevron-down-outline\"></ion-icon>\n  filter grid -->\n<ion-grid *ngIf=\"errorLoad == true\" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n</ion-grid>\n\n<ion-grid *ngIf=\"!auctionsArray && errorLoad == false\"  class=\"custGrid\"> \n  <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n    <ion-col size=\"12\" class=\"ion-text-center\">\n      <!-- *ngIf=\"spinner == true\" -->\n      <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n    </ion-col>\n    <ion-col size=\"12\">\n      <!-- *ngIf=\"spinner == true\" --> \n    </ion-col>\n  </ion-row> \n</ion-grid>\n\n<ion-grid> \n  <ion-row class=\"ion-padding\">\n    <ion-col *ngFor=\"let auct of auctionsArray ; let i = index\" size=\"12\" class=\"radus5 borderlight w100 mgt10\">\n      <ion-grid class=\"ion-no-padding\" dir=\"rtl\"> \n       <ion-row>\n          <ion-item class=\"w100\" lines=\"none\"> \n            <ion-badge *ngIf=\"auct.currentStatus == 1\" color=\"warning\" slot=\"end\" class=\"badge\">\n            <ion-text> مزاد قادم</ion-text> \n              <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n            </ion-badge>\n            <ion-badge *ngIf=\"auct.currentStatus == 3\" color=\"light\" slot=\"end\" class=\"badge\">\n              <ion-text> مزاد منتهي </ion-text> \n                <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n              </ion-badge>\n              <ion-badge *ngIf=\"auct.currentStatus == 2\" color=\"success\" slot=\"end\" class=\"badge\">\n                <ion-text> مزاد جاري</ion-text> \n                  <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n              </ion-badge>\n            <ion-label>{{auct.title}}</ion-label>\n          </ion-item>\n        </ion-row> \n      \n        <ion-row>\n          <ion-col size=\"6\" class=\"pos\">\n                 <div class=\"Status\" *ngIf=\"auct.userIn\" >\n                  <ion-badge color=\"light\">\n                    <ion-icon color=\"success\" name=\"ribbon-outline\"></ion-icon>\n                    <ion-text> مشارك   </ion-text>\n                  </ion-badge> \n                 </div>\n                 <div class=\"Status\"  *ngIf=\"auct.userWin\">\n                  <ion-badge color=\"light\">\n                    <ion-icon name=\"ribbon-outline\" color=\"warning\"></ion-icon>\n                    <ion-text> فائز   </ion-text>\n                  </ion-badge> \n                 </div>\n                 <div class=\"Status\" *ngIf=\"auct.userOut\">\n                  <ion-badge color=\"light\">\n                    <ion-icon name=\"ribbon-outline\" color=\"danger\"></ion-icon>\n                    <ion-text> ملغي   </ion-text>\n                  </ion-badge> \n                 </div>\n                <img class=\"radus5 img\" [src]=\"auct.imgs[0]\"/>  \n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-grid   dir =\"rtl\" class=\"ion-no-padding\"> \n              <ion-row  class=\"ion-margin\" class=\"mgt10 ion-justify-content-center\">\n                <ion-label> \n                  <ion-text color=\"primary\"><b> يبدأ من :</b></ion-text>\n                  <ion-text> {{auct.productPrice - (0.3 * auct.productPrice)}} </ion-text> \n                </ion-label> \n              </ion-row> \n              <ion-row  class=\"ion-margin\" class=\"mgt10 ion-justify-content-center\">\n                <ion-label> \n                  <ion-text color=\"primary\"><b>العربون :</b></ion-text>\n                  <ion-text> {{auct.deposit}} </ion-text> \n                </ion-label> \n              </ion-row> \n              <ion-row class=\"mgt10 ion-justify-content-center\">\n                <ion-label> \n                  <!-- <ion-text color=\"primary\"><b> التاريخ : </b></ion-text>  -->\n                  <ion-text> {{auct.start | date:'EEE dd-MM-yyyy' : undefined  : 'ar'}} </ion-text>\n                  <!-- <ion-text> {{auct.start | date:'EEE dd-MM'}} </ion-text> -->\n                </ion-label>\n                <ion-label class=\"ion-text-center padding5\" dir=\"rtl\">\n                  <ion-text color=\"medium\" >{{auct.start | date:'hh:mm a': undefined  : 'ar'}}</ion-text>\n                 </ion-label>\n              </ion-row>\n              <ion-row   class=\"mgt10 ion-justify-content-center\">\n                <ion-label> \n                  <ion-text color=\"primary\"><b>المدة :</b>  </ion-text>\n                  <ion-text>  {{auct.duration}} </ion-text>\n                </ion-label> \n              </ion-row>\n            </ion-grid> \n          </ion-col>\n        </ion-row>\n\n        <ion-row *ngIf=\"auctionsArray[i].timeLeft | async as tm\">\n          <ion-col size=\"6\" class=\"timercol\">\n            <h6 class=\"htext\">\n              <ion-text>يوم : </ion-text>\n              <ion-text>ساعة : </ion-text>\n              <ion-text>دقيقة : </ion-text>\n              <ion-text>ثانية </ion-text>\n            </h6>\n            <h6 class=\"hnom\">\n              <ion-text color=\"primary\">\n                <b *ngIf=\"auct.currentStatus < 3 \">{{tm['da']}} :</b> \n                <b *ngIf=\"auct.currentStatus == 3\">00 :</b> \n              </ion-text>\n              <ion-text color=\"primary\">\n                <b *ngIf=\"auct.currentStatus < 3 \">{{tm['hr']}} :</b> \n                <b *ngIf=\"auct.currentStatus == 3 \">00 :</b> \n              </ion-text>\n              <ion-text color=\"primary\">\n                <b *ngIf=\"auct.currentStatus < 3 \">{{tm['mn']}} :</b> \n                <b *ngIf=\"auct.currentStatus == 3 \">00 :</b> \n              </ion-text>\n              <ion-text color=\"primary\">\n                <b *ngIf=\"auct.currentStatus < 3 \">{{tm['sc']}}</b>\n                <b *ngIf=\"auct.currentStatus == 3 \">00</b>\n               </ion-text>\n            </h6>\n          </ion-col>\n\n        </ion-row>\n\n        <ion-row  class=\"ion-margin-top\" dir=\"rtl\">\n          <ion-col size=\"4\">\n            <ion-item class=\"w100\" lines=\"none\">\n            <!-- <ion-button  fill=\"clear\" size=\"small\">\n              <b><ion-icon name=\"share-social\" color=\"primary\" style=\"font-size: 22px;\"></ion-icon></b>\n            </ion-button> -->\n          </ion-item>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-button expand=\"block\" (click)=\"mazdDetails(auct)\">\n               <h5><b>التفاصيل</b></h5>\n            </ion-button>\n          </ion-col>\n        </ion-row> \n      </ion-grid>\n    </ion-col> \n  </ion-row>\n</ion-grid>\n\n</ion-content>\n\n<!-- style 2  -->\n<!-- <ion-header>\n  <ion-toolbar dir=\"rtl\">\n    <ion-title>\n      <ion-icon name=\"home-outline\"></ion-icon>\n      الرئيسية\n    </ion-title>\n  </ion-toolbar>\n</ion-header> -->\n\n<ion-content *ngIf= \"style == 'style2'\" class=\"\"> \n  <ion-grid class=\"ion-no-padding ion-margin-top\">\n    <ion-row class=\"segCont\">\n      <ion-segment   value=\"upcoming\" (ionChange)=\"segmentChange($event)\" dir=\"rtl\">\n        <ion-segment-button class=\"topSeg\" value=\"upcoming\">\n          <ion-label class=\"f20\" >قادم</ion-label>\n        </ion-segment-button>\n        <ion-segment-button class=\"topSeg\" value=\"live\">\n          <ion-label  class=\"f20\" >جاري</ion-label>\n        </ion-segment-button> \n        <ion-segment-button class=\"topSeg\" value=\"ended\">\n          <ion-label  class=\"f20\" > منتهي </ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </ion-row>\n  </ion-grid>\n \n\n\n\n  <ion-grid *ngIf=\"errorLoad == true\" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n</ion-grid>\n\n<ion-grid *ngIf=\"!auctionsArray && errorLoad == false\"  class=\"custGrid\"> \n  <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n    <ion-col size=\"12\" class=\"ion-text-center\">\n      <!-- *ngIf=\"spinner == true\" -->\n      <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n    </ion-col>\n    <ion-col size=\"12\">\n      <!-- *ngIf=\"spinner == true\" --> \n    </ion-col>\n  </ion-row> \n</ion-grid>\n\n  <!-- <div class=\"background-image\"></div> -->\n  <ion-slides  [options]=\"mobSlideOpt\">\n    \n      <ion-slide *ngFor=\"let auct of auctionsArray ; let i = index\">\n        <ion-card class=\"product-card\"  (click)=\"mazdDetails(auct)\"> \n          <ion-grid class=\"ion-no-padding\">\n            <ion-row>\n              <ion-col size=\"12\">\n                <div class=\"Status2\" *ngIf=\"auct.userIn\" > \n                  <ion-chip color=\"light\">\n                   <ion-icon color=\"success\" name=\"ribbon-outline\"></ion-icon>\n                   <ion-label>مشارك</ion-label>\n                 </ion-chip>\n                 </div>\n                 <div class=\"Status2\"  *ngIf=\"auct.userWin\">\n                  <ion-chip  color=\"light\">\n                    <ion-icon name=\"ribbon-outline\" color=\"warning\"></ion-icon>\n                    <ion-label> فائز   </ion-label>\n                  </ion-chip > \n                 </div>\n                 <div class=\"Status2\" *ngIf=\"auct.userOut\">\n                  <ion-chip  color=\"light\">\n                    <ion-icon name=\"ribbon-outline\" color=\"danger\"></ion-icon>\n                    <ion-label> ملغي   </ion-label>\n                  </ion-chip > \n                 </div>\n              </ion-col>\n\n              <ion-col size=\"12\" class=\"pos\"> \n                <img class=\"product-img\" [src]=\"auct.imgs[0]\"/>  \n               </ion-col>\n            </ion-row>\n          </ion-grid>\n          \n    \n\n          <!-- <img class=\"product-img\" [src]=\"auct.imgs[0]\" /> -->\n          <ion-card-header class=\"ion-no-margin ion-no-padding\" dir=\"rtl\"> \n              <ion-item class=\"w100 trnsItem\" lines=\"none\"> \n                <!-- <ion-badge *ngIf=\"auct.currentStatus == 1\" color=\"warning\" slot=\"end\" class=\"badge\">\n                <ion-text> مزاد قادم</ion-text> \n                  <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n                </ion-badge>\n                <ion-badge *ngIf=\"auct.currentStatus == 3\" color=\"light\" slot=\"end\" class=\"badge\">\n                  <ion-text> مزاد منتهي </ion-text> \n                    <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n                  </ion-badge>\n                  <ion-badge *ngIf=\"auct.currentStatus == 2\" color=\"success\" slot=\"end\" class=\"badge\">\n                    <ion-text> مزاد جاري</ion-text> \n                      <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n                  </ion-badge> -->\n                <ion-label class=\"f18\">{{auct.title}}</ion-label>\n              </ion-item> \n          </ion-card-header>\n\n          <ion-card-content class=\"product-details ion-no-padding\">\n            <ion-grid   dir =\"rtl\" class=\"ion-no-margin\"> \n              <ion-row   class=\"ion-text-start\">\n                <ion-col size=\"6\">\n                  <ion-label class=\"f16\"> \n                    <ion-text color=\"dark\"><b> يبدأ من :</b></ion-text>\n                    <ion-text> {{auct.productPrice - (0.3 * auct.productPrice)}} </ion-text> \n                  </ion-label>\n                </ion-col>\n                <ion-col size=\"6\" class=\"ion-text-end\">\n                  <ion-label class=\"f16\"> \n                    <ion-text color=\"dark\"><b>العربون :</b></ion-text>\n                    <ion-text> {{auct.deposit}} </ion-text> \n                  </ion-label> \n                </ion-col>\n              </ion-row> \n            </ion-grid> \n            <ion-grid class=\"mgt10\">\n              <ion-row class=\"ion-justify-content-center\" dir=\"rtl\">\n                <ion-label class=\"f16\"> \n                  <!-- <ion-text color=\"primary\"><b> التاريخ : </b></ion-text>  -->\n                  <ion-text> {{auct.start | date:'EEE dd-MM-yyyy' : undefined  : 'ar'}} </ion-text>\n                  <!-- <ion-text> {{auct.start | date:'EEE dd-MM'}} </ion-text> -->\n                </ion-label>\n                <ion-label class=\"f16\" dir=\"rtl\">\n                  <ion-text color=\"dark\" > &nbsp; {{auct.start | date:'hh:mm a': undefined  : 'ar'}}</ion-text>\n                 </ion-label>\n              </ion-row>\n              <ion-row  class=\"ion-justify-content-center\">\n                <ion-label class=\"f16\"> \n                  <ion-text color=\"dark\"><b>المدة :</b>  </ion-text>\n                  <ion-text>  {{auct.duration}} </ion-text>\n                </ion-label> \n              </ion-row>\n            </ion-grid> \n\n            <!-- <ion-button  fill=\"block\">Buy Now</ion-button> -->\n          </ion-card-content>\n        </ion-card>\n      </ion-slide> \n  </ion-slides>\n</ion-content>\n\n";

/***/ })

}]);
//# sourceMappingURL=src_app_home_home_module_ts.js.map