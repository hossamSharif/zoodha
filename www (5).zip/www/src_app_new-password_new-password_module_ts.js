"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_new-password_new-password_module_ts"],{

/***/ 4149:
/*!*************************************************************!*\
  !*** ./src/app/new-password/new-password-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewPasswordPageRoutingModule": () => (/* binding */ NewPasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _new_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-password.page */ 8994);




const routes = [
    {
        path: '',
        component: _new_password_page__WEBPACK_IMPORTED_MODULE_0__.NewPasswordPage
    }
];
let NewPasswordPageRoutingModule = class NewPasswordPageRoutingModule {
};
NewPasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NewPasswordPageRoutingModule);



/***/ }),

/***/ 2630:
/*!*****************************************************!*\
  !*** ./src/app/new-password/new-password.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewPasswordPageModule": () => (/* binding */ NewPasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _new_password_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-password-routing.module */ 4149);
/* harmony import */ var _new_password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-password.page */ 8994);







let NewPasswordPageModule = class NewPasswordPageModule {
};
NewPasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _new_password_routing_module__WEBPACK_IMPORTED_MODULE_0__.NewPasswordPageRoutingModule
        ],
        declarations: [_new_password_page__WEBPACK_IMPORTED_MODULE_1__.NewPasswordPage]
    })
], NewPasswordPageModule);



/***/ }),

/***/ 8994:
/*!***************************************************!*\
  !*** ./src/app/new-password/new-password.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewPasswordPage": () => (/* binding */ NewPasswordPage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _new_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-password.page.html?ngResource */ 9527);
/* harmony import */ var _new_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./new-password.page.scss?ngResource */ 5892);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/socket-service.service */ 905);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ 190);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);










let NewPasswordPage = class NewPasswordPage {
  constructor(modalController, formBuilder, toast, route, storage, rout, api) {
    this.modalController = modalController;
    this.formBuilder = formBuilder;
    this.toast = toast;
    this.route = route;
    this.storage = storage;
    this.rout = rout;
    this.api = api;
    this.style = 'style2';
    this.spinner = false;
    this.isSubmitted = false;
    this.confirmPass = "";
    this.password = "";
    this.passType = 'password';
    this.confType = 'password';
    this.show = false;
    this.showConf = false;
    this.ionicForm = this.formBuilder.group({
      password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.minLength(5), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.pattern('^([^0-9]*|[^A-Z]*|[^a-z]*|[a-zA-Z0-9]*)$')]],
      confirmPass: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.minLength(5), _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.pattern('^([^0-9]*|[^A-Z]*|[^a-z]*|[a-zA-Z0-9]*)$')]]
    });
    this.route.queryParams.subscribe(params => {
      if (params && params.user_info) {
        this.USER_INFO = JSON.parse(params.user_info); //this.timerKiller() //enable time killer fuction when you want to release v1 
      }
    });
  }

  ngOnInit() {}

  newPassword() {
    this.rout.navigate(['login']);
  }

  get errorControl() {
    return this.ionicForm.controls;
  }

  showPass(type) {
    if (type == 'pass') {
      if (this.show == true) {
        this.show = false;
        this.passType = 'password';
      } else {
        this.show = true;
        this.passType = 'text';
      }
    } else if (type == 'confirm') {
      if (this.showConf == true) {
        this.showConf = false;
        this.confType = 'password';
      } else {
        this.showConf = true;
        this.confType = 'text';
      }
    }
  }

  update() {
    if (this.validate() == true) {
      this.spinner = true;
      this.USER_INFO.logMethod = 1;
      this.USER_INFO.password = this.password;
      this.api.updatePass(this.USER_INFO).subscribe(data => {
        console.log('user was updated', data);
        let res = data;
        console.log('user was created', res['token']);
        this.storage.set('token', res['token']).then(response => {
          this.rout.navigate(['tabs/home']);
        });
      }, err => {
        console.log();
        this.spinner = false; // this.handleError( err.error.error ) 

        this.presentToast("حدث خطأ ما , حاول مرة اخري ", 'danger');
      }, () => {
        this.spinner = false;
      });
    }
  }

  handleError(msg) {
    if (msg == "duplicate phone") {
      this.presentToast('رقم الهاتف موجود مسبقا , قم بتسجيل الدخول', 'danger');
      return false;
    } else if (msg == "duplicate email") {
      this.presentToast("البريد موجود مسبقا", 'danger');
      return false;
    } else if (msg == "duplicate email") {
      this.presentToast('حدث خطأ ما ,حاول مرة اخري', 'danger');
      return false;
    } else {
      this.presentToast("حدث خطأ ما , حاول مرة اخري ", 'danger');
      return false;
    }
  }

  validate() {
    this.isSubmitted = true;

    if (this.ionicForm.valid == false) {
      console.log('Please provide all the required values!');
      return false;
    } else if (this.password.length > 0 && this.password != this.confirmPass) {
      return false;
    } else if (this.USER_INFO.password.length > 0 && this.USER_INFO.password == this.password) {
      this.presentToast('لقد ادخلت كلمة مرورك القديمة , الرجاء ادخال كلمة مرور اخري');
      return false;
    } else {
      return true;
    }
  }

  presentToast(msg, color) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  }

};

NewPasswordPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController
}, {
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute
}, {
  type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__.Storage
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService
}];

NewPasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-new-password',
  template: _new_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_new_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], NewPasswordPage);


/***/ }),

/***/ 5892:
/*!****************************************************************!*\
  !*** ./src/app/new-password/new-password.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = ".custInput {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-dark);\n  background-color: var(--ion-color-primary-contrast);\n  border-radius: 2rem;\n}\n\n.custItem {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-dark);\n  background-color: var(--ion-color-primary-contrast);\n  border-radius: 2rem;\n}\n\n.mgt10 {\n  margin-top: 10px;\n}\n\n.roundedGrid {\n  border-radius: 50px;\n  /* border-bottom-left-radius: 50px; */\n  /* border-bottom-right-radius: 50px; */\n  /* border-top-left-radius: 50px; */\n  /* border-top-right-radius: 50px; */\n  padding-left: 10px;\n  padding-right: 10px;\n}\n\n.custGridStyl2 {\n  margin-top: 10%;\n  display: grid;\n  align-items: center;\n}\n\n.header-md::after {\n  background-image: none;\n}\n\n.bordernon {\n  border: none;\n}\n\n.newHeight {\n  height: 375px;\n}\n\n.custH {\n  border-bottom-style: solid;\n  padding: 10px;\n  width: 120px;\n  text-align: center;\n}\n\n.custGrid2 {\n  position: relative;\n  top: -181px;\n}\n\n.footer-md::before {\n  background-image: none;\n}\n\n.borderNone {\n  border-radius: 0px;\n}\n\n.padd13 {\n  padding-top: 13%;\n}\n\n.padd1 {\n  padding: 1%;\n}\n\n.logoSvg {\n  position: absolute;\n  top: 30%;\n  left: 50%;\n  margin-right: 50%;\n  transform: translate(-50%, -50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5ldy1wYXNzd29yZC5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXGh1c2FtJTIwcHJvalxcem9vZG9oYVNkXFxzcmNcXGFwcFxcbmV3LXBhc3N3b3JkXFxuZXctcGFzc3dvcmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1DQUFBO0VBQ0EsbURBQUE7RUFDQSxtQkFBQTtBQ0RKOztBRElBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1DQUFBO0VBQ0EsbURBQUE7RUFDQSxtQkFBQTtBQ0RKOztBREdBO0VBQ0ksZ0JBQUE7QUNBSjs7QURHQTtFQUNJLG1CQUFBO0VBQ0EscUNBQUE7RUFDQSxzQ0FBQTtFQUNBLGtDQUFBO0VBQ0EsbUNBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDQUo7O0FESUE7RUFFSSxlQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FDRko7O0FESUE7RUFDSSxzQkFBQTtBQ0RKOztBRElBO0VBQ0ksWUFBQTtBQ0RKOztBRElBO0VBQ0ksYUFBQTtBQ0RKOztBREdBO0VBQ0ksMEJBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FDQUo7O0FERUE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7QUNDSjs7QURDQTtFQUNJLHNCQUFBO0FDRUo7O0FEQUE7RUFDSSxrQkFBQTtBQ0dKOztBRERBO0VBQ0ksZ0JBQUE7QUNJSjs7QURGQTtFQUNJLFdBQUE7QUNLSjs7QURIQTtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtFQUNBLGdDQUFBO0FDTUoiLCJmaWxlIjoibmV3LXBhc3N3b3JkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5cclxuLmN1c3RJbnB1dHtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IDAuNXB4O1xyXG4gICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAycmVtO1xyXG59XHJcblxyXG4uY3VzdEl0ZW17XHJcbiAgICBib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gICAgYm9yZGVyLXdpZHRoOiAwLjVweDtcclxuICAgIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMnJlbTtcclxufVxyXG4ubWd0MTB7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG4ucm91bmRlZEdyaWR7IFxyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIC8qIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDUwcHg7ICovXHJcbiAgICAvKiBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogNTBweDsgKi9cclxuICAgIC8qIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDUwcHg7ICovXHJcbiAgICAvKiBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNTBweDsgKi9cclxuICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XHJcbiBcclxuICAgIC8vIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcclxuICAgfVxyXG4uY3VzdEdyaWRTdHlsMntcclxuICAgIC8vIGhlaWdodDogMTAwJTtcclxuICAgIG1hcmdpbi10b3A6IDEwJTtcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcbi5oZWFkZXItbWQ6OmFmdGVyIHtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6bm9uZTtcclxufVxyXG5cclxuLmJvcmRlcm5vbntcclxuICAgIGJvcmRlcjogbm9uZTtcclxufVxyXG5cclxuLm5ld0hlaWdodHtcclxuICAgIGhlaWdodDogMzc1cHg7XHJcbn1cclxuLmN1c3RIe1xyXG4gICAgYm9yZGVyLWJvdHRvbS1zdHlsZTogc29saWQ7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgd2lkdGg6IDEyMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5jdXN0R3JpZDJ7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB0b3A6IC0xODFweDtcclxufVxyXG4uZm9vdGVyLW1kOjpiZWZvcmV7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiAgbm9uZTtcclxufVxyXG4uYm9yZGVyTm9uZXtcclxuICAgIGJvcmRlci1yYWRpdXM6IDBweDtcclxufVxyXG4ucGFkZDEze1xyXG4gICAgcGFkZGluZy10b3A6MTMlXHJcbn1cclxuLnBhZGQxe1xyXG4gICAgcGFkZGluZzogMSU7XHJcbn1cclxuLmxvZ29Tdmd7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDMwJTtcclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIG1hcmdpbi1yaWdodDogNTAlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcbn0iLCIuY3VzdElucHV0IHtcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXdpZHRoOiAwLjVweDtcbiAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcbiAgYm9yZGVyLXJhZGl1czogMnJlbTtcbn1cblxuLmN1c3RJdGVtIHtcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXdpZHRoOiAwLjVweDtcbiAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcbiAgYm9yZGVyLXJhZGl1czogMnJlbTtcbn1cblxuLm1ndDEwIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLnJvdW5kZWRHcmlkIHtcbiAgYm9yZGVyLXJhZGl1czogNTBweDtcbiAgLyogYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNTBweDsgKi9cbiAgLyogYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDUwcHg7ICovXG4gIC8qIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDUwcHg7ICovXG4gIC8qIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiA1MHB4OyAqL1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDEwcHg7XG59XG5cbi5jdXN0R3JpZFN0eWwyIHtcbiAgbWFyZ2luLXRvcDogMTAlO1xuICBkaXNwbGF5OiBncmlkO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uaGVhZGVyLW1kOjphZnRlciB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmU7XG59XG5cbi5ib3JkZXJub24ge1xuICBib3JkZXI6IG5vbmU7XG59XG5cbi5uZXdIZWlnaHQge1xuICBoZWlnaHQ6IDM3NXB4O1xufVxuXG4uY3VzdEgge1xuICBib3JkZXItYm90dG9tLXN0eWxlOiBzb2xpZDtcbiAgcGFkZGluZzogMTBweDtcbiAgd2lkdGg6IDEyMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5jdXN0R3JpZDIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRvcDogLTE4MXB4O1xufVxuXG4uZm9vdGVyLW1kOjpiZWZvcmUge1xuICBiYWNrZ3JvdW5kLWltYWdlOiBub25lO1xufVxuXG4uYm9yZGVyTm9uZSB7XG4gIGJvcmRlci1yYWRpdXM6IDBweDtcbn1cblxuLnBhZGQxMyB7XG4gIHBhZGRpbmctdG9wOiAxMyU7XG59XG5cbi5wYWRkMSB7XG4gIHBhZGRpbmc6IDElO1xufVxuXG4ubG9nb1N2ZyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAzMCU7XG4gIGxlZnQ6IDUwJTtcbiAgbWFyZ2luLXJpZ2h0OiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xufSJdfQ== */";

/***/ }),

/***/ 9527:
/*!****************************************************************!*\
  !*** ./src/app/new-password/new-password.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = " \n<ion-header>\n  <ion-toolbar  dir=\"rtl\">\n    \n      <ion-buttons slot=\"end\">\n        <ion-back-button></ion-back-button>\n      </ion-buttons>\n    \n    <!-- <ion-title>تغيير كلمة المرور</ion-title>  -->\n   </ion-toolbar>\n</ion-header>\n \n\n<ion-content dir=\"rtl\" *ngIf=\" style=='style1'\">\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col  size=\"12\" class=\"head3 newHeight ion-text-center \">  \n        <svg class=\"logoSvg\" width=\"119\" height=\"119\" viewBox=\"0 0 119 119\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <circle opacity=\"0.27\" cx=\"59.5\" cy=\"59.5\" r=\"59.5\" fill=\"white\"/>\n          <path d=\"M90.1941 52.2367H61.0521C59.4103 47.8509 56.2761 44.1827 52.2005 41.876C51.2458 41.3609 50.0547 41.7062 49.523 42.6508C48.9907 43.596 49.3137 44.7926 50.249 45.3421C54.1875 47.55 57.0009 51.3292 57.986 55.7355C58.9712 60.1419 58.0354 64.7597 55.4124 68.4345C52.7893 72.1099 48.7265 74.4959 44.2391 74.9961L46.0929 73.0762L46.0935 73.0768C46.4715 72.6994 46.6818 72.1859 46.6774 71.6521C46.6729 71.1181 46.4542 70.6086 46.0702 70.2373C45.6861 69.8665 45.1688 69.6656 44.6348 69.68C44.1009 69.6945 43.5952 69.9226 43.2317 70.3139L38.2226 75.4995C38.2165 75.5056 38.2126 75.5134 38.2065 75.5195C38.1737 75.5544 38.1465 75.5961 38.116 75.6327H38.1165C38.0649 75.6926 38.0166 75.7554 37.9722 75.8208C37.9406 75.8714 37.9173 75.9274 37.8895 75.9813V75.9807C37.8562 76.0406 37.8257 76.1022 37.798 76.165C37.7769 76.2199 37.7663 76.2782 37.7491 76.3359H37.7497C37.7269 76.4047 37.7086 76.4747 37.6936 76.5457L37.6875 76.5696C37.6786 76.6273 37.6814 76.6839 37.6775 76.7416C37.6736 76.7994 37.6625 76.856 37.6637 76.9148V76.9398H37.6642C37.6681 77.0142 37.677 77.088 37.6897 77.1618C37.6975 77.2173 37.7019 77.2734 37.7136 77.3278C37.7325 77.3982 37.7547 77.4682 37.7813 77.5365C37.8002 77.5892 37.8141 77.6441 37.8379 77.6957C37.8679 77.7596 37.9012 77.8223 37.9373 77.8828C37.9661 77.9316 37.9911 77.9821 38.0239 78.0299C38.0716 78.0932 38.1227 78.1537 38.1771 78.2108C38.207 78.2436 38.2309 78.2813 38.2636 78.3102L38.2864 78.3329L43.6097 83.4675C44.4034 84.2057 45.6422 84.1724 46.3953 83.3926C47.1485 82.6128 47.1385 81.3734 46.3725 80.6058L44.6637 78.9546H44.6642C48.9895 78.4673 53.0368 76.5758 56.1855 73.5698C59.3347 70.5644 61.4122 66.6098 62.1004 62.3111C62.4196 60.2919 62.4218 58.2349 62.1076 56.2153H90.194C90.7218 56.2153 91.2274 56.4251 91.6004 56.7981C91.9734 57.1711 92.1832 57.6767 92.1832 58.2045V67.156C92.1832 68.2544 91.2924 69.1452 90.194 69.1452C89.0956 69.1452 88.2048 68.2544 88.2048 67.156V64.1722C88.2048 63.6444 87.995 63.1387 87.622 62.7658C87.249 62.3928 86.7434 62.183 86.2155 62.183H80.2479C79.1495 62.183 78.2587 63.0738 78.2587 64.1722V67.156C78.2587 68.2544 77.3679 69.1452 76.2695 69.1452C75.1711 69.1452 74.2802 68.2544 74.2802 67.156V64.1722C74.2802 63.6444 74.0704 63.1387 73.6975 62.7658C73.3245 62.3928 72.8188 62.183 72.291 62.183H66.3234C65.225 62.183 64.3341 63.0738 64.3341 64.1722C64.3341 65.2706 65.225 66.1614 66.3234 66.1614H70.3018V67.156C70.3018 69.2879 71.4391 71.2582 73.2856 72.3244C75.1322 73.3901 77.4067 73.3901 79.2533 72.3244C81.0998 71.2582 82.2371 69.2879 82.2371 67.156V66.1614H84.2263V67.156C84.2263 69.2879 85.3636 71.2582 87.2102 72.3244C89.0567 73.3901 91.3313 73.3901 93.1778 72.3244C95.0244 71.2582 96.1616 69.2879 96.1616 67.156V58.2045C96.16 56.6221 95.5306 55.1058 94.4117 53.9868C93.2928 52.8679 91.7764 52.2384 90.194 52.2369L90.1941 52.2367Z\" fill=\"white\"/>\n          <path d=\"M33.5015 59.199C33.5015 61.5729 34.4445 63.8501 36.1234 65.5286C37.8017 67.2075 40.0791 68.1505 42.4529 68.1505C44.8268 68.1505 47.104 67.2075 48.7825 65.5286C50.4614 63.8503 51.4044 61.5729 51.4044 59.199C51.4044 56.8252 50.4614 54.548 48.7825 52.8695C47.1042 51.1906 44.8268 50.2476 42.4529 50.2476C40.0797 50.2503 37.8046 51.1939 36.1262 52.8723C34.4479 54.5508 33.5043 56.8258 33.5015 59.199ZM47.426 59.199C47.426 60.5178 46.9021 61.7828 45.9696 62.7157C45.0366 63.6481 43.7717 64.1721 42.4529 64.1721C41.1342 64.1721 39.8692 63.6481 38.9363 62.7157C38.0038 61.7827 37.4799 60.5178 37.4799 59.199C37.4799 57.8803 38.0038 56.6153 38.9363 55.6824C39.8693 54.7499 41.1342 54.226 42.4529 54.226C43.7711 54.2277 45.0355 54.7522 45.9679 55.6841C46.8998 56.6165 47.4243 57.8809 47.426 59.199Z\" fill=\"white\"/>\n          <path d=\"M32.7055 76.5222C33.6602 77.0372 34.8513 76.692 35.383 75.7474C35.9153 74.8022 35.5923 73.6055 34.657 73.0561C30.7185 70.8488 27.9051 67.0695 26.92 62.6637C25.9343 58.2579 26.8689 53.64 29.4915 49.9652C32.114 46.2899 36.1757 43.9032 40.6625 43.4021L38.8098 45.3208V45.3203C38.4318 45.6977 38.2209 46.2111 38.2254 46.745C38.2298 47.2789 38.4491 47.789 38.8331 48.1598C39.2172 48.5305 39.7345 48.7314 40.2679 48.717C40.8019 48.7031 41.3075 48.4745 41.671 48.0837L46.6802 42.8981L46.6879 42.8881V42.8876C46.7501 42.8199 46.8073 42.7477 46.8594 42.6717C46.8811 42.6406 46.9083 42.6139 46.9283 42.5823H46.9277C46.9688 42.5129 47.006 42.4408 47.0382 42.3664C47.0592 42.3214 47.0859 42.2798 47.1037 42.2332C47.1214 42.1866 47.1386 42.1111 47.1564 42.0489V42.0495C47.1775 41.984 47.1952 41.9174 47.2091 41.8502C47.2091 41.8425 47.2091 41.8341 47.2152 41.8264C47.2241 41.7686 47.2213 41.712 47.2252 41.6543C47.2291 41.5966 47.2402 41.54 47.2391 41.4811V41.4562V41.4567C47.2346 41.3823 47.2263 41.308 47.2135 41.2347C47.2058 41.1792 47.2013 41.1231 47.1897 41.0687C47.1708 40.9977 47.1481 40.9278 47.122 40.8595C47.1031 40.8068 47.0892 40.7518 47.0654 40.7002V40.7008C47.0354 40.6364 47.0021 40.5742 46.9655 40.5137C46.9366 40.4649 46.9116 40.4144 46.8789 40.3666V40.3661C46.8317 40.3028 46.7806 40.2423 46.7257 40.1851C46.6957 40.1524 46.6718 40.1146 46.6391 40.0858L46.6163 40.063L41.2965 34.9307C40.5028 34.1925 39.2639 34.2258 38.5108 35.0056C37.7577 35.7854 37.7677 37.0248 38.5336 37.7924L40.2503 39.4503C34.6367 40.068 29.5516 43.0463 26.2664 47.6397C22.9812 52.2331 21.8055 58.0077 23.035 63.5194C24.2639 69.0314 27.7805 73.7596 32.7058 76.522L32.7055 76.5222Z\" fill=\"white\"/>\n          </svg>\n     </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid class=\"custGrid2 ion-margin-bottom\">\n     <ion-row class=\"ion-justify-content-center\">\n    <ion-col size=\"10\" >\n     <ion-card class=\"bordernon w100\" >\n      <ion-card-header>\n        <ion-card-title>\n         <h3 ><b>إنشاء كلمة مرور جديدة</b></h3> \n        </ion-card-title>\n        <!-- <ion-card-subtitle>\n          Your new password must be different from previous used password\n        </ion-card-subtitle> -->\n      </ion-card-header>\n       <ion-grid>\n        <form [formGroup]=\"ionicForm\" (ngSubmit)=\"update()\" novalidate> \n        <ion-row class=\"ion-margin\">\n          <ion-list class=\"w100\"> \n           \n              <ion-item>\n                <ion-label position=\"floating\">كلمة المرور</ion-label>\n              <ion-input formControlName=\"password\" [(ngModel)]=\"password\" [type]=\"passType\"></ion-input>\n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.required\"> الحقل مطلوب </ion-note> \n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.length\"> مكون من 5 رموز علي الأقل </ion-note> \n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.pattern\"> يحوي حرف كبير وصغير ورمز ورقم</ion-note> \n              <ion-button  fill = \"clear\" (click)=\"showPass('pass')\" slot=\"end\">\n                <ion-icon  *ngIf=\"show == false\"     name=\"eye-off-outline\" ></ion-icon>\n                <ion-icon *ngIf=\"show == true\"       name=\"eye-outline\" ></ion-icon>\n               </ion-button>\n            </ion-item>\n             \n            <ion-item>\n              <ion-label position=\"floating\">تأكيد كلمة المرور</ion-label>\n              <ion-input formControlName=\"confirmPass\" [(ngModel)]=\"confirmPass\"  [type]=\"confType\"></ion-input>\n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && password.length > 0 && password != confirmPass\">  كلمة المرور غير مطابقة  </ion-note> \n              \n             <ion-button  fill = \"clear\" (click)=\"showPass('confirm')\" slot=\"end\">\n              <ion-icon  *ngIf=\"showConf == false\"    name=\"eye-off-outline\" ></ion-icon>\n              <ion-icon *ngIf=\"showConf == true\"     name=\"eye-outline\" ></ion-icon>\n             </ion-button>\n            </ion-item>   \n          </ion-list>\n        </ion-row> \n        <ion-row class=\"ion-margin\">\n          <ion-col size=\"12\">\n            <ion-item color=\"primary\" button (click)=\"update()\">\n              <ion-label class=\"ion-text-center\">حفظ التغييرات</ion-label> \n            </ion-item>\n          </ion-col>\n        </ion-row> \n        </form>\n       </ion-grid> \n      </ion-card>\n    </ion-col>\n    </ion-row>\n  </ion-grid>\n \n</ion-content>\n<ion-content dir=\"rtl\" *ngIf=\" style=='style2'\">\n  <ion-grid class=\"ion-no-padding ion-margin-top\">\n    <ion-row>\n      <ion-col  size=\"12\" class=\"ion-text-center \">  \n        <svg  width=\"119\" height=\"119\" viewBox=\"0 0 119 119\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <circle opacity=\"0.27\" cx=\"59.5\" cy=\"59.5\" r=\"59.5\" fill=\"black\"/>\n          <path d=\"M90.1941 52.2367H61.0521C59.4103 47.8509 56.2761 44.1827 52.2005 41.876C51.2458 41.3609 50.0547 41.7062 49.523 42.6508C48.9907 43.596 49.3137 44.7926 50.249 45.3421C54.1875 47.55 57.0009 51.3292 57.986 55.7355C58.9712 60.1419 58.0354 64.7597 55.4124 68.4345C52.7893 72.1099 48.7265 74.4959 44.2391 74.9961L46.0929 73.0762L46.0935 73.0768C46.4715 72.6994 46.6818 72.1859 46.6774 71.6521C46.6729 71.1181 46.4542 70.6086 46.0702 70.2373C45.6861 69.8665 45.1688 69.6656 44.6348 69.68C44.1009 69.6945 43.5952 69.9226 43.2317 70.3139L38.2226 75.4995C38.2165 75.5056 38.2126 75.5134 38.2065 75.5195C38.1737 75.5544 38.1465 75.5961 38.116 75.6327H38.1165C38.0649 75.6926 38.0166 75.7554 37.9722 75.8208C37.9406 75.8714 37.9173 75.9274 37.8895 75.9813V75.9807C37.8562 76.0406 37.8257 76.1022 37.798 76.165C37.7769 76.2199 37.7663 76.2782 37.7491 76.3359H37.7497C37.7269 76.4047 37.7086 76.4747 37.6936 76.5457L37.6875 76.5696C37.6786 76.6273 37.6814 76.6839 37.6775 76.7416C37.6736 76.7994 37.6625 76.856 37.6637 76.9148V76.9398H37.6642C37.6681 77.0142 37.677 77.088 37.6897 77.1618C37.6975 77.2173 37.7019 77.2734 37.7136 77.3278C37.7325 77.3982 37.7547 77.4682 37.7813 77.5365C37.8002 77.5892 37.8141 77.6441 37.8379 77.6957C37.8679 77.7596 37.9012 77.8223 37.9373 77.8828C37.9661 77.9316 37.9911 77.9821 38.0239 78.0299C38.0716 78.0932 38.1227 78.1537 38.1771 78.2108C38.207 78.2436 38.2309 78.2813 38.2636 78.3102L38.2864 78.3329L43.6097 83.4675C44.4034 84.2057 45.6422 84.1724 46.3953 83.3926C47.1485 82.6128 47.1385 81.3734 46.3725 80.6058L44.6637 78.9546H44.6642C48.9895 78.4673 53.0368 76.5758 56.1855 73.5698C59.3347 70.5644 61.4122 66.6098 62.1004 62.3111C62.4196 60.2919 62.4218 58.2349 62.1076 56.2153H90.194C90.7218 56.2153 91.2274 56.4251 91.6004 56.7981C91.9734 57.1711 92.1832 57.6767 92.1832 58.2045V67.156C92.1832 68.2544 91.2924 69.1452 90.194 69.1452C89.0956 69.1452 88.2048 68.2544 88.2048 67.156V64.1722C88.2048 63.6444 87.995 63.1387 87.622 62.7658C87.249 62.3928 86.7434 62.183 86.2155 62.183H80.2479C79.1495 62.183 78.2587 63.0738 78.2587 64.1722V67.156C78.2587 68.2544 77.3679 69.1452 76.2695 69.1452C75.1711 69.1452 74.2802 68.2544 74.2802 67.156V64.1722C74.2802 63.6444 74.0704 63.1387 73.6975 62.7658C73.3245 62.3928 72.8188 62.183 72.291 62.183H66.3234C65.225 62.183 64.3341 63.0738 64.3341 64.1722C64.3341 65.2706 65.225 66.1614 66.3234 66.1614H70.3018V67.156C70.3018 69.2879 71.4391 71.2582 73.2856 72.3244C75.1322 73.3901 77.4067 73.3901 79.2533 72.3244C81.0998 71.2582 82.2371 69.2879 82.2371 67.156V66.1614H84.2263V67.156C84.2263 69.2879 85.3636 71.2582 87.2102 72.3244C89.0567 73.3901 91.3313 73.3901 93.1778 72.3244C95.0244 71.2582 96.1616 69.2879 96.1616 67.156V58.2045C96.16 56.6221 95.5306 55.1058 94.4117 53.9868C93.2928 52.8679 91.7764 52.2384 90.194 52.2369L90.1941 52.2367Z\" fill=\"white\"/>\n          <path d=\"M33.5015 59.199C33.5015 61.5729 34.4445 63.8501 36.1234 65.5286C37.8017 67.2075 40.0791 68.1505 42.4529 68.1505C44.8268 68.1505 47.104 67.2075 48.7825 65.5286C50.4614 63.8503 51.4044 61.5729 51.4044 59.199C51.4044 56.8252 50.4614 54.548 48.7825 52.8695C47.1042 51.1906 44.8268 50.2476 42.4529 50.2476C40.0797 50.2503 37.8046 51.1939 36.1262 52.8723C34.4479 54.5508 33.5043 56.8258 33.5015 59.199ZM47.426 59.199C47.426 60.5178 46.9021 61.7828 45.9696 62.7157C45.0366 63.6481 43.7717 64.1721 42.4529 64.1721C41.1342 64.1721 39.8692 63.6481 38.9363 62.7157C38.0038 61.7827 37.4799 60.5178 37.4799 59.199C37.4799 57.8803 38.0038 56.6153 38.9363 55.6824C39.8693 54.7499 41.1342 54.226 42.4529 54.226C43.7711 54.2277 45.0355 54.7522 45.9679 55.6841C46.8998 56.6165 47.4243 57.8809 47.426 59.199Z\" fill=\"white\"/>\n          <path d=\"M32.7055 76.5222C33.6602 77.0372 34.8513 76.692 35.383 75.7474C35.9153 74.8022 35.5923 73.6055 34.657 73.0561C30.7185 70.8488 27.9051 67.0695 26.92 62.6637C25.9343 58.2579 26.8689 53.64 29.4915 49.9652C32.114 46.2899 36.1757 43.9032 40.6625 43.4021L38.8098 45.3208V45.3203C38.4318 45.6977 38.2209 46.2111 38.2254 46.745C38.2298 47.2789 38.4491 47.789 38.8331 48.1598C39.2172 48.5305 39.7345 48.7314 40.2679 48.717C40.8019 48.7031 41.3075 48.4745 41.671 48.0837L46.6802 42.8981L46.6879 42.8881V42.8876C46.7501 42.8199 46.8073 42.7477 46.8594 42.6717C46.8811 42.6406 46.9083 42.6139 46.9283 42.5823H46.9277C46.9688 42.5129 47.006 42.4408 47.0382 42.3664C47.0592 42.3214 47.0859 42.2798 47.1037 42.2332C47.1214 42.1866 47.1386 42.1111 47.1564 42.0489V42.0495C47.1775 41.984 47.1952 41.9174 47.2091 41.8502C47.2091 41.8425 47.2091 41.8341 47.2152 41.8264C47.2241 41.7686 47.2213 41.712 47.2252 41.6543C47.2291 41.5966 47.2402 41.54 47.2391 41.4811V41.4562V41.4567C47.2346 41.3823 47.2263 41.308 47.2135 41.2347C47.2058 41.1792 47.2013 41.1231 47.1897 41.0687C47.1708 40.9977 47.1481 40.9278 47.122 40.8595C47.1031 40.8068 47.0892 40.7518 47.0654 40.7002V40.7008C47.0354 40.6364 47.0021 40.5742 46.9655 40.5137C46.9366 40.4649 46.9116 40.4144 46.8789 40.3666V40.3661C46.8317 40.3028 46.7806 40.2423 46.7257 40.1851C46.6957 40.1524 46.6718 40.1146 46.6391 40.0858L46.6163 40.063L41.2965 34.9307C40.5028 34.1925 39.2639 34.2258 38.5108 35.0056C37.7577 35.7854 37.7677 37.0248 38.5336 37.7924L40.2503 39.4503C34.6367 40.068 29.5516 43.0463 26.2664 47.6397C22.9812 52.2331 21.8055 58.0077 23.035 63.5194C24.2639 69.0314 27.7805 73.7596 32.7058 76.522L32.7055 76.5222Z\" fill=\"white\"/>\n          </svg>\n     </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid class=\"custGridStyl2 ion-margin-bottom\">\n     <ion-row class=\"ion-justify-content-center\">\n    <ion-col size=\"10\" >\n     <ion-card class=\" roundedGrid w100\" >\n      <ion-card-header>\n        <ion-card-title>\n         <h3 ><b>إنشاء كلمة مرور جديدة</b></h3> \n        </ion-card-title>\n        <!-- <ion-card-subtitle>\n          Your new password must be different from previous used password\n        </ion-card-subtitle> -->\n      </ion-card-header>\n       <ion-grid>\n        <form [formGroup]=\"ionicForm\" (ngSubmit)=\"update()\" novalidate> \n        <ion-row class=\"ion-margin\">\n          <ion-list class=\"w100\">  \n              <ion-item class=\"custInput mgt10\">\n              <ion-input placeholder=\"كلمة المرور\" formControlName=\"password\" [(ngModel)]=\"password\" [type]=\"passType\"></ion-input>\n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.required\"> الحقل مطلوب </ion-note> \n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.length\"> مكون من 5 رموز علي الأقل </ion-note> \n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.pattern\"> يحوي حرف كبير وصغير ورمز ورقم</ion-note> \n              <ion-button  fill = \"clear\" (click)=\"showPass('pass')\" slot=\"end\">\n                <ion-icon  *ngIf=\"show == false\"     name=\"eye-off-outline\" ></ion-icon>\n                <ion-icon *ngIf=\"show == true\"       name=\"eye-outline\" ></ion-icon>\n               </ion-button>\n            </ion-item>\n             \n            <ion-item class=\"custInput mgt10\">\n              <ion-input  placeholder=\"تأكيد كلمة المرور\"  formControlName=\"confirmPass\" [(ngModel)]=\"confirmPass\"  [type]=\"confType\"></ion-input>\n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && password.length > 0 && password != confirmPass\">  كلمة المرور غير مطابقة  </ion-note> \n              \n             <ion-button  fill = \"clear\" (click)=\"showPass('confirm')\" slot=\"end\">\n              <ion-icon  *ngIf=\"showConf == false\"    name=\"eye-off-outline\" ></ion-icon>\n              <ion-icon *ngIf=\"showConf == true\"     name=\"eye-outline\" ></ion-icon>\n             </ion-button>\n            </ion-item>   \n          </ion-list>\n        </ion-row> \n        <ion-row class=\"ion-margin\">\n          <ion-col size=\"12\">\n            <ion-item  class=\"custItem\" color=\"dark\"   button (click)=\"update()\">\n              <ion-label class=\"ion-text-center\">حفظ التغييرات</ion-label> \n            </ion-item>\n          </ion-col>\n        </ion-row> \n        </form>\n       </ion-grid> \n      </ion-card>\n    </ion-col>\n    </ion-row>\n  </ion-grid>\n \n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_new-password_new-password_module_ts.js.map