(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _auth_auth_gaurd_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth/auth-gaurd.service */ 8261);




const routes = [
    {
        path: '',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tabs_tabs_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./tabs/tabs.module */ 5564)).then(m => m.TabsPageModule), canActivate: [_auth_auth_gaurd_service__WEBPACK_IMPORTED_MODULE_0__.AuthGaurdService]
    },
    {
        path: 'login',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./login/login.module */ 107)).then(m => m.LoginPageModule)
    },
    {
        path: 'tabs',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tabs_tabs_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./tabs/tabs.module */ 5564)).then(m => m.TabsPageModule), canActivate: [_auth_auth_gaurd_service__WEBPACK_IMPORTED_MODULE_0__.AuthGaurdService]
    },
    {
        path: 'mazad-details',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("default-node_modules_moment-timezone_index_js"), __webpack_require__.e("default-src_app_mzad-subescribe_mzad-subescribe_page_ts"), __webpack_require__.e("default-src_app_mzad-details_mzad-details_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./mzad-details/mzad-details.module */ 3702)).then(m => m.MzadDetailsPageModule)
    },
    {
        path: 'sign-up',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_sign-up_sign-up_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./sign-up/sign-up.module */ 3982)).then(m => m.SignUpPageModule)
    },
    {
        path: 'wallet',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_wallet_wallet_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./wallet/wallet.module */ 9555)).then(m => m.WalletPageModule)
    },
    {
        path: 'profile',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_profile_profile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./profile/profile.module */ 4523)).then(m => m.ProfilePageModule)
    },
    {
        path: 'cart',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_cart_cart_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./cart/cart.module */ 2943)).then(m => m.CartPageModule)
    },
    {
        path: 'forget-password',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_forget-password_forget-password_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./forget-password/forget-password.module */ 4845)).then(m => m.ForgetPasswordPageModule)
    },
    {
        path: 'verify',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_verify_verify_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./verify/verify.module */ 1595)).then(m => m.VerifyPageModule)
    },
    {
        path: 'new-password',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_new-password_new-password_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./new-password/new-password.module */ 2630)).then(m => m.NewPasswordPageModule)
    },
    {
        path: 'select',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_select_select_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./select/select.module */ 6028)).then(m => m.SelectPageModule)
    },
    {
        path: 'my-bidding',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("default-node_modules_moment-timezone_index_js"), __webpack_require__.e("src_app_my-bidding_my-bidding_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./my-bidding/my-bidding.module */ 9480)).then(m => m.MyBiddingPageModule)
    },
    {
        path: 'live-mzad',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("default-node_modules_moment-timezone_index_js"), __webpack_require__.e("src_app_live-mzad_live-mzad_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./live-mzad/live-mzad.module */ 8561)).then(m => m.LiveMzadPageModule)
    },
    {
        path: 'mzad-subescribe',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("default-src_app_mzad-subescribe_mzad-subescribe_page_ts"), __webpack_require__.e("src_app_mzad-subescribe_mzad-subescribe_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./mzad-subescribe/mzad-subescribe.module */ 1371)).then(m => m.MzadSubescribePageModule)
    },
    {
        path: 'order-details',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_order-details_order-details_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./order-details/order-details.module */ 6078)).then(m => m.OrderDetailsPageModule)
    },
    {
        path: 'change-phone',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_change-phone_change-phone_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./change-phone/change-phone.module */ 5546)).then(m => m.ChangePhonePageModule)
    },
    {
        path: 'terms',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_terms_terms_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./terms/terms.module */ 5144)).then(m => m.TermsPageModule)
    },
    {
        path: 'err-modal',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_err-modal_err-modal_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./err-modal/err-modal.module */ 9475)).then(m => m.ErrModalPageModule)
    },
    {
        path: 'virefy-rest',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_virefy-rest_virefy-rest_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./virefy-rest/virefy-rest.module */ 1709)).then(m => m.VirefyRestPageModule)
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_3__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component.html?ngResource */ 3383);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss?ngResource */ 202);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 190);





let AppComponent = class AppComponent {
    constructor(storage) {
        this.storage = storage;
        this.storage.create();
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-root',
        template: _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AppComponent);



/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var _app_tabs_tabs_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../app/tabs/tabs-routing.module */ 530);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/storage-angular */ 7566);
/* harmony import */ var _auth_auth_gaurd_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth/auth-gaurd.service */ 8261);
/* harmony import */ var _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auth/auth-service.service */ 5465);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_common_locales_ar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/locales/ar */ 8162);
















//import { DateAgoPipe } from './pipes/date-ago.pipe';
(0,_angular_common__WEBPACK_IMPORTED_MODULE_5__.registerLocaleData)(_angular_common_locales_ar__WEBPACK_IMPORTED_MODULE_6__["default"], 'ar');
let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent],
        imports: [_angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClientModule, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__.BrowserModule, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_11__.ReactiveFormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicModule.forRoot(), _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__.IonicStorageModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_0__.AppRoutingModule, _app_tabs_tabs_routing_module__WEBPACK_IMPORTED_MODULE_1__.TabsPageRoutingModule],
        providers: [{ provide: _angular_router__WEBPACK_IMPORTED_MODULE_14__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicRouteStrategy }, _angular_common__WEBPACK_IMPORTED_MODULE_5__.DatePipe, _auth_auth_service_service__WEBPACK_IMPORTED_MODULE_4__.AuthServiceService, _auth_auth_gaurd_service__WEBPACK_IMPORTED_MODULE_3__.AuthGaurdService],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 8261:
/*!********************************************!*\
  !*** ./src/app/auth/auth-gaurd.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthGaurdService": () => (/* binding */ AuthGaurdService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _auth_service_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth-service.service */ 5465);



let AuthGaurdService = class AuthGaurdService {
    constructor(authenticationService) {
        this.authenticationService = authenticationService;
    }
    canActivate() {
        return this.authenticationService.isAuthenticated();
    }
};
AuthGaurdService.ctorParameters = () => [
    { type: _auth_service_service__WEBPACK_IMPORTED_MODULE_0__.AuthServiceService }
];
AuthGaurdService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], AuthGaurdService);



/***/ }),

/***/ 5465:
/*!**********************************************!*\
  !*** ./src/app/auth/auth-service.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthServiceService": () => (/* binding */ AuthServiceService)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/storage */ 190);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 4505);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/socket-service.service */ 905);
/* harmony import */ var _err_modal_err_modal_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../err-modal/err-modal.page */ 3362);









let AuthServiceService = class AuthServiceService {
  constructor(modalController, rout, toast, loadingController, api, router, storage, platform, toastController) {
    this.modalController = modalController;
    this.rout = rout;
    this.toast = toast;
    this.loadingController = loadingController;
    this.api = api;
    this.router = router;
    this.storage = storage;
    this.platform = platform;
    this.toastController = toastController;
    this.authState = new rxjs__WEBPACK_IMPORTED_MODULE_4__.BehaviorSubject(false);
    this.platform.ready().then(() => {
      this.ifLoggedIn();
    });
  }

  presentToast(msg, color) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  }

  presentModal(msg, status) {
    var _this2 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this2.modalController.create({
        component: _err_modal_err_modal_page__WEBPACK_IMPORTED_MODULE_3__.ErrModalPage,
        componentProps: {
          "error": "",
          "status": ""
        }
      });
      modal.onDidDismiss().then(dataReturned => {
        if (dataReturned !== null) {
          console.log(dataReturned);

          _this2.doAfterDissmiss(dataReturned);
        }
      });
      return yield modal.present();
    })();
  }

  reload() {
    this.ifLoggedIn();
  }

  doAfterDissmiss(dataReturned) {
    this.reload(); // this.rout.navigate(['cart']);  
  }

  presentLoadingWithOptions(msg, status) {
    var _this3 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this3.loadingController.create({
        spinner: 'bubbles',
        mode: 'ios',
        duration: 2000,
        message: msg,
        translucent: true,
        // cssClass: 'custom-class custom-loading',
        backdropDismiss: false
      });
      yield loading.present();
      const {
        role,
        data
      } = yield loading.onDidDismiss();
      console.log('Loading dismissed with role:', role);
    })();
  }

  ifLoggedIn() {
    console.log('im here bro');
    this.storage.get('token').then(response => {
      if (response) {
        console.log('token', response);
        this.presentLoadingWithOptions();
        this.api.auth(response).subscribe(data => {
          console.log('authservices', data);
          this.authState.next(true);
          this.rout.navigate(['tabs/home']);
        }, err => {
          console.log(err);
          this.presentModal();
        });
      } else {
        this.rout.navigate(['login']);
      }
    });
  }

  login(user) {
    var _this4 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this4.presentLoadingWithOptions('جاري تسجيل الدخول', 'login');
      console.log(user); // this.api.login(user).subscribe(data =>{
      //   console.log('loogingksks',data)
      //   let res = data
      //   if(res['id'] != null){
      //   this.USER_INFO ={
      //     id :res['id'],
      //     user_name:res['user_name'],
      //     full_name:res['full_name'],
      //     password:res['password'],
      //     store_id:res['store_id'] 
      //   } 
      //     console.log(  'sdlijlf' ,  this.USER_INFO)
      //     this.storage.set('USER_INFO', this.USER_INFO).then((response) => {
      //     this.router.navigate(['folder/sales']);
      //     this.authState.next(true);
      //   });
      //   }else{
      //     this.loadingController.dismiss()
      //     this.presentToast('خطأ في اسم المستخدم او كلمة المرور' ,'danger')
      //   }  
      // }, (err) => {
      //    console.log(err);
      //    this.loadingController.dismiss()
      //    this.presentToast('خطأ في اسم المستخدم او كلمة المرور' ,'danger')
      //   },()=>{ }
      // )      
    })();
  }

  logout() {
    var _this5 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this5.storage.remove('USER_INFO').then(() => {
        _this5.storage.remove('STORE_INFO').then(() => {
          _this5.router.navigate(['folder/login']);

          _this5.authState.next(false);
        });
      });
    })();
  }

  isAuthenticated() {
    return this.authState.value;
  }

};

AuthServiceService.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_2__.SocketServiceService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _ionic_storage__WEBPACK_IMPORTED_MODULE_1__.Storage
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.Platform
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController
}];

AuthServiceService = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Injectable)({
  providedIn: 'root'
})], AuthServiceService);


/***/ }),

/***/ 3362:
/*!*********************************************!*\
  !*** ./src/app/err-modal/err-modal.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ErrModalPage": () => (/* binding */ ErrModalPage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _err_modal_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./err-modal.page.html?ngResource */ 9510);
/* harmony import */ var _err_modal_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./err-modal.page.scss?ngResource */ 2680);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);






let ErrModalPage = class ErrModalPage {
  constructor(modalController) {
    this.modalController = modalController;
  }

  ngOnInit() {}

  dissmis(status) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.modalController.dismiss(status);
    })();
  }

};

ErrModalPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController
}];

ErrModalPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-err-modal',
  template: _err_modal_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_err_modal_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ErrModalPage);


/***/ }),

/***/ 905:
/*!****************************************************!*\
  !*** ./src/app/services/socket-service.service.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SocketServiceService": () => (/* binding */ SocketServiceService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 4505);
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! socket.io-client */ 4769);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 8987);





let SocketServiceService = class SocketServiceService {
    constructor(http) {
        this.http = http;
        //api = 'http://localhost:3000/'
        this.api = 'https://coral-app-pr5y9.ondigitalocean.app/';
        this.message$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject('');
        this.liveStremUserHadJoined = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
        this.liveStremUserHadBidding = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
        this.liveStremAuctionHadEndOnTime = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
        this.liveStremUserFucosToBidding = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
        this.liveStremUserFucosLostToBidding = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
        //  socket = io('http://localhost:3000/',{ transports: ['websocket', 'polling', 'flashsocket'] });
        this.socket = (0,socket_io_client__WEBPACK_IMPORTED_MODULE_0__.io)('https://coral-app-pr5y9.ondigitalocean.app/', { transports: ['websocket', 'polling', 'flashsocket'] });
        this.getNewMessage = () => {
            this.socket.on('message', (message) => {
                this.message$.next(message);
            });
            return this.message$.asObservable();
        };
        this.userJoinedAuction = () => {
            this.socket.on('userJoindAuction', (auctionRoom) => {
                console.log(auctionRoom);
                this.liveStremUserHadJoined.next(auctionRoom);
            });
            return this.liveStremUserHadJoined.asObservable();
        };
        this.userBiddedInAuction = () => {
            this.socket.on('userBiddedInAuction', (auctionRoom) => {
                console.log(auctionRoom);
                this.liveStremUserHadBidding.next(auctionRoom);
            });
            return this.liveStremUserHadBidding.asObservable();
        };
        /// mzad end on time 
        this.auctionEndOntime = () => {
            this.socket.on('auctionEndOntime', (ar) => {
                console.log('auctionEndOntime', ar);
                this.liveStremAuctionHadEndOnTime.next(ar);
            });
            return this.liveStremAuctionHadEndOnTime.asObservable();
        };
        this.userFucosedBiddedInAuction = () => {
            this.socket.on('userFucosedBiddedInAuction', (auctionRoom) => {
                console.log(auctionRoom);
                this.liveStremUserFucosToBidding.next(auctionRoom);
            });
            return this.liveStremUserFucosToBidding.asObservable();
        };
        this.userFucosedLostBiddedInAuction = () => {
            this.socket.on('userFucosedlostBiddedInAuction', (auctionRoom) => {
                console.log(auctionRoom);
                this.liveStremUserFucosLostToBidding.next(auctionRoom);
            });
            return this.liveStremUserFucosLostToBidding.asObservable();
        };
    }
    sendMessage(message) {
        this.socket.emit('message', message);
    }
    sendsms(phone, code) {
        console.log('msg', phone, code);
        let msg = 'your verify code is : ' + code;
        let senderId = 'Farhatna';
        phone = '249' + phone;
        return this.http.get('https://mazinhost.com/smsv1/sms/api?action=send-sms&api_key=aG9zc2Ftc2hhcmlmMTk5MEBnbWFpbC5jb206cHVjJHYxQlB4dA==&to=' + phone + '&from=' + senderId + '&sms=' + msg);
    }
    getAuction(id) {
        console.log('this.auctionId from live service', id);
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('id', id);
        return this.http.get(this.api + 'auctions/' + id);
    }
    getOrder(id) {
        console.log('this.auctionId from live service', id);
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('id', id);
        return this.http.get(this.api + 'orders/' + id);
    }
    getUserOrder(userId) {
        console.log('this.auctionId from live service', userId);
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('userId', userId);
        return this.http.get(this.api + 'orders/all/' + userId);
    }
    getBalance(userId) {
        console.log('this.auctionId from live service', userId);
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('userId', userId);
        return this.http.get(this.api + 'transactions/balance/' + userId);
    }
    getAllTransaction(userId) {
        console.log('this.auctionId from live service', userId);
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('userId', userId);
        return this.http.get(this.api + 'transactions/all/' + userId);
    }
    getAllAuction() {
        return this.http.get(this.api + 'auctions/all');
    }
    getUserAuction(userId) {
        console.log('this.auctionId from live service', userId);
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('userId', userId);
        return this.http.get(this.api + 'auctions/userauction/' + userId);
    }
    getNewAuction() {
        this.socket.on('create', function (room) {
            console.log('room created aknolage' + room);
            // socket.join(room);
        });
    }
    loginEmit(id) {
        this.socket.emit('identity', id);
    }
    updateAuctions(auction) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('auction', auction);
        return this.http.post(this.api + 'auctions/update/', auction);
    }
    updateAuctionsLog(auction) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('auction', auction);
        return this.http.post(this.api + 'auctions/updatelog/', auction);
    }
    endAuctionOntime(auction) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('auction', auction);
        return this.http.post(this.api + 'auctions/endAuctionOnTime/', auction);
    }
    updateAuctionUsers(auction) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('auction', auction);
        return this.http.post(this.api + 'auctions/updateAuctionUsers/', auction);
    }
    cancelAuctionUsers(auction) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('auction', auction);
        return this.http.post(this.api + 'auctions/cancelAuctionUsers/', auction);
    }
    resubiscribeAuctionUsers(auction) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('auction', auction);
        return this.http.post(this.api + 'auctions/resubiscribeAuctionUsers/', auction);
    }
    createTransaction(transaction) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('transaction', transaction);
        return this.http.post(this.api + 'transactions/', transaction);
    }
    loginPhone(phone, imei) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('phone', phone);
        params = params.append('imei', imei);
        return this.http.get(this.api + 'users/loginphone/' + phone + '&' + imei);
    }
    loginEmail(email, password) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('email', email);
        params = params.append('password', password);
        return this.http.get(this.api + 'users/loginemail/' + email + '&' + password);
    }
    createUser(user) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('user', user);
        return this.http.post(this.api + 'users/create/', user);
    }
    sendMail(user) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('user', user);
        return this.http.post(this.api + 'users/resetemail/', user);
    }
    updateUser(user) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('user', user);
        return this.http.post(this.api + 'users/update/', user);
    }
    updatePass(user) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('user', user);
        return this.http.post(this.api + 'users/updatepass/', user);
    }
    updatePhone(user) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('user', user);
        return this.http.post(this.api + 'users/updatephone/', user);
    }
    sendVirfyCode(code, number) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('code', code);
        params = params.append('number', number);
        return this.http.get(this.api + 'users/loginphone/' + code);
    }
    auth(token) {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpParams();
        params = params.append('token', token);
        return this.http.get(this.api + 'users/auth/' + token);
    }
    userJoiningAuction(auctionRoom) {
        console.log(auctionRoom);
        this.socket.emit('joiningAuction', auctionRoom);
    }
    ///bidding proccess
    userBiddingInAuction(auctionRoom) {
        console.log(auctionRoom);
        this.socket.emit('biddingInAuction', auctionRoom);
    }
    //fucos to bidding 
    userFucosBiddingInAuction(auctionRoom) {
        console.log(auctionRoom);
        this.socket.emit('fucosBiddingInAuction', auctionRoom);
    }
    //lost fucos to bidding 
    userFucosLostBiddingInAuction(auctionRoom) {
        console.log(auctionRoom);
        this.socket.emit('fucosLostBiddingInAuction', auctionRoom);
    }
};
SocketServiceService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient }
];
SocketServiceService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
        providedIn: 'root'
    })
], SocketServiceService);



/***/ }),

/***/ 530:
/*!*********************************************!*\
  !*** ./src/app/tabs/tabs-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPageRoutingModule": () => (/* binding */ TabsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs.page */ 7942);
/* harmony import */ var _auth_auth_gaurd_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../auth/auth-gaurd.service */ 8261);





const routes = [
    {
        path: 'tabs',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_0__.TabsPage,
        children: [
            {
                path: 'home',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("default-node_modules_moment-timezone_index_js"), __webpack_require__.e("src_app_home_home_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../home/home.module */ 3467)).then(m => m.HomePageModule), canActivate: [_auth_auth_gaurd_service__WEBPACK_IMPORTED_MODULE_1__.AuthGaurdService]
            },
            {
                path: 'my-account',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_my-account_my-account_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../my-account/my-account.module */ 7796)).then(m => m.MyAccountPageModule)
            },
            {
                path: 'cart',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_cart_cart_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../cart/cart.module */ 2943)).then(m => m.CartPageModule)
            },
            {
                path: 'my-bidding',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_moment_moment_js"), __webpack_require__.e("default-node_modules_moment-timezone_index_js"), __webpack_require__.e("src_app_my-bidding_my-bidding_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../my-bidding/my-bidding.module */ 9480)).then(m => m.MyBiddingPageModule)
            },
            {
                path: 'wallet',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_wallet_wallet_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../wallet/wallet.module */ 9555)).then(m => m.WalletPageModule)
            },
            {
                path: '',
                redirectTo: 'tabs/home',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: 'tabs/home',
        pathMatch: 'full'
    }
];
let TabsPageRoutingModule = class TabsPageRoutingModule {
};
TabsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
    })
], TabsPageRoutingModule);



/***/ }),

/***/ 7942:
/*!***********************************!*\
  !*** ./src/app/tabs/tabs.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPage": () => (/* binding */ TabsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _tabs_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs.page.html?ngResource */ 5230);
/* harmony import */ var _tabs_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs.page.scss?ngResource */ 4710);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);




let TabsPage = class TabsPage {
    constructor() { }
};
TabsPage.ctorParameters = () => [];
TabsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-tabs',
        template: _tabs_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tabs_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TabsPage);



/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 6057);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		79,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		5593,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		3225,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		4812,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		6655,
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		4856,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		3059,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		8648,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		8308,
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		4690,
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		4090,
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		6214,
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		9447,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime-button.entry.js": [
		7950,
		"default-node_modules_ionic_core_dist_esm_data-caf38df0_js-node_modules_ionic_core_dist_esm_th-d3ab8e",
		"node_modules_ionic_core_dist_esm_ion-datetime-button_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		9689,
		"default-node_modules_ionic_core_dist_esm_data-caf38df0_js-node_modules_ionic_core_dist_esm_th-d3ab8e",
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		8840,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		749,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		9667,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		3288,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		5473,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		3634,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		2855,
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		495,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		8737,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		9632,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		4446,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		2275,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		8050,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		1772,
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		3592,
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		5454,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		290,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		2666,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		4816,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		5534,
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		4902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		1938,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		8179,
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		668,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		1624,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		9989,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		8902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		199,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		8395,
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		6357,
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		8268,
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		5269,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		2875,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 202:
/*!***********************************************!*\
  !*** ./src/app/app.component.scss?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 2680:
/*!**********************************************************!*\
  !*** ./src/app/err-modal/err-modal.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlcnItbW9kYWwucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 4710:
/*!************************************************!*\
  !*** ./src/app/tabs/tabs.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".order-badge {\n  position: absolute;\n  top: -10px;\n  right: -10px;\n  background-color: red;\n  color: white;\n  font-size: 12px;\n  font-weight: bold;\n  padding: 2px 6px;\n  border-radius: 50%;\n}\n\nion-tab-bar {\n  --background: var(--ion-color-dark);\n  box-shadow: 0px 1px 2px rgba(0, 0, 0, 0.2);\n  bottom: 15px;\n  position: relative;\n  border-radius: 40px;\n  width: 92%;\n  border-top: none;\n  margin: 0 auto;\n  padding: 6px;\n  height: 65px;\n}\n\nion-tab-button.tab-selected {\n  --background:var(--ion-color-primary-contrast);\n  border-radius: 100%;\n}\n\nion-tab-button {\n  --color:var(--ion-color-light);\n  --color-selected: var(--ion-color-dark);\n  --padding-bottom: 8px;\n  --padding-top: 8px;\n  --background: var(--ion-color-dark);\n}\n\nion-tab-button::before {\n  background-color: transparent;\n  display: block;\n  content: \"\";\n  margin: 0 auto;\n  width: 20px;\n  height: 2px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYnMucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFxodXNhbSUyMHByb2pcXHpvb2RvaGFTZFxcc3JjXFxhcHBcXHRhYnNcXHRhYnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksa0JBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUNBSjs7QURHRTtFQUNFLG1DQUFBO0VBQ0EsMENBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtBQ0FKOztBRElFO0VBQ0UsOENBQUE7RUFDRSxtQkFBQTtBQ0ROOztBREdFO0VBQ0UsOEJBQUE7RUFDQSx1Q0FBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDRCxtQ0FBQTtBQ0FIOztBREdJO0VBQ0UsNkJBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtBQ0ROIiwiZmlsZSI6InRhYnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4ub3JkZXItYmFkZ2Uge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IC0xMHB4O1xuICAgIHJpZ2h0OiAtMTBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZWQ7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtc2l6ZTogMTJweDtcbiAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICBwYWRkaW5nOiAycHggNnB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgfVxuXG4gIGlvbi10YWItYmFyIHtcbiAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcbiAgICBib3gtc2hhZG93OiAwcHggMXB4IDJweCByZ2JhKDAsIDAsIDAsIDAuMik7XG4gICAgYm90dG9tOiAxNXB4O1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICBib3JkZXItcmFkaXVzOiA0MHB4O1xuICAgIHdpZHRoOiA5MiU7XG4gICAgYm9yZGVyLXRvcDogbm9uZTtcbiAgICBtYXJnaW46IDAgYXV0bztcbiAgICBwYWRkaW5nOiA2cHg7XG4gICAgaGVpZ2h0OiA2NXB4O1xuICB9XG4gIFxuXG4gIGlvbi10YWItYnV0dG9uLnRhYi1zZWxlY3RlZCB7XG4gICAgLS1iYWNrZ3JvdW5kOnZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIH0gXG4gIGlvbi10YWItYnV0dG9uIHtcbiAgICAtLWNvbG9yOnZhcigtLWlvbi1jb2xvci1saWdodCk7IFxuICAgIC0tY29sb3Itc2VsZWN0ZWQ6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcbiAgICAtLXBhZGRpbmctYm90dG9tOiA4cHg7XG4gICAgLS1wYWRkaW5nLXRvcDogOHB4OyBcbiAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xuICBcbiAgXG4gICAgJjo6YmVmb3JlIHtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICAgICAgZGlzcGxheTogYmxvY2s7XG4gICAgICBjb250ZW50OiBcIlwiO1xuICAgICAgbWFyZ2luOiAwIGF1dG87XG4gICAgICB3aWR0aDogMjBweDtcbiAgICAgIGhlaWdodDogMnB4O1xuICAgIH1cblxuICAgXG4gICAgLy8gJi50YWItc2VsZWN0ZWQ6OmJlZm9yZSB7XG4gICAgLy8gYmFja2dyb3VuZC1jb2xvcjogIzVhNDFhMDtcbiAgICBcbiAgICAvLyB9XG4gIH0iLCIub3JkZXItYmFkZ2Uge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogLTEwcHg7XG4gIHJpZ2h0OiAtMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmVkO1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIHBhZGRpbmc6IDJweCA2cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cblxuaW9uLXRhYi1iYXIge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcbiAgYm94LXNoYWRvdzogMHB4IDFweCAycHggcmdiYSgwLCAwLCAwLCAwLjIpO1xuICBib3R0b206IDE1cHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgYm9yZGVyLXJhZGl1czogNDBweDtcbiAgd2lkdGg6IDkyJTtcbiAgYm9yZGVyLXRvcDogbm9uZTtcbiAgbWFyZ2luOiAwIGF1dG87XG4gIHBhZGRpbmc6IDZweDtcbiAgaGVpZ2h0OiA2NXB4O1xufVxuXG5pb24tdGFiLWJ1dHRvbi50YWItc2VsZWN0ZWQge1xuICAtLWJhY2tncm91bmQ6dmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xufVxuXG5pb24tdGFiLWJ1dHRvbiB7XG4gIC0tY29sb3I6dmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgLS1jb2xvci1zZWxlY3RlZDogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xuICAtLXBhZGRpbmctYm90dG9tOiA4cHg7XG4gIC0tcGFkZGluZy10b3A6IDhweDtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG59XG5pb24tdGFiLWJ1dHRvbjo6YmVmb3JlIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBjb250ZW50OiBcIlwiO1xuICBtYXJnaW46IDAgYXV0bztcbiAgd2lkdGg6IDIwcHg7XG4gIGhlaWdodDogMnB4O1xufSJdfQ== */";

/***/ }),

/***/ 3383:
/*!***********************************************!*\
  !*** ./src/app/app.component.html?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n";

/***/ }),

/***/ 9510:
/*!**********************************************************!*\
  !*** ./src/app/err-modal/err-modal.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n<ion-content>\n  <ion-grid  class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"dissmis('reload')\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n</ion-grid>\n</ion-content>\n";

/***/ }),

/***/ 5230:
/*!************************************************!*\
  !*** ./src/app/tabs/tabs.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-tabs>\n\n  <ion-tab-bar slot=\"bottom\">\n   \n    <ion-tab-button tab=\"my-account\">\n      <ion-icon name=\"person\"></ion-icon>\n      <ion-label>حسابي</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"cart\">\n      <!-- <div class=\"order-badge\">2</div> -->\n      <ion-icon name=\"receipt-outline\"></ion-icon>\n      <ion-label>الطلبات</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"my-bidding\"> \n        <ion-icon name=\"hand-right-outline\"></ion-icon>\n        <ion-label>مزاداتي</ion-label> \n    </ion-tab-button> \n    <ion-tab-button tab=\"wallet\">\n      <ion-icon name=\"wallet-outline\"></ion-icon>\n      <ion-label>المحفظة</ion-label>\n    </ion-tab-button>\n    <ion-tab-button tab=\"home\">\n      <ion-icon name=\"home-outline\"></ion-icon>\n      <ion-label>الرئيسية</ion-label>\n    </ion-tab-button>\n  </ion-tab-bar>\n\n</ion-tabs>\n";

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map