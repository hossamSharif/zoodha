"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_my-account_my-account_module_ts"],{

/***/ 6541:
/*!*********************************************************!*\
  !*** ./src/app/my-account/my-account-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyAccountPageRoutingModule": () => (/* binding */ MyAccountPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _my_account_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./my-account.page */ 6197);




const routes = [
    {
        path: '',
        component: _my_account_page__WEBPACK_IMPORTED_MODULE_0__.MyAccountPage
    }
];
let MyAccountPageRoutingModule = class MyAccountPageRoutingModule {
};
MyAccountPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MyAccountPageRoutingModule);



/***/ }),

/***/ 7796:
/*!*************************************************!*\
  !*** ./src/app/my-account/my-account.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyAccountPageModule": () => (/* binding */ MyAccountPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _my_account_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./my-account-routing.module */ 6541);
/* harmony import */ var _my_account_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./my-account.page */ 6197);







let MyAccountPageModule = class MyAccountPageModule {
};
MyAccountPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _my_account_routing_module__WEBPACK_IMPORTED_MODULE_0__.MyAccountPageRoutingModule
        ],
        declarations: [_my_account_page__WEBPACK_IMPORTED_MODULE_1__.MyAccountPage]
    })
], MyAccountPageModule);



/***/ }),

/***/ 6197:
/*!***********************************************!*\
  !*** ./src/app/my-account/my-account.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyAccountPage": () => (/* binding */ MyAccountPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _my_account_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./my-account.page.html?ngResource */ 9420);
/* harmony import */ var _my_account_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./my-account.page.scss?ngResource */ 6337);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/storage */ 190);






let MyAccountPage = class MyAccountPage {
    constructor(storage, rout) {
        this.storage = storage;
        this.rout = rout;
    }
    ngOnInit() {
    }
    logout() {
        this.storage.remove('token').then((response) => {
            console.log(response);
            this.rout.navigate(['login']);
        });
    }
    profile() {
        this.rout.navigate(['profile']);
    }
};
MyAccountPage.ctorParameters = () => [
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__.Storage },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
MyAccountPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-my-account',
        template: _my_account_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_my_account_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MyAccountPage);



/***/ }),

/***/ 6337:
/*!************************************************************!*\
  !*** ./src/app/my-account/my-account.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = ".header-md::after {\n  background-image: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm15LWFjY291bnQucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFxodXNhbSUyMHByb2pcXHpvb2RvaGFTZFxcc3JjXFxhcHBcXG15LWFjY291bnRcXG15LWFjY291bnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0JBQUE7QUNDSiIsImZpbGUiOiJteS1hY2NvdW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXItbWQ6OmFmdGVyIHtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6bm9uZTtcclxufSIsIi5oZWFkZXItbWQ6OmFmdGVyIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn0iXX0= */";

/***/ }),

/***/ 9420:
/*!************************************************************!*\
  !*** ./src/app/my-account/my-account.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar dir=\"rtl\">\n   \n    <ion-title>\n      <ion-icon name=\"person-outline\"></ion-icon>\n      حسابي\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content dir=\"rtl\"> \n  <ion-item button (click)=\"profile()\" >\n    <ion-icon name=\"person-outline\" color=\"primary\"></ion-icon>\n    الملف الشخصي \n  </ion-item>\n  <ion-item button (click)=\"logout()\" >\n    <ion-icon name=\"power-outline\" color=\"danger\"></ion-icon>\n     تسجيل خروج \n  </ion-item>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_my-account_my-account_module_ts.js.map