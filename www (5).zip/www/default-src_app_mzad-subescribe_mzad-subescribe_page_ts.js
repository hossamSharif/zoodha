"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_mzad-subescribe_mzad-subescribe_page_ts"],{

/***/ 4937:
/*!*********************************************************!*\
  !*** ./src/app/mzad-subescribe/mzad-subescribe.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MzadSubescribePage": () => (/* binding */ MzadSubescribePage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _mzad_subescribe_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mzad-subescribe.page.html?ngResource */ 8184);
/* harmony import */ var _mzad_subescribe_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./mzad-subescribe.page.scss?ngResource */ 9093);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/socket-service.service */ 905);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ 6908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);









let MzadSubescribePage = class MzadSubescribePage {
  constructor(api, rout, loadingController, toast, actionSheetCtl, modalController) {
    this.api = api;
    this.rout = rout;
    this.loadingController = loadingController;
    this.toast = toast;
    this.actionSheetCtl = actionSheetCtl;
    this.modalController = modalController;
    this.agreeTerms = false;
  }

  ngOnInit() {
    console.log(this.mzd, this.USER_INFO);
  }

  presentLoadingWithOptions(msg) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this.loadingController.create({
        spinner: 'bubbles',
        mode: 'ios',
        duration: 5000,
        message: msg,
        translucent: true,
        // cssClass: 'custom-class custom-loading',
        backdropDismiss: false
      });
      yield loading.present();
      const {
        role,
        data
      } = yield loading.onDidDismiss();
      console.log('Loading dismissed with role:', role);
    })();
  }

  closeModal() {
    var _this2 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.modalController.dismiss();

      yield _this2.modalController.dismiss(_this2.mzd, 'cancel');
    })();
  }

  agreeCheck(ev) {
    console.log(ev.target.value);
    console.log(this.agreeTerms);
  }

  validate() {
    if (this.agreeTerms == false) {
      this.presentToast('الرجاء قراءة الشروط والإتفاقية والموافقة عليها', 'danger');
      return false;
    } else if (this.walletBalance < +this.mzd['deposite'] + +this.mzd['fee']) {
      this.presentToast('رصيدك غير كافي , الرجاء شحن محفظتك', 'danger');
      return false;
    } else if (this.checkRemainTime() <= 60000) {
      console.log('this.checkRemainTime()', this.checkRemainTime());
      this.presentToast('لا يمكنك الإشتراك , لقد بدأ المزاد بالفعل', 'danger');
      return false;
    } else {
      return true;
    } // validate if user not restircted
    // validate if user not from staff

  } // wallet pehavior subject must change when user add balance to his wallet from anotherapp


  checkRemainTime() {
    //offset between now and startdate auction
    let newDate = moment__WEBPACK_IMPORTED_MODULE_4__(this.mzd['start']);
    let today = new Date();
    return moment__WEBPACK_IMPORTED_MODULE_4__(newDate).diff(moment__WEBPACK_IMPORTED_MODULE_4__(today));
  }

  prepareUserbj(resubiscr) {
    if (!resubiscr) {
      let mzdTemp = {
        _id: this.mzd['_id'],
        user: [{
          "userId": this.USER_INFO._id,
          "status": 1,
          "time": new Date(),
          "cancel": 0,
          "cancelTime": "",
          "reason": "",
          "transactionId": ""
        }]
      };
      return mzdTemp;
    } else {
      let mzdTemp = {
        _id: this.mzd['_id'],
        user: [{
          "userId": this.USER_INFO._id,
          "cancel": 0,
          "cancelTime": null,
          "reason": "",
          "cancelTransId": ""
        }]
      };
      return mzdTemp;
    }
  }

  subescribe() {
    if (this.validate() == true) {
      this.presentLoadingWithOptions("جاري معالجة طلبك .."); //api to add user to log of mzad

      console.log('prepareUserbj', this.prepareUserbj());
      this.api.updateAuctionUsers(this.prepareUserbj()).subscribe(data => {
        console.log('auction update', data, data['updatedAuctionUsers']);
        this.mzd['users'] = data['updatedAuctionUsers']['users'];
        console.log(this.mzd);
        this.presentToast("تم الإشتراك بنجاح ", 'success'); //back to details page with new data

        this.modalController.dismiss(this.mzd, 'done');
      }, err => {
        this.loadingController.dismiss();
        console.log(err.error);
        this.handleError(err.error.error);
      }, () => {
        this.loadingController.dismiss();
      }); //api to add pay transaction + 
      //
      //socket emmit to tell others + push notification 
    }
  }

  reSubiscribtion() {
    // when user cancel subiscribe to auctions 
    // user can only cancel subiscrbe befor auction start date(){ 
    if (this.validate() == true) {
      this.presentLoadingWithOptions("جاري معالجة طلبك .."); //api to add user to log of mzad

      console.log('prepareUserbj', this.prepareUserbj('resubiscr'));
      this.api.resubiscribeAuctionUsers(this.prepareUserbj('resubiscr')).subscribe(data => {
        console.log('auction update', data, data['updatedAuctionUsers']);
        this.presentToast("تم الإشتراك بنجاح ", 'success');
        this.modalController.dismiss(this.mzd, 'done');
        this.rout.navigate(['tabs/home']);
      }, err => {
        this.loadingController.dismiss();
        console.log(err.error);
        this.handleError(err.error.error);
      }, () => {
        this.loadingController.dismiss();
      }); //api to add pay transaction + 
      //
      //socket emmit to tell others + push notification 
    }
  }

  handleError(err) {
    if (err == 'max users') {
      this.presentToast('اكتمل العدد المطلوب , لا يمكنك المشاركة', 'danger');
    } else if (err == 'prev cancel trans not done') {
      this.presentToast('لديك عملية إرجاع مبلغ لم تكتمل , لا يمكنك المشاركة', 'danger');
    } else {
      this.presentToast('حدث خطأ ما الرجاء المحاولة مرة اخري', 'danger');
    }
  }

  presentActionSheet() {
    var _this3 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const actionSheet = yield _this3.actionSheetCtl.create({
        header: 'دفع رسوم الإشتراك ',
        subHeader: _this3.mzd.fee + _this3.mzd.deposit + 'ج.س',
        cssClass: 'my-custom-class',
        mode: 'ios',
        buttons: [{
          text: 'المحفظة',
          // role: 'destructive',
          icon: 'wallet',
          // data: {
          //   type: 'delete'
          // },
          handler: () => {
            if (_this3.mzd.userOut == true) {
              _this3.reSubiscribtion();
            } else {
              _this3.subescribe();
            }
          }
        } // , {
        //   text: 'قوقل باي',
        //   icon: 'logo-google',
        //   data: 10,
        //   handler: () => {
        //     this.subescribe();
        //   }
        // }, {
        //   text: 'ابل باي',
        //   icon: 'logo-apple',
        //   data: 'Data value',
        //   handler: () => {
        //     this.subescribe();
        //   }
        // }
        , {
          text: 'إلغاء',
          icon: 'close',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }]
      });
      yield actionSheet.present();
      const {
        role,
        data
      } = yield actionSheet.onDidDismiss();
      console.log('onDidDismiss resolved with role and data', role, data);
    })();
  }

  presentToast(msg, color) {
    var _this4 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this4.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  }

};

MzadSubescribePage.ctorParameters = () => [{
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ActionSheetController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController
}];

MzadSubescribePage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-mzad-subescribe',
  template: _mzad_subescribe_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_mzad_subescribe_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], MzadSubescribePage);


/***/ }),

/***/ 9093:
/*!**********************************************************************!*\
  !*** ./src/app/mzad-subescribe/mzad-subescribe.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = ".footer {\n  border-style: solid;\n  border-width: 0.3px;\n  border-color: var(--ion-color-light-shade);\n  border-top-right-radius: 30px;\n  border-top-left-radius: 30px;\n}\n\n.footer-md::before {\n  background-image: none;\n}\n\n.action-sheet-container {\n  direction: rtl;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm16YWQtc3ViZXNjcmliZS5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXGh1c2FtJTIwcHJvalxcem9vZG9oYVNkXFxzcmNcXGFwcFxcbXphZC1zdWJlc2NyaWJlXFxtemFkLXN1YmVzY3JpYmUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDBDQUFBO0VBQ0EsNkJBQUE7RUFDQSw0QkFBQTtBQ0NKOztBREVBO0VBQ0ksc0JBQUE7QUNDSjs7QURFQTtFQUNJLGNBQUE7QUNDSiIsImZpbGUiOiJtemFkLXN1YmVzY3JpYmUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmZvb3RlcntcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IDAuM3B4O1xyXG4gICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpO1xyXG4gICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDMwcHg7XHJcbiAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAzMHB4O1xyXG59XHJcblxyXG4uZm9vdGVyLW1kOjpiZWZvcmV7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiAgbm9uZTtcclxufVxyXG5cclxuLmFjdGlvbi1zaGVldC1jb250YWluZXJ7XHJcbiAgICBkaXJlY3Rpb246IHJ0bDtcclxufVxyXG4gIFxyXG4gICAgICAgXHJcbiAiLCIuZm9vdGVyIHtcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXdpZHRoOiAwLjNweDtcbiAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpO1xuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMzBweDtcbiAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMzBweDtcbn1cblxuLmZvb3Rlci1tZDo6YmVmb3JlIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn1cblxuLmFjdGlvbi1zaGVldC1jb250YWluZXIge1xuICBkaXJlY3Rpb246IHJ0bDtcbn0iXX0= */";

/***/ }),

/***/ 8184:
/*!**********************************************************************!*\
  !*** ./src/app/mzad-subescribe/mzad-subescribe.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar dir=\"rtl\">\n    <ion-buttons slot=\"end\"> \n      <ion-button fill=\"clear\" (click)=\"closeModal()\"> \n        <ion-icon name=\"close-circle-outline\" color=\"danger\"></ion-icon>\n      </ion-button>\n    </ion-buttons> \n    <ion-title>الإشتراك في مزاد</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid class=\"ion-no-margin  ion-no-padding\"  dir=\"rtl\" >\n    <ion-row class=\"ion-no-padding\"> \n      <ion-card class=\"w100\"> \n        <ion-card-header>  \n            <ion-card-title>\n              <ion-icon name=\"cash-outline\" color=\"primary\"></ion-icon> \n              رسوم المشاركة\n            </ion-card-title>\n          </ion-card-header>\n          <ion-grid class=\"ion-no-margin  ion-no-padding ion-padding-bottom\" dir=\"rtl\">\n            <ion-row class=\"ion-no-margin  ion-no-padding\"> \n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item lines=\"none\"> \n                    <ion-label><ion-text color=\"primary\"><b>المنتج </b> </ion-text>  </ion-label>\n                    <ion-label slot=\"end\">\n                      <ion-text> {{ mzd['title'] }} </ion-text>\n                       \n                    </ion-label>\n                  </ion-item>\n              </ion-col>\n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item lines=\"none\"> \n                    <ion-label><ion-text color=\"primary\"><b>العربون</b> </ion-text>  </ion-label>\n                    <ion-label slot=\"end\">\n                      <ion-text> {{ mzd['deposit'] }} </ion-text>\n                      <ion-text> ج.س</ion-text>\n                    </ion-label>\n                  </ion-item>\n              </ion-col>\n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item>  \n                  <ion-label>\n                    <ion-text color=\"primary\"><b>رسوم دفتر </b> </ion-text>\n                  </ion-label>\n                  <ion-label slot=\"end\">\n                    <ion-text> {{ mzd['fee' ]}} </ion-text>\n                    <ion-text> ج.س</ion-text>\n                  </ion-label>\n                </ion-item>\n              </ion-col>\n\n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item lines=\"none\"> \n                  <ion-label>\n                    <ion-text color=\"primary\"><b>المجموع </b> </ion-text>\n                  </ion-label>\n                  <ion-label slot=\"end\"> \n                    <ion-text> {{ mzd['fee'] + mzd['deposit'] }}  </ion-text>\n                    <ion-text> ج.س</ion-text>\n                  </ion-label>\n                </ion-item>\n              </ion-col>\n            </ion-row>\n          </ion-grid> \n      </ion-card> \n      <ion-card class=\"w100\">\n        <ion-card-header>\n          <ion-card-title>\n            <ion-icon name=\"bookmark-outline\" color=\"primary\"></ion-icon> \n            بنود المزاد\n          </ion-card-title> \n        </ion-card-header>\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\" >\n             <ion-card-content> \n              <ion-label *ngFor=\"let term of mzd['terms']\">\n                <ion-icon name=\"pin\" color=\"primary\"></ion-icon>\n                <ion-text>{{term.desc}}</ion-text><br>\n               </ion-label> \n            </ion-card-content>\n            <ion-item>\n              <ion-label>أوافق علي الشروط </ion-label>\n              <ion-checkbox [(ngModel)]=\"agreeTerms\" (ionChange)=\"agreeCheck($event)\"></ion-checkbox>\n            </ion-item>\n            </ion-col>\n          </ion-row> \n        </ion-grid>\n      </ion-card> \n    </ion-row>\n  </ion-grid>\n</ion-content>\n<ion-footer class=\"footer\">\n  <ion-grid dir=\"rtl\">\n    <ion-row>\n      <ion-col size=\"6\">\n       <ion-button expand=\"block\" type=\"outline\" (click)=\"presentActionSheet()\"> \n        <h5>دفــع </h5>\n       </ion-button>\n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <h4 class=\"ion-no-margin\">\n        <ion-text color=\"primary\">\n            رسوم الإشتراك\n        </ion-text> <br>  \n        <ion-text>  {{mzd['fee'] + mzd['deposit']}}  </ion-text>\n        <ion-text> ج.س</ion-text>\n       </h4>  \n      </ion-col> \n    </ion-row>\n  </ion-grid>\n</ion-footer>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_mzad-subescribe_mzad-subescribe_page_ts.js.map