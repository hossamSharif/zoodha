"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_order-details_order-details_module_ts"],{

/***/ 6121:
/*!***************************************************************!*\
  !*** ./src/app/order-details/order-details-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderDetailsPageRoutingModule": () => (/* binding */ OrderDetailsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _order_details_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order-details.page */ 122);




const routes = [
    {
        path: '',
        component: _order_details_page__WEBPACK_IMPORTED_MODULE_0__.OrderDetailsPage
    }
];
let OrderDetailsPageRoutingModule = class OrderDetailsPageRoutingModule {
};
OrderDetailsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], OrderDetailsPageRoutingModule);



/***/ }),

/***/ 6078:
/*!*******************************************************!*\
  !*** ./src/app/order-details/order-details.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderDetailsPageModule": () => (/* binding */ OrderDetailsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _order_details_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./order-details-routing.module */ 6121);
/* harmony import */ var _order_details_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./order-details.page */ 122);







let OrderDetailsPageModule = class OrderDetailsPageModule {
};
OrderDetailsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _order_details_routing_module__WEBPACK_IMPORTED_MODULE_0__.OrderDetailsPageRoutingModule
        ],
        declarations: [_order_details_page__WEBPACK_IMPORTED_MODULE_1__.OrderDetailsPage]
    })
], OrderDetailsPageModule);



/***/ }),

/***/ 122:
/*!*****************************************************!*\
  !*** ./src/app/order-details/order-details.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrderDetailsPage": () => (/* binding */ OrderDetailsPage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _order_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./order-details.page.html?ngResource */ 6846);
/* harmony import */ var _order_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./order-details.page.scss?ngResource */ 5405);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/storage */ 190);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/socket-service.service */ 905);










let OrderDetailsPage = class OrderDetailsPage {
  constructor(api, socket, route, storage, loadingController, toast, actionSheetCtl, datePipe, rout, modalController) {
    this.api = api;
    this.socket = socket;
    this.route = route;
    this.storage = storage;
    this.loadingController = loadingController;
    this.toast = toast;
    this.actionSheetCtl = actionSheetCtl;
    this.datePipe = datePipe;
    this.rout = rout;
    this.modalController = modalController;
    this.errorLoad = false;
    this.order = undefined;
    this.higtPayedPrie = 0;
    this.showEmpty = false;
    this.showSkelton = false;
    this.route.queryParams.subscribe(params => {
      console.log('params', params);

      if (params && params.id) {
        this.USER_INFO = JSON.parse(params.user_info);
        this.orderId = JSON.parse(params.id);
        console.log(this.orderId);
        this.getOrder();
      }
    });
  }

  reload() {
    this.errorLoad = false;
    this.order = undefined;
    this.getOrder();
  }

  getOrder() {
    this.showSkelton = true;
    this.api.getOrder(this.orderId).subscribe(data => {
      console.log(data);
      let res = data['order'][0];
      this.order = res;
      console.log(this.order);
      this.preparOrders();
    }, err => {
      console.log(err);
      this.errorLoad = true;
    }, () => {
      this.showSkelton = false;
    });
  }

  getWalletBalance() {
    this.showSkelton = true;
    this.api.getBalance(this.USER_INFO._id).subscribe(data => {
      console.log(data);
      let res = data['transaction'][0];
      this.walletBalance = res.balance;
    }, err => {
      console.log(err);
    }, () => {});
  }

  getNetTot() {
    let net = this.higtPayedPrie - +this.order['auctions'][0].deposit;

    if (this.order.delivary) {
      net = net + +this.order.delivary;
    }

    if (this.order.discount) {
      net = +net - +this.order.discount;
    }

    return net;
  }

  preparOrders() {
    let arrmax = this.order['auctions'][0].logs.sort((a, b) => a.pay > b.pay ? -1 : 1);
    let arr = this.order['auctions'][0].logs.filter(x => x.userId == this.USER_INFO._id && +x.pay == +arrmax[0].pay);
    let winer = arr;
    this.higtPayedPrie = winer[0].pay;
  }

  ngOnInit() {}

  showActionPay() {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.getWalletBalance();
      yield _this.presentActionSheetPay();
    })();
  }

  presentActionSheetPay() {
    var _this2 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const actionSheet = yield _this2.actionSheetCtl.create({
        header: 'سداد مبلغ ',
        //  subHeader:  '  ج.س '  +  this.higtPayedPrie,  
        cssClass: 'my-custom-class',
        mode: 'ios',
        buttons: [{
          text: 'رصيد المحفظة' + _this2.walletBalance + " ج.س",
          //  role: 'destructive',
          icon: 'wallet',
          handler: () => {
            _this2.performPay();
          }
        }, {
          text: 'إلغاء',
          icon: 'close',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }]
      });
      yield actionSheet.present();
      const {
        role,
        data
      } = yield actionSheet.onDidDismiss();
      console.log('onDidDismiss resolved with role and data', role, data);
    })();
  }

  presentActionSheetPick() {
    var _this3 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const actionSheet = yield _this3.actionSheetCtl.create({
        header: 'سداد مبلغ ',
        //  subHeader:  '  ج.س '  +  this.higtPayedPrie,  
        cssClass: 'my-custom-class',
        mode: 'ios',
        buttons: [{
          text: 'المحفظة',
          //  role: 'destructive',
          icon: 'wallet',
          handler: () => {
            _this3.pickProduct();
          }
        }, {
          text: 'إلغاء',
          icon: 'close',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }]
      });
      yield actionSheet.present();
      const {
        role,
        data
      } = yield actionSheet.onDidDismiss();
      console.log('onDidDismiss resolved with role and data', role, data);
    })();
  }

  validateBalance() {
    if (+this.higtPayedPrie <= this.walletBalance) {
      return true;
    } else if (+this.higtPayedPrie > this.walletBalance) {
      return false;
    }
  }

  performPay() {
    var _this4 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this4.payInvoice();
      yield _this4.backTo();
    })();
  }

  backTo() {
    this.rout.navigate(['tabs/cart']);
  }

  payInvoice() {
    if (this.validateBalance() == false) {
      this.presentToast('رصيد المحفظة غير كافي ', 'danger');
    } else {
      this.presentLoadingWithOptions("جاري معالجة طلبك ..");
      let details = "سداد فاتورة رقم " + " " + this.orderId;
      let fromAccount = this.USER_INFO._id;
      let toAccount = 310000205349900001; // رقم حساب الشركة

      let fromAccountTitle = "حساب محفظة : " + this.USER_INFO.firstName;
      let toAccountTitle = "شركة زوودها";
      let comment = "سداد فاتورة رقم " + " " + this.orderId + "من مزاد : " + this.order.auctions[0].title + "," + "رقم: " + this.order.auctions[0]._id;
      this.trasaction = {
        _id: "",
        orderId: this.order._id,
        auctId: this.order.auctId,
        userId: this.USER_INFO._id,
        currentStatus: 0,
        typee: 1,
        pay: this.higtPayedPrie,
        details: details,
        comment: comment,
        fromAccount: fromAccount,
        toAccount: toAccount,
        fromAccountTitle: fromAccountTitle,
        toAccountTitle: toAccountTitle
      };
      this.api.createTransaction(this.trasaction).subscribe(data => {
        console.log(data);
        this.presentToast('تم سداد الفاتورة بنجاح', 'success');
      }, err => {
        console.log(err);
      }, () => {});
    }
  }

  pickProduct() {}

  closeModal() {
    var _this5 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this5.modalController.dismiss('data');
    })();
  }

  presentLoadingWithOptions(msg) {
    var _this6 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this6.loadingController.create({
        spinner: 'bubbles',
        mode: 'ios',
        duration: 5000,
        message: msg,
        translucent: true,
        // cssClass: 'custom-class custom-loading',
        backdropDismiss: false
      });
      yield loading.present();
      const {
        role,
        data
      } = yield loading.onDidDismiss();
      console.log('Loading dismissed with role:', role);
    })();
  }

  presentToast(msg, color) {
    var _this7 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this7.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  }

};

OrderDetailsPage.ctorParameters = () => [{
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_4__.SocketServiceService
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_4__.SocketServiceService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute
}, {
  type: _ionic_storage__WEBPACK_IMPORTED_MODULE_3__.Storage
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ActionSheetController
}, {
  type: _angular_common__WEBPACK_IMPORTED_MODULE_7__.DatePipe
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController
}];

OrderDetailsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-order-details',
  template: _order_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_order_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], OrderDetailsPage);


/***/ }),

/***/ 5405:
/*!******************************************************************!*\
  !*** ./src/app/order-details/order-details.page.scss?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = ".mgt10 {\n  margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyLWRldGFpbHMucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFxodXNhbSUyMHByb2pcXHpvb2RvaGFTZFxcc3JjXFxhcHBcXG9yZGVyLWRldGFpbHNcXG9yZGVyLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQUE7QUNDSiIsImZpbGUiOiJvcmRlci1kZXRhaWxzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tZ3QxMHtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuIiwiLm1ndDEwIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn0iXX0= */";

/***/ }),

/***/ 6846:
/*!******************************************************************!*\
  !*** ./src/app/order-details/order-details.page.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar dir=\"rtl\">\n    <ion-buttons slot=\"end\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title> تفاصيل الطلب </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <!-- <ion-grid *ngIf=\"order\"> \n    <ion-row > \n      <ion-col size=\"12\" class=\"radus5 borderlight w100 ion-margin-top \">\n        <ion-grid class=\"ion-no-padding\" dir=\"rtl\"> \n          <ion-row  >\n            <ion-item class=\"w100\" lines=\"none\"> \n                \n                <ion-card-title>\n                 <ion-icon name=\"list-outline\" color=\"primary\"></ion-icon> \n                  المنتجات\n                </ion-card-title>\n               \n            </ion-item>\n          </ion-row>\n           \n          <ion-row  >\n            <ion-col size=\"12\" > \n              <ion-item>\n                <ion-thumbnail slot=\"start\"><ion-img class=\"radus5 img\" [src]=\"order.auctions[0].imgs[0]\"></ion-img></ion-thumbnail>  \n                <ion-grid   dir =\"rtl\" class=\"ion-no-padding\">\n                  <ion-row class=\"ion-margin-top ion-padding-start\">\n                    <ion-col size=\"8\">\n                      <ion-label > \n                        {{order.auctions[0].title}}\n                     </ion-label>\n                    </ion-col>\n                  </ion-row>\n                \n                  <ion-row  class=\"ion-margin-top ion-padding-start\">\n                    <ion-label> \n                      <ion-note color=\"primary\"><b>سعر المنتج :</b>  </ion-note>\n                      <ion-note>  {{order.higtPayedPrie}}</ion-note>\n                      <ion-note>  ج.س</ion-note>\n                    </ion-label>\n                  </ion-row>\n                </ion-grid>\n              </ion-item> \n              </ion-col>\n            \n          \n          </ion-row> \n           \n          </ion-grid>\n      </ion-col> \n    </ion-row>\n  </ion-grid> -->\n  <ion-grid *ngIf=\"errorLoad == true\" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n</ion-grid>\n\n\n<ion-grid *ngIf=\"!order && errorLoad == false\"  class=\"custGrid\"> \n  <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n    <ion-col size=\"12\" class=\"ion-text-center\">\n      <!-- *ngIf=\"spinner == true\" -->\n      <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n    </ion-col>\n    <ion-col size=\"12\">\n      <!-- *ngIf=\"spinner == true\" --> \n    </ion-col>\n  </ion-row> \n</ion-grid>\n \n  <ion-grid class=\"ion-no-margin  ion-no-padding\"  dir=\"rtl\" *ngIf=\"order\">\n    <ion-row class=\"ion-no-padding\"> \n      <ion-card class=\"w100\"> \n        <ion-card-header>  \n            <ion-card-title>\n             <ion-icon name=\"pricetags-outline\" color=\"primary\"></ion-icon> \n              ملخص الطلب\n            </ion-card-title>\n          </ion-card-header>\n          <ion-grid class=\"ion-no-margin  ion-no-padding ion-padding-bottom\" dir=\"rtl\">\n            <ion-row class=\"ion-no-margin  ion-no-padding\">\n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item lines=\"none\"> \n                    <ion-label> <ion-note color=\"primary\"><b>    رقم الطلب: </b>  </ion-note>  </ion-label>\n                    <ion-label slot=\"end\">\n                      <ion-note>  {{order._id.substring(0,6)}} </ion-note> \n                    </ion-label>\n                  </ion-item>\n              </ion-col>\n               <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item lines=\"none\"> \n                    <ion-label> <ion-note color=\"primary\"><b>    رقم المزاد: </b>  </ion-note>  </ion-label>\n                    <ion-label slot=\"end\">\n                      <ion-note>  {{order.auctions[0]._id.substring(0,6)}} </ion-note> \n                    </ion-label>\n                  </ion-item>\n              </ion-col>\n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item lines=\"none\"> \n                    <ion-label> <ion-note color=\"primary\"><b>   حالة الطلب :</b>  </ion-note>  </ion-label>\n                    <ion-label slot=\"end\">\n                      <ion-note *ngIf =\"order.currentStatus == 0\"> قيد المعالجة</ion-note>\n                      <ion-note *ngIf =\"order.currentStatus == 1\">  تم الدفع  </ion-note>\n                      <ion-note *ngIf =\"order.currentStatus == 2\">  تم الإستلام  </ion-note>\n                      <ion-note *ngIf =\"order.currentStatus == 3\">  تم الإلغاء  </ion-note>\n                    </ion-label>\n                  </ion-item>\n              </ion-col>  \n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item lines=\"none\"> \n                    <ion-label> <ion-note color=\"primary\"><b>    المنتج: </b>  </ion-note>  </ion-label>\n                    <ion-label slot=\"end\">\n                      <ion-note>  {{order.auctions[0].title}} </ion-note> \n                    </ion-label>\n                  </ion-item>\n              </ion-col> \n                <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item lines=\"none\"> \n                    <ion-label> <ion-note color=\"primary\"><b>    العدد: </b>  </ion-note>  </ion-label>\n                    <ion-label slot=\"end\">\n                      <ion-note>  1 </ion-note>\n                      <ion-note>  قطعة </ion-note>\n                    </ion-label>\n                  </ion-item>\n              </ion-col> \n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item lines=\"none\"> \n                    <ion-label> <ion-note color=\"primary\"><b>سعر المنتج :</b>  </ion-note>  </ion-label>\n                    <ion-label slot=\"end\">\n                      <ion-note>  {{higtPayedPrie}}</ion-note>\n                      <ion-note>  ج.س</ion-note>\n                    </ion-label>\n                  </ion-item>\n              </ion-col> \n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item>  \n                  <ion-label>\n                    <ion-text color=\"primary\"><b> العربون </b> </ion-text>\n                  </ion-label>\n                  <ion-label slot=\"end\">\n                    \n                    <ion-text> - {{order['auctions'][0].deposit}} </ion-text>\n                    <ion-text>  ج.س </ion-text>\n                  </ion-label>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\" class=\"ion-text-center\" *ngIf=\"order.delivary\">\n                <ion-item lines=\"none\"> \n                    <ion-label><ion-text color=\"primary\"><b> التوصيل</b> </ion-text>  </ion-label>\n                    <ion-label slot=\"end\">\n                      <ion-note>  {{order.delivary}}</ion-note>\n                      <ion-note>  ج.س</ion-note>\n                    </ion-label>\n                  </ion-item>\n              </ion-col>\n              <ion-col size=\"12\" class=\"ion-text-center\" *ngIf=\"order.discount\">\n                <ion-item>  \n                  <ion-label>\n                    <ion-text color=\"primary\"><b> تخفيض </b> </ion-text>\n                  </ion-label>\n                  <ion-label slot=\"end\">\n                    <ion-text> - </ion-text>\n                    <ion-text> {{order.discount}} </ion-text>\n                    <ion-text>  ج.س </ion-text>\n                  </ion-label>\n                </ion-item>\n              </ion-col>\n\n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item lines=\"none\"> \n                  <ion-label>\n                    <ion-text color=\"primary\"><b>صافي المبلغ المطلوب </b> </ion-text>\n                  </ion-label>\n                  <ion-label slot=\"end\">\n                    <ion-text>  {{ getNetTot() }}  </ion-text>\n                    <ion-text> ج.س</ion-text>\n                  </ion-label>\n                </ion-item>\n              </ion-col>\n            </ion-row>\n          </ion-grid> \n      </ion-card> \n      <!-- <ion-card class=\"w100\">\n        <ion-card-header>\n          <ion-card-title>\n            <ion-icon name=\"bookmark-outline\" color=\"primary\"></ion-icon> \n           تنبيه\n          </ion-card-title> \n        </ion-card-header>\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\" >\n             <ion-card-content>\n              <ion-icon name=\"pin\" color=\"primary\"></ion-icon>\n              <ion-label>\n                يجب سداد هذه الفاتورة قبل تاريخ <ion-text>13-3-2020</ion-text>\n              </ion-label>\n              <ion-label>\n               في حالة عدم السداد قبل التاريخ المحدد اعلاه , تعتبر هذ الفاتورة لاغية ولايمكن للمستخدم استرجاع اي مبلغ تم دفعة مقدما \n              </ion-label>\n            </ion-card-content> \n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </ion-card>  -->\n    </ion-row>\n  </ion-grid>\n</ion-content>\n<ion-footer class=\"footer\" *ngIf=\"order\">\n   <!-- *ngIf=\"order.currentStatus != 3\" -->\n   <!-- *ngIf=\"order.currentStatus == 0\" -->\n  <ion-grid dir=\"rtl\"  *ngIf=\"order.currentStatus == 0\"> \n    <ion-row  >\n      <ion-col size=\"6\">\n       <ion-button expand=\"block\" type=\"outline\" (click)=\"showActionPay()\"> \n        <h5>دفــع </h5>\n       </ion-button>\n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <h4 class=\"ion-no-margin\">\n        <ion-text color=\"primary\">\n            المبلغ\n        </ion-text> <br>  \n        <ion-text> {{getNetTot()}} </ion-text>\n         <ion-text> ج.س</ion-text>\n       </h4>  \n      </ion-col> \n    </ion-row>\n\n    <!-- <ion-row *ngIf=\"order.currentStatus == 1\" class=\"ion-justify-content-center\">\n      <ion-col size=\"6\">\n       <ion-button expand=\"block\" type=\"outline\" (click)=\"presentActionSheetPick()\"> \n        <h5>إستلام </h5>\n       </ion-button>\n      </ion-col> \n    </ion-row> -->\n  </ion-grid>\n</ion-footer>";

/***/ })

}]);
//# sourceMappingURL=src_app_order-details_order-details_module_ts.js.map