"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_forget-password_forget-password_module_ts"],{

/***/ 8733:
/*!*******************************************************************!*\
  !*** ./src/app/forget-password/forget-password-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgetPasswordPageRoutingModule": () => (/* binding */ ForgetPasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _forget_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forget-password.page */ 3694);




const routes = [
    {
        path: '',
        component: _forget_password_page__WEBPACK_IMPORTED_MODULE_0__.ForgetPasswordPage
    }
];
let ForgetPasswordPageRoutingModule = class ForgetPasswordPageRoutingModule {
};
ForgetPasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ForgetPasswordPageRoutingModule);



/***/ }),

/***/ 4845:
/*!***********************************************************!*\
  !*** ./src/app/forget-password/forget-password.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgetPasswordPageModule": () => (/* binding */ ForgetPasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _forget_password_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forget-password-routing.module */ 8733);
/* harmony import */ var _forget_password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forget-password.page */ 3694);







let ForgetPasswordPageModule = class ForgetPasswordPageModule {
};
ForgetPasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _forget_password_routing_module__WEBPACK_IMPORTED_MODULE_0__.ForgetPasswordPageRoutingModule
        ],
        declarations: [_forget_password_page__WEBPACK_IMPORTED_MODULE_1__.ForgetPasswordPage]
    })
], ForgetPasswordPageModule);



/***/ }),

/***/ 3694:
/*!*********************************************************!*\
  !*** ./src/app/forget-password/forget-password.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgetPasswordPage": () => (/* binding */ ForgetPasswordPage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _forget_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forget-password.page.html?ngResource */ 3285);
/* harmony import */ var _forget_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./forget-password.page.scss?ngResource */ 715);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/socket-service.service */ 905);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ 190);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);










let ForgetPasswordPage = class ForgetPasswordPage {
  constructor(formBuilder, toast, route, storage, rout, api) {
    this.formBuilder = formBuilder;
    this.toast = toast;
    this.route = route;
    this.storage = storage;
    this.rout = rout;
    this.api = api;
    this.style = 'style2';
    this.spinner = false;
    this.isSubmitted = false;
    this.ionicForm = this.formBuilder.group({
      email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]]
    });
  }

  ngOnInit() {
    this.user = {
      email: ""
    };
  }

  sendMail() {
    if (this.validate() == true) {
      this.spinner = true;
      this.api.sendMail(this.user).subscribe(data => {
        console.log('user was created', data);
        let res = data;
        console.log('email was sent', res['digit']);
        let navigationExtras = {
          queryParams: {
            digit: JSON.stringify(res['digit']),
            user_info: JSON.stringify(res['user'])
          }
        };
        this.rout.navigate(['virefy-rest'], navigationExtras);
      }, err => {
        console.log(err);
        this.spinner = false;
        this.handleError(err.error.error);
      }, () => {
        this.spinner = false;
      });
    }
  }

  handleError(msg) {
    if (msg == "email not found") {
      this.presentToast("البريد ليس موجود ", 'danger');
      return false;
    } else if (!msg) {
      this.presentToast('حدث خطأ ما ,حاول مرة اخري', 'danger');
      return false;
    } else {
      this.presentToast("حدث خطأ ما ,الرجاء المحاولة لاحقا    ", 'danger');
      return false;
    }
  }

  get errorControl() {
    return this.ionicForm.controls;
  }

  presentToast(msg, color) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  }

  validate() {
    this.isSubmitted = true;

    if (this.ionicForm.valid == false) {
      console.log('Please provide all the required values!');
      return false;
    } else {
      return true;
    }
  }

  newPassword() {
    this.rout.navigate(['new-password']);
  }

};

ForgetPasswordPage.ctorParameters = () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute
}, {
  type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__.Storage
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService
}];

ForgetPasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-forget-password',
  template: _forget_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_forget_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ForgetPasswordPage);


/***/ }),

/***/ 715:
/*!**********************************************************************!*\
  !*** ./src/app/forget-password/forget-password.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = ".custInput {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-dark);\n  background-color: var(--ion-color-primary-contrast);\n  border-radius: 2rem;\n}\n\n.custItem {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-dark);\n  background-color: var(--ion-color-primary-contrast);\n  border-radius: 2rem;\n}\n\n.mgt10 {\n  margin-top: 10px;\n}\n\n.roundedGrid {\n  border-radius: 50px;\n  /* border-bottom-left-radius: 50px; */\n  /* border-bottom-right-radius: 50px; */\n  /* border-top-left-radius: 50px; */\n  /* border-top-right-radius: 50px; */\n  padding-left: 10px;\n  padding-right: 10px;\n}\n\n.custGridStyl2 {\n  margin-top: 10%;\n  display: grid;\n  align-items: center;\n}\n\n.header-md::after {\n  background-image: none;\n}\n\n.bordernon {\n  border: none;\n}\n\n.newHeight {\n  height: 375px;\n}\n\n.custH {\n  border-bottom-style: solid;\n  padding: 10px;\n  width: 120px;\n  text-align: center;\n}\n\n.custGrid {\n  position: relative;\n  top: -50%;\n}\n\n.footer-md::before {\n  background-image: none;\n}\n\n.borderNone {\n  border-radius: 0px;\n}\n\n.padd13 {\n  padding-top: 13%;\n}\n\n.padd1 {\n  padding: 1%;\n}\n\n.logoSvg {\n  position: absolute;\n  top: 30%;\n  left: 50%;\n  margin-right: 50%;\n  transform: translate(-50%, -50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvcmdldC1wYXNzd29yZC5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXGh1c2FtJTIwcHJvalxcem9vZG9oYVNkXFxzcmNcXGFwcFxcZm9yZ2V0LXBhc3N3b3JkXFxmb3JnZXQtcGFzc3dvcmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1DQUFBO0VBQ0EsbURBQUE7RUFDQSxtQkFBQTtBQ0NKOztBREVBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1DQUFBO0VBQ0EsbURBQUE7RUFDQSxtQkFBQTtBQ0NKOztBRENBO0VBQ0ksZ0JBQUE7QUNFSjs7QURDQTtFQUNJLG1CQUFBO0VBQ0EscUNBQUE7RUFDQSxzQ0FBQTtFQUNBLGtDQUFBO0VBQ0EsbUNBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDRUo7O0FERUE7RUFFSSxlQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FDQUo7O0FER0E7RUFDSSxzQkFBQTtBQ0FKOztBREVBO0VBQ0ksWUFBQTtBQ0NKOztBREVBO0VBQ0ksYUFBQTtBQ0NKOztBRENBO0VBQ0ksMEJBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FDRUo7O0FEQUE7RUFDSSxrQkFBQTtFQUNBLFNBQUE7QUNHSjs7QUREQTtFQUNJLHNCQUFBO0FDSUo7O0FERkE7RUFDSSxrQkFBQTtBQ0tKOztBREhBO0VBQ0ksZ0JBQUE7QUNNSjs7QURKQTtFQUNJLFdBQUE7QUNPSjs7QURMQTtFQUNJLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtFQUNBLGdDQUFBO0FDUUoiLCJmaWxlIjoiZm9yZ2V0LXBhc3N3b3JkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jdXN0SW5wdXR7XHJcbiAgICBib3JkZXItc3R5bGU6IHNvbGlkO1xyXG4gICAgYm9yZGVyLXdpZHRoOiAwLjVweDtcclxuICAgIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMnJlbTtcclxufVxyXG5cclxuLmN1c3RJdGVte1xyXG4gICAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci13aWR0aDogMC41cHg7XHJcbiAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDJyZW07XHJcbn1cclxuLm1ndDEwe1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG5cclxuLnJvdW5kZWRHcmlkeyBcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbiAgICAvKiBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1MHB4OyAqL1xyXG4gICAgLyogYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDUwcHg7ICovXHJcbiAgICAvKiBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA1MHB4OyAqL1xyXG4gICAgLyogYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDUwcHg7ICovXHJcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xyXG4gXHJcbiAgICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XHJcbiAgIH1cclxuLmN1c3RHcmlkU3R5bDJ7XHJcbiAgICAvLyBoZWlnaHQ6IDEwMCU7XHJcbiAgICBtYXJnaW4tdG9wOiAxMCU7XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLmhlYWRlci1tZDo6YWZ0ZXIge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTpub25lO1xyXG59XHJcbi5ib3JkZXJub257XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbn1cclxuXHJcbi5uZXdIZWlnaHR7XHJcbiAgICBoZWlnaHQ6IDM3NXB4O1xyXG59XHJcbi5jdXN0SHtcclxuICAgIGJvcmRlci1ib3R0b20tc3R5bGU6IHNvbGlkO1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIHdpZHRoOiAxMjBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG4uY3VzdEdyaWR7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB0b3A6IC01MCU7XHJcbn1cclxuLmZvb3Rlci1tZDo6YmVmb3Jle1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogIG5vbmU7XHJcbn1cclxuLmJvcmRlck5vbmV7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwcHg7XHJcbn1cclxuLnBhZGQxM3tcclxuICAgIHBhZGRpbmctdG9wOjEzJVxyXG59XHJcbi5wYWRkMXtcclxuICAgIHBhZGRpbmc6IDElO1xyXG59XHJcbi5sb2dvU3Zne1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAzMCU7XHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG59IiwiLmN1c3RJbnB1dCB7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGJvcmRlci13aWR0aDogMC41cHg7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XG4gIGJvcmRlci1yYWRpdXM6IDJyZW07XG59XG5cbi5jdXN0SXRlbSB7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGJvcmRlci13aWR0aDogMC41cHg7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XG4gIGJvcmRlci1yYWRpdXM6IDJyZW07XG59XG5cbi5tZ3QxMCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5yb3VuZGVkR3JpZCB7XG4gIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4gIC8qIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDUwcHg7ICovXG4gIC8qIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1MHB4OyAqL1xuICAvKiBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA1MHB4OyAqL1xuICAvKiBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNTBweDsgKi9cbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xufVxuXG4uY3VzdEdyaWRTdHlsMiB7XG4gIG1hcmdpbi10b3A6IDEwJTtcbiAgZGlzcGxheTogZ3JpZDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmhlYWRlci1tZDo6YWZ0ZXIge1xuICBiYWNrZ3JvdW5kLWltYWdlOiBub25lO1xufVxuXG4uYm9yZGVybm9uIHtcbiAgYm9yZGVyOiBub25lO1xufVxuXG4ubmV3SGVpZ2h0IHtcbiAgaGVpZ2h0OiAzNzVweDtcbn1cblxuLmN1c3RIIHtcbiAgYm9yZGVyLWJvdHRvbS1zdHlsZTogc29saWQ7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIHdpZHRoOiAxMjBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uY3VzdEdyaWQge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRvcDogLTUwJTtcbn1cblxuLmZvb3Rlci1tZDo6YmVmb3JlIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn1cblxuLmJvcmRlck5vbmUge1xuICBib3JkZXItcmFkaXVzOiAwcHg7XG59XG5cbi5wYWRkMTMge1xuICBwYWRkaW5nLXRvcDogMTMlO1xufVxuXG4ucGFkZDEge1xuICBwYWRkaW5nOiAxJTtcbn1cblxuLmxvZ29Tdmcge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMzAlO1xuICBsZWZ0OiA1MCU7XG4gIG1hcmdpbi1yaWdodDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbn0iXX0= */";

/***/ }),

/***/ 3285:
/*!**********************************************************************!*\
  !*** ./src/app/forget-password/forget-password.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header>\n  <ion-toolbar color=\"primary\" dir=\"rtl\">\n    <ion-buttons slot=\"start\">\n     <ion-button fill=\"clear\" > \n     </ion-button>\n    </ion-buttons>\n     <ion-title>إستعادة كلمة المرور</ion-title>\n   </ion-toolbar>\n</ion-header> -->\n \n<ion-content dir=\"rtl\"  *ngIf=\" style=='style1'\">\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col size=\"12\" class=\"head3 newHeight ion-text-center \">  \n        <svg class=\"logoSvg\" width=\"119\" height=\"119\" viewBox=\"0 0 119 119\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <circle opacity=\"0.27\" cx=\"59.5\" cy=\"59.5\" r=\"59.5\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M87.5908 52.4474C88.1575 53.3924 88.3464 54.5259 88.3464 55.6598V81.925C88.3464 86.0818 84.9451 89.4831 80.9771 89.4831H37.3273C33.3593 89.4831 29.958 86.0818 29.958 81.925V55.6598C29.958 54.5259 30.1469 53.3924 30.7137 52.4474L52.8219 70.777C56.2231 73.6115 61.8918 73.6115 65.482 70.777L87.5902 52.4474H87.5908Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M40.1623 55.6605L32.9819 49.6136L55.0901 31.4732C57.1686 29.5836 60.9476 29.3947 63.2154 31.2842L85.3236 49.6139L78.1433 55.6608V51.1256C78.1433 48.8583 76.4426 47.1576 74.3641 47.1576H43.942C41.8635 47.1576 40.1628 48.8583 40.1628 51.1256V55.6608L40.1623 55.6605Z\" fill=\"white\"/>\n          <path d=\"M49.4223 53.2042C48.0995 53.2042 48.0995 51.3147 49.4223 51.3147H68.8849C70.2077 51.3147 70.2077 53.2042 68.8849 53.2042H49.4223Z\" fill=\"white\"/>\n          <path d=\"M49.4223 60.9505C48.0995 60.9505 48.0995 59.061 49.4223 59.061H68.8849C70.2077 59.061 70.2077 60.9505 68.8849 60.9505H49.4223Z\" fill=\"white\"/>\n          <path d=\"M49.4223 57.172C48.0995 57.172 48.0995 55.2825 49.4223 55.2825H68.8849C70.2077 55.2825 70.2077 57.172 68.8849 57.172H49.4223Z\" fill=\"white\"/>\n        </svg>\n     </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid class=\"custGrid ion-margin-bottom\">\n     <ion-row class=\"ion-justify-content-center\">\n    <ion-col size=\"10\" >\n     <ion-card class=\"bordernon w100\" >\n      <ion-card-header>\n        <ion-card-title>\n         <h3 ><b>هل نسيت كلمة السر </b> ؟</h3> \n        </ion-card-title>\n        <ion-card-subtitle>\n          الرجاء ادخال بريدك الإلكتروني إعادة تعيين كلمة السر\n        </ion-card-subtitle>\n      </ion-card-header>\n      <ion-grid  >\n        <form [formGroup]=\"ionicForm\" (ngSubmit)=\"sendMail()\" novalidate> \n          <ion-list class=\"w100\"  dir=\"rtl\">\n            <ion-label position=\"floating\">البريد الإلكتروني: </ion-label>    \n            <ion-item>\n             \n              <ion-input formControlName=\"email\" [(ngModel)]=\"user.email\" ></ion-input> \n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.email.errors?.required\"> الحقل مطلوب </ion-note> \n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.email.errors?.pattern\">    خطأ في صيغة البريد  </ion-note>\n            </ion-item>\n            \n         \n             \n             <!-- <ion-item>\n              <ion-label>كلمة المرور</ion-label> \n              <ion-input formControlName=\"password\" [(ngModel)]=\"USER_INFO.password\" [type]=\"passType\"></ion-input>\n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.required\"> الحقل مطلوب </ion-note> \n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.length\"> مكون من 5 رموز علي الأقل </ion-note> \n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.pattern\"> يحوي حرف كبير وصغير ورمز ورقم</ion-note> \n              <ion-button  fill = \"clear\" (click)=\"showPass('pass')\">\n                <ion-icon  *ngIf=\"show == false\"  slot=\"end\"   name=\"eye-off-outline\" ></ion-icon>\n                <ion-icon *ngIf=\"show == true\"   slot=\"end\"   name=\"eye-outline\" ></ion-icon>\n               </ion-button>\n            </ion-item>\n            <ion-item>\n              <ion-label>تأكيد كلمة المرور</ion-label> \n              <ion-input formControlName=\"confirmPass\" [(ngModel)]=\"confirmPass\"  [type]=\"confType\"></ion-input>\n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && USER_INFO.password.length > 0 && USER_INFO.password != confirmPass\">  كلمة المرور غير مطابقة  </ion-note> \n              \n             <ion-button  fill = \"clear\" (click)=\"showPass('confirm')\">\n              <ion-icon  *ngIf=\"showConf == false\"  slot=\"end\"   name=\"eye-off-outline\" ></ion-icon>\n              <ion-icon *ngIf=\"showConf == true\"   slot=\"end\"   name=\"eye-outline\" ></ion-icon>\n             </ion-button>\n            </ion-item>   -->\n\n           \n          </ion-list>\n      \n          <ion-row class=\"ion-margin\" dir=\"rtl\" > \n            <ion-col size=\"12\">\n              <ion-item color=\"primary\" [disabled]=\"spinner == true\" button (click)=\"sendMail()\">\n                <ion-label class=\"ion-text-center\"> \n                  <ion-text >التالي</ion-text>\n                </ion-label>\n                <ion-spinner name=\"lines\" color=\"light\" *ngIf=\"spinner == true\"></ion-spinner>  \n              </ion-item>\n            </ion-col>\n          </ion-row>\n\n        \n           \n          \n        </form>\n      </ion-grid>\n      </ion-card>\n    </ion-col>\n    </ion-row>\n  </ion-grid>\n \n</ion-content>\n\n<ion-content dir=\"rtl\"  *ngIf=\" style=='style2'\">\n  \n  <ion-grid class=\"custGridStyl2 ion-margin-bottom\">\n\n    <ion-row>\n      <ion-col size=\"12\" class=\" ion-text-center \">  \n        <svg  width=\"119\" height=\"119\" viewBox=\"0 0 119 119\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <circle opacity=\"0.27\" cx=\"59.5\" cy=\"59.5\" r=\"59.5\" fill=\"black\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M87.5908 52.4474C88.1575 53.3924 88.3464 54.5259 88.3464 55.6598V81.925C88.3464 86.0818 84.9451 89.4831 80.9771 89.4831H37.3273C33.3593 89.4831 29.958 86.0818 29.958 81.925V55.6598C29.958 54.5259 30.1469 53.3924 30.7137 52.4474L52.8219 70.777C56.2231 73.6115 61.8918 73.6115 65.482 70.777L87.5902 52.4474H87.5908Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M40.1623 55.6605L32.9819 49.6136L55.0901 31.4732C57.1686 29.5836 60.9476 29.3947 63.2154 31.2842L85.3236 49.6139L78.1433 55.6608V51.1256C78.1433 48.8583 76.4426 47.1576 74.3641 47.1576H43.942C41.8635 47.1576 40.1628 48.8583 40.1628 51.1256V55.6608L40.1623 55.6605Z\" fill=\"white\"/>\n          <path d=\"M49.4223 53.2042C48.0995 53.2042 48.0995 51.3147 49.4223 51.3147H68.8849C70.2077 51.3147 70.2077 53.2042 68.8849 53.2042H49.4223Z\" fill=\"white\"/>\n          <path d=\"M49.4223 60.9505C48.0995 60.9505 48.0995 59.061 49.4223 59.061H68.8849C70.2077 59.061 70.2077 60.9505 68.8849 60.9505H49.4223Z\" fill=\"white\"/>\n          <path d=\"M49.4223 57.172C48.0995 57.172 48.0995 55.2825 49.4223 55.2825H68.8849C70.2077 55.2825 70.2077 57.172 68.8849 57.172H49.4223Z\" fill=\"white\"/>\n        </svg>\n     </ion-col>\n    </ion-row>\n     <ion-row class=\"ion-justify-content-center\">\n    <ion-col size=\"11\" >\n     <ion-card class=\" roundedGrid w100\" >\n      <ion-card-header>\n        <ion-card-title>\n         <h3 ><b>هل نسيت كلمة السر </b> ؟</h3> \n        </ion-card-title>\n        <ion-card-subtitle>\n          الرجاء ادخال بريدك الإلكتروني إعادة تعيين كلمة السر\n        </ion-card-subtitle>\n      </ion-card-header>\n      <ion-grid  >\n        <form [formGroup]=\"ionicForm\" (ngSubmit)=\"sendMail()\" novalidate> \n          <ion-list class=\"w100\"  dir=\"rtl\">\n            <!-- <ion-label position=\"floating\">البريد الإلكتروني: </ion-label>     -->\n            <ion-item class=\"custInput\">\n             \n              <ion-input placeholder=\"البريد الإلكتروني\" formControlName=\"email\" [(ngModel)]=\"user.email\" ></ion-input> \n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.email.errors?.required\"> الحقل مطلوب </ion-note> \n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.email.errors?.pattern\">    خطأ في صيغة البريد  </ion-note>\n            </ion-item>\n            \n         \n             \n             <!-- <ion-item>\n              <ion-label>كلمة المرور</ion-label> \n              <ion-input formControlName=\"password\" [(ngModel)]=\"USER_INFO.password\" [type]=\"passType\"></ion-input>\n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.required\"> الحقل مطلوب </ion-note> \n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.length\"> مكون من 5 رموز علي الأقل </ion-note> \n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.pattern\"> يحوي حرف كبير وصغير ورمز ورقم</ion-note> \n              <ion-button  fill = \"clear\" (click)=\"showPass('pass')\">\n                <ion-icon  *ngIf=\"show == false\"  slot=\"end\"   name=\"eye-off-outline\" ></ion-icon>\n                <ion-icon *ngIf=\"show == true\"   slot=\"end\"   name=\"eye-outline\" ></ion-icon>\n               </ion-button>\n            </ion-item>\n            <ion-item>\n              <ion-label>تأكيد كلمة المرور</ion-label> \n              <ion-input formControlName=\"confirmPass\" [(ngModel)]=\"confirmPass\"  [type]=\"confType\"></ion-input>\n              <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && USER_INFO.password.length > 0 && USER_INFO.password != confirmPass\">  كلمة المرور غير مطابقة  </ion-note> \n              \n             <ion-button  fill = \"clear\" (click)=\"showPass('confirm')\">\n              <ion-icon  *ngIf=\"showConf == false\"  slot=\"end\"   name=\"eye-off-outline\" ></ion-icon>\n              <ion-icon *ngIf=\"showConf == true\"   slot=\"end\"   name=\"eye-outline\" ></ion-icon>\n             </ion-button>\n            </ion-item>   -->\n\n           \n          </ion-list>\n      \n          <ion-row class=\"ion-margin\" dir=\"rtl\" > \n            <ion-col size=\"12\">\n              <ion-item class=\"custItem\" color=\"dark\"  [disabled]=\"spinner == true\" button (click)=\"sendMail()\">\n                <ion-label class=\"ion-text-center\"> \n                  <ion-text >التالي</ion-text>\n                </ion-label>\n                <ion-spinner name=\"lines\" color=\"light\" *ngIf=\"spinner == true\"></ion-spinner>  \n              </ion-item>\n            </ion-col>\n          </ion-row>\n\n        \n           \n          \n        </form>\n      </ion-grid>\n      </ion-card>\n    </ion-col>\n    </ion-row>\n  </ion-grid>\n \n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_forget-password_forget-password_module_ts.js.map