"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_mzad-details_mzad-details_module_ts"],{

/***/ 5071:
/*!*************************************************************!*\
  !*** ./src/app/mzad-details/mzad-details-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MzadDetailsPageRoutingModule": () => (/* binding */ MzadDetailsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _mzad_details_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mzad-details.page */ 1374);




const routes = [
    {
        path: '',
        component: _mzad_details_page__WEBPACK_IMPORTED_MODULE_0__.MzadDetailsPage
    }
];
let MzadDetailsPageRoutingModule = class MzadDetailsPageRoutingModule {
};
MzadDetailsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MzadDetailsPageRoutingModule);



/***/ }),

/***/ 3702:
/*!*****************************************************!*\
  !*** ./src/app/mzad-details/mzad-details.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MzadDetailsPageModule": () => (/* binding */ MzadDetailsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _mzad_details_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mzad-details-routing.module */ 5071);
/* harmony import */ var _mzad_details_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mzad-details.page */ 1374);







let MzadDetailsPageModule = class MzadDetailsPageModule {
};
MzadDetailsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _mzad_details_routing_module__WEBPACK_IMPORTED_MODULE_0__.MzadDetailsPageRoutingModule
        ],
        declarations: [_mzad_details_page__WEBPACK_IMPORTED_MODULE_1__.MzadDetailsPage]
    })
], MzadDetailsPageModule);



/***/ }),

/***/ 1374:
/*!***************************************************!*\
  !*** ./src/app/mzad-details/mzad-details.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MzadDetailsPage": () => (/* binding */ MzadDetailsPage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _mzad_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mzad-details.page.html?ngResource */ 1486);
/* harmony import */ var _mzad_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./mzad-details.page.scss?ngResource */ 5675);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs */ 2378);
/* harmony import */ var _mzad_subescribe_mzad_subescribe_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../mzad-subescribe/mzad-subescribe.page */ 4937);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ 190);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/socket-service.service */ 905);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! moment */ 6908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! moment-timezone */ 2469);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(moment_timezone__WEBPACK_IMPORTED_MODULE_7__);














let MzadDetailsPage = class MzadDetailsPage {
  constructor(api, socket, route, storage, loadingController, toast, actionSheetCtl, datePipe, rout, modalController) {
    this.api = api;
    this.socket = socket;
    this.route = route;
    this.storage = storage;
    this.loadingController = loadingController;
    this.toast = toast;
    this.actionSheetCtl = actionSheetCtl;
    this.datePipe = datePipe;
    this.rout = rout;
    this.modalController = modalController;
    this.style = 'style2';
    this.mzad = {
      "_id": "06e6f08e85e942d290ec642c14614637",
      "title": "iphone pro",
      "shortDescr": "iuhiuygi",
      "descr": "vhghvi87797",
      "imgs": ["jhohih"],
      "start": {
        "$date": {
          "$numberLong": "1668202503976"
        }
      },
      "end": {
        "$date": {
          "$numberLong": "1668202503976"
        }
      },
      "currentStatus": 1,
      "fee": 0,
      "deposit": 0,
      "productPrice": 0,
      "minUsercount": 90,
      "contryCode": "249",
      "terms": [],
      "users": [{
        "userId": "736fc6299c3a4269ace43b7641014af2",
        "status": 1,
        "userName": "boorak"
      }, {
        "userId": "700865bcaa934e5ebe956a2013c33395",
        "status": 1,
        "userName": "hossam"
      }],
      "logs": [// {
        //   "userId": String ,
        //   "time": Date,
        //   "pay" : Number,
        //   "lastHighestPay": Number , //to confirm last payment that happend pefore this one
        //   }
      ],
      "createdAt": {
        "$date": {
          "$numberLong": "1668202503993"
        }
      },
      "updatedAt": {
        "$date": {
          "$numberLong": "1668202503993"
        }
      },
      "__v": 0
    };
    this.errorLoad = false;
    this.showMore = false;
    this.mzd = undefined;
    this.terms = [];
    this.timeLeft = {
      da: "",
      hr: "",
      mn: "",
      sc: ""
    };
  }

  tirmString(string, length) {
    return string.substring(0, length) + '...';
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params && params.id) {
        this.id = JSON.parse(params.id);
        this.storage.get('user_info').then(response => {
          if (response) {
            this.USER_INFO = response.user;
            console.log(this.USER_INFO);
            this.getAuction(this.id);
          }
        });
      }
    });
  }

  reload() {
    this.errorLoad = false;
    this.mzd = undefined;
    this.getAuction(this.id);
  }

  getAuction(id) {
    this.api.getAuction(this.id).subscribe(data => {
      console.log(data);
      let res = data['auction'];
      this.mzd = res;
      console.log('mzzzz', this.mzd);
      this.prepare();
    }, err => {
      this.errorLoad = true;
      console.log(err);
    });
  }

  prepare() {
    this.timeLeft = this.endAfterounter();

    if (this.mzd['currentStatus'] == 1) {
      this.mzd['timeLeft'] = this.startAfterounter();
    } else if (this.mzd['currentStatus'] == 2) {
      //edit here
      this.mzd['timeLeft'] = this.endAfterounter();
    } else if (this.mzd['currentStatus'] == 3) {
      //edit here
      this.mzd['timeLeft'] = this.endSinceAfterounter();
    } // userIn


    let fltuse = [];
    fltuse = this.mzd.users.filter(x => x.userId == this.USER_INFO._id);
    console.log('fltuse', fltuse);

    if (fltuse.length > 0 && this.mzd.currentStatus < 3 && fltuse[0].cancel == 0) {
      this.mzd.userIn = true;
    } else if (fltuse.length > 0 && fltuse[0].cancel == 1) {
      this.mzd.userOut = true;
    } else if (this.mzd.logs.length > 0 && fltuse.length > 0 && this.mzd.currentStatus == 3) {
      // userWin
      let mx = this.mzd.logs.reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0);
      let flt = this.mzd.logs.filter(x => x.pay == mx);
      console.log('userWin', mx, flt);

      if (flt[0].userId == this.USER_INFO._id) {
        this.mzd.userWin = true;
      }
    }

    let du = moment__WEBPACK_IMPORTED_MODULE_6__.duration(moment__WEBPACK_IMPORTED_MODULE_6__(this.mzd['end']).diff(moment__WEBPACK_IMPORTED_MODULE_6__(this.mzd['start'])));
    let hr = "";
    let day = "";
    let con = "";

    if (du.days() > 0) {
      day = du.days().toString() + " يوم";
    }

    if (du.hours() > 0) {
      hr = du.hours().toString() + " ساعة";
    }

    if (du.hours() > 0 && du.hours() > 0) {
      con = " , ";
    }

    this.mzd['duration'] = day + con + hr;
    console.log('length', this.mzd['terms'].length);

    if (this.mzd['terms'].length > 3) {
      this.getTerms('less');
    } else {
      this.getTerms('more');
    }

    console.log(this.mzd);
  }

  viewMoreLess() {
    console.log(this.view);

    if (this.view == 0) {
      this.getTerms('more');
      this.view = 1;
    } else {
      this.getTerms('less');
      this.view = 0;
    }
  }

  getTerms(moreOrLess) {
    let length;

    if (moreOrLess == 'less') {
      length = 3;
    } else if (moreOrLess == 'more') {
      length = this.mzd['terms'].length;
    } else {
      length = this.mzd['terms'].length;
    }

    this.terms = [];

    for (let index = 0; index < length; index++) {
      const element = this.mzd['terms'][index];
      this.terms.push(element);
    }

    this.view = 0;
  }

  endAfterounter() {
    let offset = moment_timezone__WEBPACK_IMPORTED_MODULE_7__().utcOffset();
    let newDate = moment__WEBPACK_IMPORTED_MODULE_6__(this.mzd['end']).add();
    console.log('init', this.mzd['end'], 'sdfs', offset, 'newDate', moment__WEBPACK_IMPORTED_MODULE_6__(newDate).format('YYYY-MM-DDTHH:mm:ss.SSSSZ'));
    return new rxjs__WEBPACK_IMPORTED_MODULE_8__.Observable(observer => {
      setInterval(() => observer.next({
        da: this.memntoEnd(newDate).asDays().toFixed(0).toString(),
        hr: this.memntoEnd(newDate).hours().toString(),
        mn: this.memntoEnd(newDate).minutes().toString(),
        sc: this.memntoEnd(newDate).seconds().toString()
      }), 1000);
    });
  }

  memntoEnd(newDate) {
    return moment__WEBPACK_IMPORTED_MODULE_6__.duration(moment__WEBPACK_IMPORTED_MODULE_6__(newDate).diff(moment__WEBPACK_IMPORTED_MODULE_6__()));
  }

  startAfterounter() {
    let offset = moment_timezone__WEBPACK_IMPORTED_MODULE_7__().utcOffset();
    let newDate = moment__WEBPACK_IMPORTED_MODULE_6__(this.mzd['start']).add();
    console.log(moment__WEBPACK_IMPORTED_MODULE_6__(), 'init', this.mzd['start'], 'sdfs', offset, 'newDate', moment__WEBPACK_IMPORTED_MODULE_6__(newDate).format('YYYY-MM-DDTHH:mm:ss.SSSSZ'));
    return new rxjs__WEBPACK_IMPORTED_MODULE_8__.Observable(observer => {
      setInterval(() => observer.next({
        da: this.memntoStart(newDate).asDays().toFixed(0).toString(),
        hr: this.memntoStart(newDate).hours().toString(),
        mn: this.memntoStart(newDate).minutes().toString(),
        sc: this.memntoStart(newDate).seconds().toString()
      }), 1000);
    });
  }

  memntoStart(newDate) {
    let today = new Date();
    return moment__WEBPACK_IMPORTED_MODULE_6__.duration(moment__WEBPACK_IMPORTED_MODULE_6__(newDate).diff(moment__WEBPACK_IMPORTED_MODULE_6__(today)));
  }

  endSinceAfterounter() {
    let offset = moment_timezone__WEBPACK_IMPORTED_MODULE_7__().utcOffset();
    let newDate = moment__WEBPACK_IMPORTED_MODULE_6__(this.mzd['end']).add();
    console.log(moment__WEBPACK_IMPORTED_MODULE_6__(), 'init', this.mzd['end'], 'sdfs', offset, 'newDate', moment__WEBPACK_IMPORTED_MODULE_6__(newDate).format('YYYY-MM-DDTHH:mm:ss.SSSSZ'));
    return new rxjs__WEBPACK_IMPORTED_MODULE_8__.Observable(observer => {
      setInterval(() => observer.next({
        da: this.memnSinceEnd(newDate).asDays().toFixed(0).toString(),
        hr: this.memnSinceEnd(newDate).hours().toString(),
        mn: this.memnSinceEnd(newDate).minutes().toString(),
        sc: this.memnSinceEnd(newDate).seconds().toString()
      }), 1000);
    });
  }

  memnSinceEnd(newDate) {
    return moment__WEBPACK_IMPORTED_MODULE_6__.duration(moment__WEBPACK_IMPORTED_MODULE_6__().diff(moment__WEBPACK_IMPORTED_MODULE_6__(newDate)));
  }

  presentModal(id, status) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this.modalController.create({
        component: _mzad_subescribe_mzad_subescribe_page__WEBPACK_IMPORTED_MODULE_3__.MzadSubescribePage,
        componentProps: {
          "mzd": _this.mzd,
          "USER_INFO": _this.USER_INFO
        }
      });
      modal.onDidDismiss().then(dataReturned => {
        if (dataReturned !== null) {
          console.log(dataReturned);

          _this.doAfterDissmiss(dataReturned);
        }
      });
      return yield modal.present();
    })();
  }

  doAfterDissmiss(dataReturned) {
    console.log(dataReturned, dataReturned.data, dataReturned.role);

    if (dataReturned.role == 'done') {
      this.rout.navigate(['tabs/home']); // this.mzd = dataReturned.data
      // this.socket.userJoiningAuction([this.USER_INFO._id,this.USER_INFO.firstName , this.mzad._id ])
      //push notification to aution's subiscribed users
      // let navigationExtras: NavigationExtras = {
      //   queryParams: {
      //     user_info: JSON.stringify(this.USER_INFO),
      //     auction_id: JSON.stringify(this.mzad._id)
      //   }
      // }; 
      //  this.rout.navigate(['live-mzad'], navigationExtras); 
    }
  }

  checkRemainTime() {
    //offset between now and startdate auction
    let newDate = moment__WEBPACK_IMPORTED_MODULE_6__(this.mzd['start']);
    let today = new Date();
    return moment__WEBPACK_IMPORTED_MODULE_6__(newDate).diff(moment__WEBPACK_IMPORTED_MODULE_6__(today));
  }

  validate() {
    if (this.checkRemainTime() <= 60000) {
      console.log('this.checkRemainTime()', this.checkRemainTime());
      this.presentToast('لا يمكنك الإشتراك , لقد بدأ المزاد بالفعل', 'danger');
      return false;
    } else {
      return true;
    } // validate if user not restircted
    // validate if user not from staff

  }

  prepareUserbj() {
    let mzdTemp = {
      _id: this.mzd['_id'],
      user: [{
        "userId": this.USER_INFO._id,
        "cancel": 1,
        "cancelTime": new Date(),
        "reason": "i dont Know",
        "cancelTransId": ""
      }]
    };
    return mzdTemp;
  }

  cancelSubiscribtion() {
    // when user cancel subiscribe to auctions 
    // user can only cancel subiscrbe befor auction start date(){ 
    if (this.validate() == true) {
      this.presentLoadingWithOptions("جاري معالجة طلبك .."); //api to add user to log of mzad

      console.log('prepareUserbj', this.prepareUserbj());
      this.api.cancelAuctionUsers(this.prepareUserbj()).subscribe(data => {
        console.log('auction update', data, data['updatedAuctionUsers']);
        this.presentToast("تم إلغاء الإشتراك بنجاح ", 'success'); //back to home page with new data

        this.rout.navigate(['tabs/home']);
      }, err => {
        this.loadingController.dismiss();
        console.log(err.error);
        this.handleError(err.error.error);
      }, () => {
        this.loadingController.dismiss();
      }); //api to add pay transaction + 
      //
      //socket emmit to tell others + push notification 
    }
  }

  handleError(err) {
    if (err == 'max users') {
      this.presentToast('اكتمل العدد المطلوب , لا يمكنك المشاركة', 'danger');
    } else {
      this.presentToast('حدث خطأ ما الرجاء المحاولة مرة اخري', 'danger');
    }
  }

  presentLoadingWithOptions(msg) {
    var _this2 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this2.loadingController.create({
        spinner: 'bubbles',
        mode: 'ios',
        duration: 5000,
        message: msg,
        translucent: true,
        // cssClass: 'custom-class custom-loading',
        backdropDismiss: false
      });
      yield loading.present();
      const {
        role,
        data
      } = yield loading.onDidDismiss();
      console.log('Loading dismissed with role:', role);
    })();
  }

  presentToast(msg, color) {
    var _this3 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this3.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  }

  subiscribe() {
    this.presentModal();
  }

};

MzadDetailsPage.ctorParameters = () => [{
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_5__.SocketServiceService
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_5__.SocketServiceService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.ActivatedRoute
}, {
  type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__.Storage
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.LoadingController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.ActionSheetController
}, {
  type: _angular_common__WEBPACK_IMPORTED_MODULE_11__.DatePipe
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.ModalController
}];

MzadDetailsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_13__.Component)({
  selector: 'app-mzad-details',
  template: _mzad_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_mzad_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], MzadDetailsPage);


/***/ }),

/***/ 5675:
/*!****************************************************************!*\
  !*** ./src/app/mzad-details/mzad-details.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = ".bgContent {\n  --background:var(--ion-color-dark) ;\n}\n\n.header-md::after {\n  background-image: none;\n}\n\n.roundedGrid {\n  border-bottom-left-radius: 50px;\n  border-bottom-right-radius: 50px;\n  padding-left: 10px;\n  padding-right: 10px;\n  background-color: var(--ion-color-primary-contrast);\n}\n\n.htx {\n  font-size: 2.5rem;\n  text-align: center;\n  color: var(--ion-color-primary-contrast);\n}\n\n.paddindStyle {\n  padding: 3px;\n}\n\n.custItem {\n  --background: none;\n}\n\n.detailCard {\n  background: var(--ion-color-dark-tint);\n}\n\n.cardCont {\n  color: var(--ion-color-primary-contrast);\n  font-size: 1.2rem;\n}\n\n.roundedRow {\n  border-radius: 1.5rem;\n  background-color: var(--ion-color-dark);\n}\n\n.bold {\n  font-weight: bold;\n}\n\n.col {\n  color: var(--ion-color-primary-contrast);\n}\n\n.btStyle2 {\n  border-style: solid;\n  border-color: var(--ion-color-dark);\n  background-color: var(--ion-color-primary-contrast);\n  border-radius: 2rem;\n  height: 84%;\n}\n\n.fotterStyle2 {\n  background-color: var(--ion-color-dark);\n}\n\n.borderlightbot {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-light-shade);\n}\n\n.borderbt {\n  border-bottom-style: solid;\n  border-bottom-width: 0.5px;\n  border-color: var(--ion-color-light-shade);\n}\n\n.pb0 {\n  padding-bottom: 0px;\n}\n\n.htextStyle {\n  color: var(--ion-color-primary-contrast);\n  font-size: 1.2rem;\n}\n\n.budgStatus {\n  position: absolute;\n  float: right;\n  right: 1rem;\n  top: 10px;\n}\n\n.mgleft {\n  margin-right: 2px;\n}\n\n.pos {\n  position: relative;\n}\n\n.custH {\n  text-align: center;\n  width: 100%;\n}\n\n.paddind {\n  padding: 3px;\n}\n\n.bgc {\n  background-color: var(--ion-color-medium);\n}\n\n.timercol {\n  background-color: var(--ion-color-light-tint);\n  border-bottom-left-radius: 9px;\n  border-bottom-right-radius: 9px;\n}\n\n.footer {\n  border-style: solid;\n  border-width: 0.3px;\n  border-color: var(--ion-color-light-shade);\n  border-top-right-radius: 30px;\n  border-top-left-radius: 30px;\n}\n\n.footer-md::before {\n  background-image: none;\n}\n\n.totcol {\n  border-right-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-light-shade);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm16YWQtZGV0YWlscy5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXGh1c2FtJTIwcHJvalxcem9vZG9oYVNkXFxzcmNcXGFwcFxcbXphZC1kZXRhaWxzXFxtemFkLWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksbUNBQUE7QUNBSjs7QURHRTtFQUNFLHNCQUFBO0FDQUo7O0FER0U7RUFDRSwrQkFBQTtFQUNBLGdDQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLG1EQUFBO0FDQUo7O0FER0c7RUFDQyxpQkFBQTtFQUNBLGtCQUFBO0VBQ0Esd0NBQUE7QUNBSjs7QURHRztFQUNDLFlBQUE7QUNBSjs7QURJQTtFQUNJLGtCQUFBO0FDREo7O0FER0E7RUFDSSxzQ0FBQTtBQ0FKOztBREdBO0VBQ0ksd0NBQUE7RUFDQSxpQkFBQTtBQ0FKOztBRE9HO0VBQ0MscUJBQUE7RUFDQSx1Q0FBQTtBQ0pKOztBRE1HO0VBQ0MsaUJBQUE7QUNISjs7QURLQztFQUNFLHdDQUFBO0FDRkg7O0FESUc7RUFDQyxtQkFBQTtFQUNBLG1DQUFBO0VBQ0EsbURBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7QUNESjs7QURJRztFQUNDLHVDQUFBO0FDREo7O0FESUE7RUFDSSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsMENBQUE7QUNESjs7QURJQTtFQUNJLDBCQUFBO0VBQ0EsMEJBQUE7RUFDQSwwQ0FBQTtBQ0RKOztBREdBO0VBQ0ksbUJBQUE7QUNBSjs7QURHQztFQUNHLHdDQUFBO0VBQ0EsaUJBQUE7QUNBSjs7QURFQTtFQUNDLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0FDQ0Q7O0FEQ0E7RUFDRSxpQkFBQTtBQ0VGOztBREFBO0VBQ0Msa0JBQUE7QUNHRDs7QUREQTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtBQ0lKOztBREZBO0VBQ0ksWUFBQTtBQ0tKOztBREZBO0VBQ0kseUNBQUE7QUNLSjs7QURIQTtFQUNHLDZDQUFBO0VBQ0MsOEJBQUE7RUFDQSwrQkFBQTtBQ01KOztBREpBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDBDQUFBO0VBQ0EsNkJBQUE7RUFDQSw0QkFBQTtBQ09KOztBREpBO0VBQ0ksc0JBQUE7QUNPSjs7QURKQTtFQUNJLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQ0FBQTtBQ09KIiwiZmlsZSI6Im16YWQtZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBzdHlsZSAyXHJcbi5iZ0NvbnRlbnR7XHJcbiAgICAtLWJhY2tncm91bmQ6dmFyKC0taW9uLWNvbG9yLWRhcmspIDtcclxuICB9XHJcbiAgXHJcbiAgLmhlYWRlci1tZDo6YWZ0ZXIgeyBcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6IG5vbmU7IFxyXG4gIH1cclxuXHJcbiAgLnJvdW5kZWRHcmlkeyBcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDUwcHg7XHJcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogNTBweDtcclxuICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDEwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XHJcbiAgIH1cclxuXHJcbiAgIC5odHh7XHJcbiAgICBmb250LXNpemU6IDIuNXJlbTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XHJcbiAgIH1cclxuXHJcbiAgIC5wYWRkaW5kU3R5bGV7XHJcbiAgICBwYWRkaW5nOiAzcHg7XHJcbiAgIFxyXG4gICAgfVxyXG4gICAgXHJcbi5jdXN0SXRlbXtcclxuICAgIC0tYmFja2dyb3VuZDogbm9uZTtcclxufVxyXG4uZGV0YWlsQ2FyZHtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1kYXJrLXRpbnQpO1xyXG4gICAgXHJcbn1cclxuLmNhcmRDb250e1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcclxuICAgIGZvbnQtc2l6ZTogMS4ycmVtO1xyXG59XHJcbi5jYXJkSGVke1xyXG5cclxufVxyXG5cclxuXHJcbiAgIC5yb3VuZGVkUm93e1xyXG4gICAgYm9yZGVyLXJhZGl1czogMS41cmVtOyBcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAgfVxyXG4gICAuYm9sZHtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICB9XHJcbiAuY29se1xyXG4gICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpOyBcclxuIH1cclxuICAgLmJ0U3R5bGUye1xyXG4gICAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMnJlbTsgXHJcbiAgICBoZWlnaHQ6IDg0JTtcclxuICAgfVxyXG5cclxuICAgLmZvdHRlclN0eWxlMntcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAgfVxyXG4vLyBzdHlsZSAxXHJcbi5ib3JkZXJsaWdodGJvdHtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IC41cHg7XHJcbiAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XHJcbn1cclxuXHJcbi5ib3JkZXJidHtcclxuICAgIGJvcmRlci1ib3R0b20tc3R5bGU6IHNvbGlkO1xyXG4gICAgYm9yZGVyLWJvdHRvbS13aWR0aDogLjVweDtcclxuICAgIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlKTtcclxufVxyXG4ucGIwe1xyXG4gICAgcGFkZGluZy1ib3R0b206IDBweDtcclxuIH1cclxuXHJcbiAuaHRleHRTdHlsZXtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XHJcbiAgICBmb250LXNpemU6IDEuMnJlbTtcclxuIH1cclxuLmJ1ZGdTdGF0dXN7XHJcbiBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiBmbG9hdDogcmlnaHQ7XHJcbiByaWdodDogMXJlbTtcclxuIHRvcDoxMHB4O1xyXG59XHJcbi5tZ2xlZnR7XHJcbiAgbWFyZ2luLXJpZ2h0OiAycHg7XHJcbn1cclxuLnBvc3tcclxuIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG4uY3VzdEh7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG4ucGFkZGluZHtcclxuICAgIHBhZGRpbmc6IDNweDtcclxufVxyXG5cclxuLmJnY3tcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG59XHJcbi50aW1lcmNvbHtcclxuICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXRpbnQpO1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogOXB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDlweDtcclxufVxyXG4uZm9vdGVye1xyXG4gICAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci13aWR0aDogMC4zcHg7XHJcbiAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMzBweDtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDMwcHg7XHJcbn1cclxuXHJcbi5mb290ZXItbWQ6OmJlZm9yZXtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6ICBub25lO1xyXG59XHJcblxyXG4udG90Y29se1xyXG4gICAgYm9yZGVyLXJpZ2h0LXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci13aWR0aDogMC41cHg7XHJcbiAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XHJcbn0iLCIuYmdDb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOnZhcigtLWlvbi1jb2xvci1kYXJrKSA7XG59XG5cbi5oZWFkZXItbWQ6OmFmdGVyIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn1cblxuLnJvdW5kZWRHcmlkIHtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNTBweDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDUwcHg7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbiAgcGFkZGluZy1yaWdodDogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xufVxuXG4uaHR4IHtcbiAgZm9udC1zaXplOiAyLjVyZW07XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcbn1cblxuLnBhZGRpbmRTdHlsZSB7XG4gIHBhZGRpbmc6IDNweDtcbn1cblxuLmN1c3RJdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiBub25lO1xufVxuXG4uZGV0YWlsQ2FyZCB7XG4gIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1kYXJrLXRpbnQpO1xufVxuXG4uY2FyZENvbnQge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xuICBmb250LXNpemU6IDEuMnJlbTtcbn1cblxuLnJvdW5kZWRSb3cge1xuICBib3JkZXItcmFkaXVzOiAxLjVyZW07XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcbn1cblxuLmJvbGQge1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLmNvbCB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XG59XG5cbi5idFN0eWxlMiB7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1jb250cmFzdCk7XG4gIGJvcmRlci1yYWRpdXM6IDJyZW07XG4gIGhlaWdodDogODQlO1xufVxuXG4uZm90dGVyU3R5bGUyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xufVxuXG4uYm9yZGVybGlnaHRib3Qge1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBib3JkZXItd2lkdGg6IDAuNXB4O1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XG59XG5cbi5ib3JkZXJidCB7XG4gIGJvcmRlci1ib3R0b20tc3R5bGU6IHNvbGlkO1xuICBib3JkZXItYm90dG9tLXdpZHRoOiAwLjVweDtcbiAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpO1xufVxuXG4ucGIwIHtcbiAgcGFkZGluZy1ib3R0b206IDBweDtcbn1cblxuLmh0ZXh0U3R5bGUge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xuICBmb250LXNpemU6IDEuMnJlbTtcbn1cblxuLmJ1ZGdTdGF0dXMge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGZsb2F0OiByaWdodDtcbiAgcmlnaHQ6IDFyZW07XG4gIHRvcDogMTBweDtcbn1cblxuLm1nbGVmdCB7XG4gIG1hcmdpbi1yaWdodDogMnB4O1xufVxuXG4ucG9zIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4uY3VzdEgge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4ucGFkZGluZCB7XG4gIHBhZGRpbmc6IDNweDtcbn1cblxuLmJnYyB7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xufVxuXG4udGltZXJjb2wge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtdGludCk7XG4gIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDlweDtcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDlweDtcbn1cblxuLmZvb3RlciB7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGJvcmRlci13aWR0aDogMC4zcHg7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlKTtcbiAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDMwcHg7XG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDMwcHg7XG59XG5cbi5mb290ZXItbWQ6OmJlZm9yZSB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmU7XG59XG5cbi50b3Rjb2wge1xuICBib3JkZXItcmlnaHQtc3R5bGU6IHNvbGlkO1xuICBib3JkZXItd2lkdGg6IDAuNXB4O1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XG59Il19 */";

/***/ }),

/***/ 1486:
/*!****************************************************************!*\
  !*** ./src/app/mzad-details/mzad-details.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-header *ngIf=\"style == 'style1'\">\n  <ion-toolbar dir=\"rtl\">\n    <ion-buttons slot=\"end\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n      <ion-title>\n        <ion-icon name=\"list-outline\"></ion-icon>\n        تفاصيل\n      </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n<ion-header *ngIf= \"style == 'style2' && mzd\"  color=\"translucent\" class=\"hedAfter\">\n  <ion-toolbar dir=\"rtl\" class=\"ion-text-center\" color=\"translucent\">\n    <ion-buttons slot=\"end\" >\n      <ion-back-button ></ion-back-button>\n    </ion-buttons>\n      <ion-title >\n        {{ mzd['title'] }}\n      </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content  *ngIf= \"style == 'style1'\" class=\"\">\n  <ion-grid *ngIf=\"errorLoad == true\" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n  </ion-grid>\n\n<ion-grid *ngIf=\"!mzd && errorLoad == false\"  class=\"custGrid\"> \n  <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n    <ion-col size=\"12\" class=\"ion-text-center\">\n      <!-- *ngIf=\"spinner == true\" -->\n      <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n    </ion-col>\n    <ion-col size=\"12\">\n      <!-- *ngIf=\"spinner == true\" --> \n    </ion-col>\n  </ion-row> \n</ion-grid>\n  \n\n  <ion-grid class=\"ion-no-margin  ion-no-padding\"  dir=\"rtl\" *ngIf=\"mzd\"> \n    <ion-row class=\"ion-no-margin  ion-no-padding\"> \n      <ion-col size=\"12\" class=\"ion-no-margin pos\"> \n        <div class=\"budgStatus\" *ngIf=\"mzd\">\n          <ion-badge *ngIf=\"mzd['currentStatus'] == 1\" color=\"warning\" slot=\"end\" class=\"badge\">\n            <ion-icon  name=\"ellipse\" color=\"light\"></ion-icon> \n            <ion-text> مزاد قادم</ion-text>  \n            </ion-badge>\n            <ion-badge *ngIf=\"mzd['currentStatus'] == 3\" color=\"light\" slot=\"end\" class=\"badge\">\n              <ion-text> مزاد منتهي </ion-text> \n                <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n              </ion-badge>\n              <ion-badge *ngIf=\"mzd['currentStatus']  == 2\" color=\"success\" slot=\"end\" class=\"badge\">\n                <ion-text> مزاد جاري</ion-text> \n                  <ion-icon   name=\"ellipse\" color=\"danger\"></ion-icon> \n              </ion-badge> \n              <ion-badge color=\"light\" *ngIf=\"mzd['userIn']\" class=\"mgleft\">\n                <ion-icon name=\"ribbon-outline\"></ion-icon>\n                <ion-text> مشارك   </ion-text>\n              </ion-badge>  \n              <ion-badge color=\"light\" *ngIf=\"mzd['userOut']\" class=\"mgleft\">\n                <ion-icon name=\"ribbon-outline\" color=\"danger\"></ion-icon>\n                <ion-text> ملغي   </ion-text>\n              </ion-badge>  \n        </div>\n         \n        <img class=\"radus5 img\"  [src]=\"mzd['imgs'][0]\"/>   \n      </ion-col>  \n      <ion-col size=\"12\"  class=\"borderbt\">\n        <ion-card-header class=\"pb0\"> \n          <ion-card-title> {{ mzd['title'] }}  </ion-card-title>\n          <ion-label>\n            {{mzd['shortDescr']}}\n          </ion-label>\n        </ion-card-header> \n        <ion-card-content>\n          <ion-label *ngIf=\"showMore == true\">\n            {{mzd['descr']}}\n            <ion-text><ion-button fill=\"clear\" size=\"small\" (click)=\"showMore = false \">اقل</ion-button></ion-text>\n          </ion-label>\n          <ion-label *ngIf=\"showMore == false\">{{tirmString(mzd['descr'] ,100)}}\n             <ion-text><ion-button fill=\"clear\" size=\"small\" (click)=\"showMore = true \">المزيد</ion-button></ion-text>\n           </ion-label>\n        </ion-card-content>\n      </ion-col> \n     </ion-row> \n\n    \n    <ion-row class=\"ion-no-padding\" *ngIf=\"mzd\"> \n      <ion-card class=\"w100\" *ngIf=\"mzd['currentStatus'] != 1\">\n        <ion-card-header class=\"pb0\">\n          <ion-card-title>\n            <ion-icon name=\"bookmark-outline\" color=\"primary\"></ion-icon> \n            المشاركين\n          </ion-card-title> \n        </ion-card-header>\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\" >\n             <ion-card-content> \n              <ion-label *ngFor=\"let term of mzd['terms']\">\n                <ion-icon name=\"pin\" color=\"primary\"></ion-icon>\n                <ion-text>{{term.desc}}</ion-text><br>\n               </ion-label> \n            </ion-card-content>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </ion-card> \n      <ion-card class=\"w100\"> \n        <ion-card-header class=\"pb0\">  \n            <ion-card-title>\n             <ion-icon name=\"cash-outline\" color=\"primary\"></ion-icon> \n              الرسوم\n            </ion-card-title>\n          </ion-card-header>\n          <ion-grid class=\"ion-no-margin  ion-no-padding ion-padding-bottom\" dir=\"rtl\">\n            <ion-row class=\"ion-no-margin  ion-no-padding\"> \n              <ion-col size=\"4\" class=\"ion-text-center\">\n                <ion-card-content> \n                    <ion-text color=\"primary\"><b>العربون</b> </ion-text><br> \n                    <ion-text>  {{mzd['deposit']}} </ion-text>\n                    <!-- <ion-text> ر.س </ion-text>  -->\n                  </ion-card-content>\n              </ion-col>\n              <ion-col size=\"4\" class=\"ion-text-center\">\n                <ion-card-content>  \n                      <ion-text color=\"primary\"><b>رسوم دفتر </b> </ion-text><br> \n                       <ion-text>    {{mzd['fee']}}</ion-text> \n                       <!-- <ion-text>   ر.س </ion-text>   -->\n                </ion-card-content>\n              </ion-col>\n\n              <ion-col size=\"4\" class=\"ion-text-center totcol\">\n                <ion-card-content> \n                  <ion-text color=\"primary\"><b>المجموع </b>  </ion-text><br>\n                  <ion-text>{{+mzd['deposit'] + +mzd['fee']}} </ion-text>\n                  <!-- <ion-text>   ر.س </ion-text>  -->\n                </ion-card-content>\n              </ion-col>\n            </ion-row>\n          </ion-grid> \n      </ion-card> \n   \n      <ion-card class=\"w100\">\n        <ion-card-header class=\"pb0\">  \n          <ion-card-title>\n            <ion-icon name=\"calendar-outline\" color=\"primary\"></ion-icon>\n          الجدول الزمني \n          </ion-card-title>\n        </ion-card-header>\n        <ion-grid>\n          <ion-row>  \n            <ion-col size=\"12\" *ngIf=\"mzd['timeLeft'] | async as tm\">\n              <h6 class=\"htext\">\n                 <!-- <ion-text>انتنهي :</ion-text>\n                <ion-text>بدأ منذ : </ion-text> -->\n                <ion-label><ion-text color=\"primary\" class=\"paddind\">\n                  <b *ngIf=\"mzd.currentStatus == 1 \">  يبدأ بعد :</b>\n                  <b *ngIf=\"mzd.currentStatus === 3 \">  إنتهي منذ :</b>\n                  <b *ngIf=\"mzd.currentStatus === 2 \">  ينتهي بعد :</b>\n                 </ion-text></ion-label>\n                <ion-label><ion-text color=\"primary\" class=\"paddind\"><b>{{tm['da'] }}</b> </ion-text>يوم : </ion-label>\n                <ion-label><ion-text color=\"primary\" class=\"paddind\"><b>{{tm['hr'] }}</b> </ion-text>ساعة : </ion-label>\n                <ion-label><ion-text color=\"primary\" class=\"paddind\"><b>{{tm['mn'] }}</b> </ion-text>دقيقة : </ion-label>\n                <ion-label><ion-text color=\"primary\" class=\"paddind\"><b>{{tm['sc'] }}</b> </ion-text>ثانية </ion-label>\n              </h6> \n            </ion-col>\n          </ion-row>\n          <ion-row class=\"ion-margin-top ion-padding-bottom\"> \n            <ion-col size=\"6\" >\n              <ion-label> \n                <ion-label><ion-text color=\"primary\" class=\"paddind\"><b> التاريخ :</b> </ion-text></ion-label>\n                <ion-text class=\"paddind\">{{mzd['start'] | date:'EEE dd-MM-yyyy' : undefined  : 'ar'}}</ion-text>    \n                <!-- <ion-text class=\"paddind\" color=\"primary\"> <b></b> </ion-text> -->\n              </ion-label> \n            </ion-col> \n            <ion-col size=\"4\" >\n              <ion-label class=\"padding5\">\n                <ion-text color=\"medium\" > {{mzd['start'] | date:'hh:mm a': undefined  : 'ar'}}</ion-text>\n               </ion-label>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </ion-card>\n         <ion-card class=\"w100\">\n        <ion-card-header class=\"pb0\">\n          <ion-card-title>\n            <ion-icon name=\"bookmark-outline\" color=\"primary\"></ion-icon> \n            بنود المزاد\n          </ion-card-title> \n        </ion-card-header>\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\" >\n             <ion-card-content> \n              <ion-label *ngFor=\"let term of terms\">\n                <ion-icon name=\"pin\" color=\"primary\"></ion-icon>\n                <ion-text>{{term.desc}}</ion-text><br>\n               </ion-label> \n            </ion-card-content>\n            </ion-col>\n          </ion-row>\n          <ion-item button (click)=\"viewMoreLess()\" lines=\"none\" class=\"lightItem lightBorder\">\n            <h4 class=\"custH\">\n             <ion-label *ngIf=\"view == 0\">\n               <ion-note >المزيد</ion-note><br>\n               <ion-icon name=\"chevron-down-outline\" color=\"primary\"></ion-icon>\n             </ion-label>\n             <ion-label *ngIf=\"view == 1\">\n               <ion-note >اقل</ion-note><br>\n               <ion-icon   name=\"chevron-up-outline\" color=\"primary\"></ion-icon> \n             </ion-label> \n            </h4> \n         </ion-item> \n        </ion-grid>\n      </ion-card> \n    </ion-row>\n\n  </ion-grid> \n</ion-content>\n\n\n<ion-content  *ngIf= \"style == 'style2'\" class=\"bgContent\">\n\n <ion-grid *ngIf=\"errorLoad == true\" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n</ion-grid>\n\n<ion-grid *ngIf=\"!mzd && errorLoad == false\"  class=\"custGrid\"> \n  <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n    <ion-col size=\"12\" class=\"ion-text-center\">\n      <!-- *ngIf=\"spinner == true\" -->\n      <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n    </ion-col>\n    <ion-col size=\"12\">\n      <!-- *ngIf=\"spinner == true\" --> \n    </ion-col>\n  </ion-row> \n</ion-grid>\n\n<ion-grid  class=\"roundedGrid ion-no-margin ion-padding-top w100\"  dir=\"rtl\" *ngIf=\"mzd\"> \n  <ion-row  class=\"roundedRow ion-no-margin ion-no-padding  w100\" dir=\"rtl\"> \n    <ion-col size=\"7\"  class=\"ion-padding-start\"> \n      <h3 class=\"col\">     السعر الإفتتاحي    </h3> \n    </ion-col>\n \n    <ion-col  size=\"5\" class=\"ion-text-end ion-padding-end\" > \n      <h3 class=\"col\">   {{mzd['productPrice'] - (0.3 * mzd['productPrice'])}} <ion-text>ر.س</ion-text>   </h3> \n    </ion-col>\n  </ion-row> \n\n  <ion-row>\n    <img class=\"radus5 img\"  [src]=\"mzd['imgs'][0]\"/>   \n  </ion-row>\n\n\n  <ion-row>\n  <ion-col size=\"12\"  class=\"\">\n    <ion-card-header class=\"pb0\"> \n      <ion-card-title> {{ mzd['title'] }}  </ion-card-title>\n      <ion-label>\n        {{mzd['shortDescr']}}\n      </ion-label>\n    </ion-card-header> \n    <ion-card-content >\n      <ion-label *ngIf=\"showMore == true\">\n        {{mzd['descr']}}\n        <ion-text><ion-button fill=\"clear\" size=\"small\" (click)=\"showMore = false \">اقل</ion-button></ion-text>\n      </ion-label>\n      <ion-label *ngIf=\"showMore == false\">{{tirmString(mzd['descr'] ,20)}}\n         <ion-text><ion-button fill=\"clear\" size=\"small\" (click)=\"showMore = true \">المزيد</ion-button></ion-text>\n       </ion-label>\n    </ion-card-content>\n  </ion-col> \n</ion-row> \n</ion-grid>\n\n<ion-grid *ngIf=\"mzd\"> \n    <ion-row dir=\"rtl\">  \n      <ion-col size=\"12\" *ngIf=\"mzd['timeLeft'] | async as tm\">\n        <h6 class=\"htx\"> \n          <!-- <ion-label><ion-text color=\"primary\" class=\"paddind\">\n            <b *ngIf=\"mzd.currentStatus == 1 \">  يبدأ بعد :</b>\n            <b *ngIf=\"mzd.currentStatus === 3 \">  إنتهي منذ :</b>\n            <b *ngIf=\"mzd.currentStatus === 2 \">  ينتهي بعد :</b>\n           </ion-text>\n          </ion-label> -->\n          <ion-label><ion-text class=\"paddindStyle2\"><b>{{tm['da'] }}</b> </ion-text> :  </ion-label>\n          <ion-label><ion-text class=\"paddindStyle2\"><b>{{tm['hr'] }}</b> </ion-text>  :  </ion-label>\n          <ion-label><ion-text class=\"paddindStyle2\"><b>{{tm['mn'] }}</b> </ion-text>  :  </ion-label>\n          <ion-label><ion-text class=\"paddindStyle2\"><b>{{tm['sc'] }}</b> </ion-text>  </ion-label>\n        </h6> \n      </ion-col>\n    </ion-row>\n  \n\n  <ion-row class=\"ion-no-padding\" *ngIf=\"mzd\" dir=\"rtl\"> \n    <ion-card class=\"w100\" *ngIf=\"mzd['currentStatus'] != 1\">\n      <ion-card-header class=\"pb0\">\n        <ion-card-title>\n          <ion-icon name=\"bookmark-outline\" color=\"primary\"></ion-icon> \n          المشاركين\n        </ion-card-title> \n      </ion-card-header>\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"12\" >\n           <ion-card-content> \n            <ion-label *ngFor=\"let term of mzd['terms']\">\n              <ion-icon name=\"pin\" color=\"primary\"></ion-icon>\n              <ion-text>{{term.desc}}</ion-text><br>\n             </ion-label> \n          </ion-card-content>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-card> \n    <ion-card class=\"w100 detailCard\"> \n      <ion-card-header class=\"pb0\">  \n          <ion-card-title color=\"light\">\n           <ion-icon name=\"cash-outline\" color=\"light\"></ion-icon> \n            الرسوم\n          </ion-card-title>\n        </ion-card-header>\n        <ion-grid class=\"ion-no-margin  ion-no-padding ion-padding-bottom\" dir=\"rtl\">\n          <ion-row class=\"ion-no-margin  ion-no-padding\"> \n            <ion-col size=\"4\" class=\"ion-text-center\">\n              <ion-card-content class=\"cardCont\"> \n                  <ion-text color=\"light\"><b>العربون</b> </ion-text><br> \n                  <ion-text>  {{mzd['deposit']}} </ion-text>\n                  <!-- <ion-text> ر.س </ion-text>  -->\n                </ion-card-content>\n            </ion-col>\n            <ion-col size=\"4\" class=\"ion-text-center\">\n              <ion-card-content class=\"cardCont\">  \n                    <ion-text color=\"light\"><b>رسوم دفتر </b> </ion-text><br> \n                     <ion-text>    {{mzd['fee']}}</ion-text> \n                     <!-- <ion-text>   ر.س </ion-text>   -->\n              </ion-card-content>\n            </ion-col>\n  \n            <ion-col size=\"4\" class=\"ion-text-center totcol\">\n              <ion-card-content class=\"cardCont\"> \n                <ion-text color=\"light\"><b>المجموع </b>  </ion-text><br>\n                <ion-text>{{+mzd['deposit'] + +mzd['fee']}} </ion-text>\n                <!-- <ion-text>   ر.س </ion-text>  -->\n              </ion-card-content>\n            </ion-col>\n          </ion-row>\n        </ion-grid> \n    </ion-card> \n  \n    <ion-card class=\"w100 detailCard\">\n      <ion-card-header class=\"pb0\">  \n        <ion-card-title color =\"light\">\n          <ion-icon name=\"calendar-outline\" color =\"light\"></ion-icon>\n        الجدول الزمني \n        </ion-card-title>\n      </ion-card-header>\n      <ion-grid>\n        <ion-row>  \n          <ion-col size=\"12\" *ngIf=\"mzd['timeLeft'] | async as tm\">\n            <h6 class=\"htextStyle\">\n               <!-- <ion-text>انتنهي :</ion-text>\n              <ion-text>بدأ منذ : </ion-text> -->\n              <ion-label><ion-text color=\"light\" class=\"paddind\">\n                <b *ngIf=\"mzd.currentStatus == 1 \">  يبدأ بعد  </b>\n                <b *ngIf=\"mzd.currentStatus === 3 \">  إنتهي منذ  </b>\n                <b *ngIf=\"mzd.currentStatus === 2 \">  ينتهي بعد  </b>\n               </ion-text>\n              </ion-label><br>\n              <ion-label><ion-text color=\"light\" class=\"paddind\"><b>{{tm['da'] }}</b> </ion-text>يوم : </ion-label>\n              <ion-label><ion-text color=\"light\" class=\"paddind\"><b>{{tm['hr'] }}</b> </ion-text>ساعة : </ion-label>\n              <ion-label><ion-text color=\"light\" class=\"paddind\"><b>{{tm['mn'] }}</b> </ion-text>دقيقة : </ion-label>\n              <ion-label><ion-text color=\"light\" class=\"paddind\"><b>{{tm['sc'] }}</b> </ion-text>ثانية </ion-label>\n            </h6> \n          </ion-col>\n        </ion-row>\n        <ion-row class=\"ion-margin-top ion-padding-bottom\"> \n          <ion-col size=\"12\" >\n            <ion-label class=\"htextStyle\"> \n              <ion-label><ion-text color=\"light\" class=\"paddind\"><b> التاريخ  </b> </ion-text></ion-label><br>\n              <ion-text class=\"paddind\">{{mzd['start'] | date:'EEE dd-MM-yyyy' : undefined  : 'ar'}}</ion-text>    \n              <!-- <ion-text class=\"paddind\" color=\"primary\"> <b></b> </ion-text> -->\n              \n            </ion-label> \n            <ion-label class=\"padding5\">\n              <ion-text color=\"light\" > {{mzd['start'] | date:'hh:mm a': undefined  : 'ar'}}</ion-text>\n             </ion-label>\n          </ion-col> \n          \n        </ion-row>\n      </ion-grid>\n    </ion-card>\n\n       <ion-card class=\"w100 detailCard\"> \n      <ion-card-header class=\"pb0\">\n        <ion-card-title color=\"light\">\n          <ion-icon name=\"bookmark-outline\" color=\"light\"></ion-icon> \n          بنود المزاد\n        </ion-card-title> \n      </ion-card-header>\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"12\" >\n           <ion-card-content class=\"cardCont\">\n            <ion-label *ngFor=\"let term of terms\">\n              <ion-icon name=\"pin\" color=\"primary\"></ion-icon>\n              <ion-text>{{term.desc}}</ion-text><br>\n             </ion-label> \n          </ion-card-content>\n          </ion-col>\n        </ion-row>\n        <ion-item button (click)=\"viewMoreLess()\" lines=\"none\" class=\"lightItem lightBorder custItem\">\n          <h4 class=\"custH\">\n           <ion-label *ngIf=\"view == 0\">\n             <ion-note >المزيد</ion-note><br>\n             <ion-icon name=\"chevron-down-outline\" color=\"primary\"></ion-icon>\n           </ion-label>\n           <ion-label *ngIf=\"view == 1\">\n             <ion-note >اقل</ion-note><br>\n             <ion-icon   name=\"chevron-up-outline\" color=\"primary\"></ion-icon> \n           </ion-label> \n          </h4> \n       </ion-item> \n      </ion-grid>\n      </ion-card> \n  </ion-row>\n</ion-grid>\n</ion-content>\n\n<ion-footer class=\"fotterStyle2\"  *ngIf=\"mzd && style=='style2'\">\n  <ion-grid dir=\"rtl\">\n    <ion-row  >\n      <ion-col size=\"6\" *ngIf=\"mzd['currentStatus'] == 1 && !mzd['userIn']\">\n       <ion-button expand=\"block\" fill=\"clear\" color=\"dark\" (click)=\"subiscribe()\"  class=\"btStyle2\"> \n        <h5 class=\"bold\">دخول المزاد</h5>\n        <ion-icon name=\"send-outline\"  color=\"light\" slot=\"end\"></ion-icon> \n       </ion-button>\n      </ion-col>\n      <ion-col size=\"6\" *ngIf=\"mzd['currentStatus'] == 1 && mzd['userIn'] == true\">\n        <ion-button  expand=\"block\" fill=\"clear\" color=\"danger\"  (click)=\"cancelSubiscribtion()\"  class=\"btStyle2\"> \n         <h5> إلغاء الإشتراك</h5>\n         <!-- <ion-icon name=\"send-outline\"  color=\"light\" slot=\"end\"></ion-icon>  -->\n        </ion-button>\n       </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\" *ngIf=\"mzd['currentStatus'] != 1\">\n        <h4 class=\"ion-no-margin\">\n        <ion-text color=\"primary\">\n            أعلي مزايدة\n        </ion-text> <br>  \n        <ion-text> {{ mzd['fee'] + mzd['deposit'] }}  </ion-text>\n         <ion-text> ج.س</ion-text>\n       </h4>  \n      </ion-col> \n    </ion-row>\n  </ion-grid>\n</ion-footer>\n\n<ion-footer class=\"footer\"  *ngIf=\"mzd && style=='style1'\">\n  <ion-grid dir=\"rtl\">\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col size=\"6\" *ngIf=\"mzd['currentStatus'] == 1 && !mzd['userIn']\">\n       <ion-button expand=\"block\" (click)=\"subiscribe()\"> \n        <h5>دخول المزاد</h5>\n        <ion-icon name=\"send-outline\"  color=\"light\" slot=\"end\"></ion-icon> \n       </ion-button>\n      </ion-col>\n      <ion-col size=\"6\"*ngIf=\"mzd['currentStatus'] == 1 && mzd['userIn'] == true\">\n        <ion-button expand=\"block\" (click)=\"cancelSubiscribtion()\" color=\"danger\"> \n         <h5> إلغاء الإشتراك</h5>\n         <!-- <ion-icon name=\"send-outline\"  color=\"light\" slot=\"end\"></ion-icon>  -->\n        </ion-button>\n       </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\" *ngIf=\"mzd['currentStatus'] != 1\">\n        <h4 class=\"ion-no-margin\">\n        <ion-text color=\"primary\">\n            أعلي مزايدة\n        </ion-text> <br>  \n        <ion-text> {{ mzd['fee'] + mzd['deposit'] }}  </ion-text>\n         <ion-text> ج.س</ion-text>\n       </h4>  \n      </ion-col> \n    </ion-row>\n  </ion-grid>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_mzad-details_mzad-details_module_ts.js.map