"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_home_home_module_ts"],{

/***/ 2003:
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 2267);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage,
        children: [
            {
                path: 'mazad-details',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_mzad-subescribe_mzad-subescribe_page_ts"), __webpack_require__.e("default-src_app_mzad-details_mzad-details_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../mzad-details/mzad-details.module */ 3702)).then(m => m.MzadDetailsPageModule)
            },
            {
                path: '',
                redirectTo: '/tabs/home',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: '/tabs/home',
        pathMatch: 'full'
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HomePageRoutingModule);



/***/ }),

/***/ 3467:
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home-routing.module */ 2003);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page */ 2267);







let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_0__.HomePageRoutingModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_1__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 2267:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page.html?ngResource */ 3853);
/* harmony import */ var _home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss?ngResource */ 1020);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 2378);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/socket-service.service */ 905);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! moment */ 6908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment-timezone */ 2469);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment_timezone__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage */ 190);











let HomePage = class HomePage {
  // (alias) timer(dueTime?: number | Date, periodOrScheduler?: number | SchedulerLike, scheduler?: SchedulerLike): Observable<number>
  // import timer
  // Creates an Observable that starts emitting after an dueTime and emits ever increasing numbers after each period of time thereafter.
  // Its like index /interval, but you can specify when should the emissions start.
  // timer returns an Observable that emits an infinite sequence of ascending integers, with a constant interval of time, period of your choosing between those emissions. The first emission happens after the specified dueTime. The initial delay may be a Date. By default, this operator uses the asyncScheduler SchedulerLike to provide a notion of time, but you may pass any SchedulerLike to it. If period is not specified, the output Observable emits only one value, 0. Otherwise, it emits an infinite sequence.
  // Examples
  // Emits ascending numbers, one every second (1000ms), starting after 3 seconds
  // import { timer } from 'rxjs';
  // const numbers = timer(3000, 1000);
  // numbers.subscribe(x => console.log(x));
  // Emits one number after five seconds
  // import { timer } from 'rxjs';
  // const numbers = timer(5000);
  // numbers.subscribe(x => console.log(x))
  constructor(storage, api, datePipe, rout, socket) {
    //  this.socket.getNewAuction()
    this.storage = storage;
    this.api = api;
    this.datePipe = datePipe;
    this.rout = rout;
    this.socket = socket;
    this.errorLoad = false;
    this.timeLeftArr = [{
      da: String,
      hr: String,
      mn: String,
      sc: String
    }];
    this.auctionsArray = [];
    this.slideOpts = {
      slidesPerView: 3,
      nitialSlide: 0
    };
  }

  ngOnInit() {
    this.storage.get('user_info').then(response => {
      if (response) {
        this.USER_INFO = response.user;
        console.log('kkkkkkkkkk', this.USER_INFO);
        this.getAllAuction();
      }
    });
  }

  ionViewWillEnter() {}

  getAllAuction() {
    this.api.getAllAuction().subscribe(data => {
      console.log(data);
      let res = data['auctions'];
      this.auctionsArray = res;
      console.log(this.auctionsArray);
      this.prepareAuc();
    }, err => {
      console.log(err);
      this.handleError(err.error.error);
    });
  }

  reload() {
    this.errorLoad = false;
    this.auctionsArray = undefined;
    this.getAllAuction();
  }

  handleError(err) {
    this.errorLoad = true; // if (err.error == "No user with this phone found") {
    //   console.log('no user was found') 
    // // this.getsms('new',err) // uncomment it after apply smsgetway 
    // // this.getVirfyCode('new' , err) // comment it after apply smsgetway 
    // }else if(err.error == "another phone"){
    //   // to apply imei check uncmment the line in zoodohapi/controller/user.j function : loginPhone
    //   this.presentToast('seem you use another phone','danger') 
    // } else{ 
    //   this.presentToast('حدث خطأ ما ,حاول مرة اخري','danger')
    //   console.log(err.kind)
    // }
  }

  prepareAuc() {
    //set count down for auctions
    for (let index = 0; index < this.auctionsArray.length; index++) {
      const element = this.auctionsArray[index];

      if (element.currentStatus == 1) {
        element.timeLeft = this.startAfterounter(index);
      } else if (element.currentStatus == 2) {
        //edit here
        element.timeLeft = this.endAfterounter(index);
      } else if (element.currentStatus == 3) {
        //edit here
        element.timeLeft = this.endSinceAfterounter(index);
      } // userIn


      let fltuse = [];
      fltuse = element.users.filter(x => x.userId == this.USER_INFO._id);
      console.log('fltuse' + index, fltuse);

      if (fltuse.length > 0 && element.currentStatus < 3 && fltuse[0].cancel == 0) {
        element.userIn = true;
      } else if (fltuse.length > 0 && fltuse[0].cancel == 1) {
        element.userOut = true;
      } else if (element.logs.length > 0 && fltuse.length > 0 && element.currentStatus == 3) {
        // userWin
        let mx = element.logs.reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0);
        let flt = element.logs.filter(x => x.pay == mx);
        console.log('userWin', mx, flt);

        if (flt[0].userId == this.USER_INFO._id) {
          element.userWin = true;
        }
      } //duration


      let du = moment__WEBPACK_IMPORTED_MODULE_3__.duration(moment__WEBPACK_IMPORTED_MODULE_3__(element.end).diff(moment__WEBPACK_IMPORTED_MODULE_3__(element.start)));
      let hr = "";
      let day = "";
      let con = "";

      if (du.days() > 0) {
        day = du.days().toString() + " يوم";
      }

      if (du.hours() > 0) {
        hr = du.hours().toString() + " ساعة";
      }

      if (du.hours() > 0 && du.hours() > 0) {
        con = " , ";
      }

      element.duration = day + con + hr;
    }

    console.log(this.auctionsArray);
  }

  endAfterounter(index) {
    let offset = moment_timezone__WEBPACK_IMPORTED_MODULE_4__().utcOffset();
    let newDate = moment__WEBPACK_IMPORTED_MODULE_3__(this.auctionsArray[index]['end']).add();
    console.log('init', this.auctionsArray[index]['end'], 'sdfs', offset, 'newDate', moment__WEBPACK_IMPORTED_MODULE_3__(newDate).format('YYYY-MM-DDTHH:mm:ss.SSSSZ'));
    return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable(observer => {
      setInterval(() => observer.next({
        da: this.memntoEnd(newDate).asDays().toFixed(0).toString(),
        hr: this.memntoEnd(newDate).hours().toString(),
        mn: this.memntoEnd(newDate).minutes().toString(),
        sc: this.memntoEnd(newDate).seconds().toString()
      }), 1000);
    });
  }

  memntoEnd(newDate) {
    return moment__WEBPACK_IMPORTED_MODULE_3__.duration(moment__WEBPACK_IMPORTED_MODULE_3__(newDate).diff(moment__WEBPACK_IMPORTED_MODULE_3__()));
  }

  startAfterounter(index) {
    let offset = moment_timezone__WEBPACK_IMPORTED_MODULE_4__().utcOffset();
    let newDate = moment__WEBPACK_IMPORTED_MODULE_3__(this.auctionsArray[index]['start']).add();
    console.log(moment__WEBPACK_IMPORTED_MODULE_3__(), 'init', this.auctionsArray[index]['start'], 'sdfs', offset, 'newDate', moment__WEBPACK_IMPORTED_MODULE_3__(newDate).format('YYYY-MM-DDTHH:mm:ss.SSSSZ'));
    return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable(observer => {
      setInterval(() => observer.next({
        da: this.memntoStart(newDate).asDays().toFixed(0).toString(),
        hr: this.memntoStart(newDate).hours().toString(),
        mn: this.memntoStart(newDate).minutes().toString(),
        sc: this.memntoStart(newDate).seconds().toString()
      }), 1000);
    });
  }

  memntoStart(newDate) {
    let today = new Date();
    return moment__WEBPACK_IMPORTED_MODULE_3__.duration(moment__WEBPACK_IMPORTED_MODULE_3__(newDate).diff(moment__WEBPACK_IMPORTED_MODULE_3__(today)));
  }

  endSinceAfterounter(index) {
    let offset = moment_timezone__WEBPACK_IMPORTED_MODULE_4__().utcOffset();
    let newDate = moment__WEBPACK_IMPORTED_MODULE_3__(this.auctionsArray[index]['end']).add();
    console.log(moment__WEBPACK_IMPORTED_MODULE_3__(), 'init', this.auctionsArray[index]['end'], 'sdfs', offset, 'newDate', moment__WEBPACK_IMPORTED_MODULE_3__(newDate).format('YYYY-MM-DDTHH:mm:ss.SSSSZ'));
    return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable(observer => {
      setInterval(() => observer.next({
        da: this.memnSinceEnd(newDate).asDays().toFixed(0).toString(),
        hr: this.memnSinceEnd(newDate).hours().toString(),
        mn: this.memnSinceEnd(newDate).minutes().toString(),
        sc: this.memnSinceEnd(newDate).seconds().toString()
      }), 1000);
    });
  }

  memnSinceEnd(newDate) {
    return moment__WEBPACK_IMPORTED_MODULE_3__.duration(moment__WEBPACK_IMPORTED_MODULE_3__().diff(moment__WEBPACK_IMPORTED_MODULE_3__(newDate)));
  }

  mazdDetails(auct) {
    let navigationExtras = {
      queryParams: {
        id: JSON.stringify(auct._id),
        user_info: JSON.stringify(this.USER_INFO)
      }
    };

    if (auct.userIn == true && auct.currentStatus == 2) {
      this.rout.navigate(['live-mzad'], navigationExtras);
    } else if (auct.userWin == true) {
      // redirect to tabs/cart and pass _id to present details modal 
      this.rout.navigate(['order-details'], navigationExtras);
    } else if (auct.userOut == true && auct.currentStatus == 1) {
      this.rout.navigate(['mazad-details'], navigationExtras);
    } else {
      this.rout.navigate(['mazad-details'], navigationExtras);
    }
  }

};

HomePage.ctorParameters = () => [{
  type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__.Storage
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_2__.SocketServiceService
}, {
  type: _angular_common__WEBPACK_IMPORTED_MODULE_7__.DatePipe
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_2__.SocketServiceService
}];

HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
  selector: 'app-home',
  template: _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
  styles: [_home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
})], HomePage);


/***/ }),

/***/ 1020:
/*!************************************************!*\
  !*** ./src/app/home/home.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = ".radus5 {\n  border-radius: 4%;\n}\n\n.borderlight {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-light-shade);\n}\n\n.badge {\n  padding-top: 4px;\n  padding-bottom: 5px;\n  padding-right: 13px;\n  padding-left: 14px;\n}\n\n.mgt10 {\n  margin-top: 10px;\n}\n\n.padding5 {\n  padding-top: 5px;\n}\n\n--ion-padding {\n  padding-left: unset;\n  padding-right: unset;\n  padding-inline-start: var(--ion-padding, 9px);\n  padding-inline-end: var(--ion-padding, 9px);\n}\n\n.timercol {\n  background-color: var(--ion-color-light-tint);\n  border-bottom-left-radius: 9px;\n  border-bottom-right-radius: 9px;\n}\n\n.htext {\n  text-align: center;\n  margin-top: 3px;\n  margin-bottom: 1px;\n}\n\n.hnom {\n  text-align: center;\n  margin-top: 1px;\n}\n\n.img {\n  height: 135px;\n  width: 153px;\n}\n\n.Status {\n  position: absolute;\n  float: right;\n  right: 3px;\n  top: 3px;\n}\n\n.pos {\n  position: relative;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFxodXNhbSUyMHByb2pcXHpvb2RvaGFTZFxcc3JjXFxhcHBcXGhvbWVcXGhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksaUJBQUE7QUNBSjs7QURHQTtFQUNJLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQ0FBQTtBQ0FKOztBREdBO0VBQ0ksZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUNBSjs7QURHQTtFQUNJLGdCQUFBO0FDQUo7O0FER0E7RUFDQSxnQkFBQTtBQ0FBOztBREVBO0VBQ0ksbUJBQUE7RUFDQSxvQkFBQTtFQUNBLDZDQUFBO0VBQ0EsMkNBQUE7QUNDSjs7QURFQTtFQUNJLDZDQUFBO0VBQ0EsOEJBQUE7RUFDQSwrQkFBQTtBQ0NKOztBRENBO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUNFSjs7QURBQTtFQUNJLGtCQUFBO0VBQ0EsZUFBQTtBQ0dKOztBREFBO0VBQ0ksYUFBQTtFQUNBLFlBQUE7QUNHSjs7QUREQztFQUNHLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxRQUFBO0FDSUo7O0FERkc7RUFDQyxrQkFBQTtBQ0tKIiwiZmlsZSI6ImhvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiIFxyXG4ucmFkdXM1e1xyXG4gICAgYm9yZGVyLXJhZGl1czogNCU7XHJcbn1cclxuXHJcbi5ib3JkZXJsaWdodHtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IC41cHg7XHJcbiAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XHJcbn1cclxuXHJcbi5iYWRnZXtcclxuICAgIHBhZGRpbmctdG9wOiA0cHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNXB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogMTNweDtcclxuICAgIHBhZGRpbmctbGVmdDogMTRweDtcclxufVxyXG5cclxuLm1ndDEwe1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxufVxyXG5cclxuLnBhZGRpbmc1e1xyXG5wYWRkaW5nLXRvcDogNXB4O1xyXG59XHJcbi0taW9uLXBhZGRpbmd7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IHVuc2V0O1xyXG4gICAgcGFkZGluZy1yaWdodDogdW5zZXQ7XHJcbiAgICBwYWRkaW5nLWlubGluZS1zdGFydDogdmFyKC0taW9uLXBhZGRpbmcsIDlweCk7XHJcbiAgICBwYWRkaW5nLWlubGluZS1lbmQ6IHZhcigtLWlvbi1wYWRkaW5nLCA5cHgpO1xyXG59XHJcblxyXG4udGltZXJjb2x7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtdGludCk7XHJcbiAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA5cHg7XHJcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogOXB4O1xyXG59XHJcbi5odGV4dHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6IDNweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDFweDtcclxufVxyXG4uaG5vbXtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6IDFweDtcclxufVxyXG5cclxuLmltZ3tcclxuICAgIGhlaWdodDogMTM1cHg7XHJcbiAgICB3aWR0aDogMTUzcHg7XHJcbn1cclxuIC5TdGF0dXN7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICByaWdodDogM3B4O1xyXG4gICAgdG9wOiAzcHg7XHJcbiAgIH1cclxuICAgLnBvc3tcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgfVxyXG5cclxuIFxyXG5cclxuIiwiLnJhZHVzNSB7XG4gIGJvcmRlci1yYWRpdXM6IDQlO1xufVxuXG4uYm9yZGVybGlnaHQge1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBib3JkZXItd2lkdGg6IDAuNXB4O1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XG59XG5cbi5iYWRnZSB7XG4gIHBhZGRpbmctdG9wOiA0cHg7XG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDEzcHg7XG4gIHBhZGRpbmctbGVmdDogMTRweDtcbn1cblxuLm1ndDEwIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLnBhZGRpbmc1IHtcbiAgcGFkZGluZy10b3A6IDVweDtcbn1cblxuLS1pb24tcGFkZGluZyB7XG4gIHBhZGRpbmctbGVmdDogdW5zZXQ7XG4gIHBhZGRpbmctcmlnaHQ6IHVuc2V0O1xuICBwYWRkaW5nLWlubGluZS1zdGFydDogdmFyKC0taW9uLXBhZGRpbmcsIDlweCk7XG4gIHBhZGRpbmctaW5saW5lLWVuZDogdmFyKC0taW9uLXBhZGRpbmcsIDlweCk7XG59XG5cbi50aW1lcmNvbCB7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC10aW50KTtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogOXB4O1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogOXB4O1xufVxuXG4uaHRleHQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDNweDtcbiAgbWFyZ2luLWJvdHRvbTogMXB4O1xufVxuXG4uaG5vbSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogMXB4O1xufVxuXG4uaW1nIHtcbiAgaGVpZ2h0OiAxMzVweDtcbiAgd2lkdGg6IDE1M3B4O1xufVxuXG4uU3RhdHVzIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBmbG9hdDogcmlnaHQ7XG4gIHJpZ2h0OiAzcHg7XG4gIHRvcDogM3B4O1xufVxuXG4ucG9zIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufSJdfQ== */";

/***/ }),

/***/ 3853:
/*!************************************************!*\
  !*** ./src/app/home/home.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar dir=\"rtl\">\n    <ion-title>\n      <ion-icon name=\"home-outline\"></ion-icon>\n      الرئيسية\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid> \n    <ion-row class=\"ion-margin-top ion-justify-content-center\">\n      <!-- <ion-col size=\"10\" class=\"ion-text-center\">\n        <ion-chip>\n          <ion-icon color= \"dark\" name=\"chevron-down\"></ion-icon> \n          <ion-label>الحالة</ion-label>\n        </ion-chip>  \n        <ion-chip>\n          <ion-icon  color= \"dark\" name=\"chevron-down\"></ion-icon> \n          <ion-label>التصنيف</ion-label>\n        </ion-chip>\n        <ion-chip>\n          <ion-icon  color= \"dark\" name=\"chevron-down\"></ion-icon> \n          <ion-label>الدولة</ion-label>\n        </ion-chip>\n      </ion-col> -->\n       \n       \n      <!-- <ion-slides  [options]=\"slideOpts\">\n        <ion-slide (click)=\"options()\">\n          <ion-select value=\"brown\" okText=\"موافق\" cancelText=\"إلغاء\" [multiple]=\"true\">\n            <ion-select-option>\n              بدون\n            </ion-select-option>\n            <ion-select-option>\n              إلكترويات\n            </ion-select-option>\n            <ion-select-option>\n              عقارات\n            </ion-select-option>\n            <ion-select-option>\n              رحلات سياحة\n            </ion-select-option>\n            <ion-select-option>\n              أخري\n            </ion-select-option>\n          </ion-select>\n\n         \n         \n        </ion-slide>\n        <ion-slide>\n          <ion-select value=\"dark\" okText=\"موافق\" cancelText=\"إلغاء\">\n            <ion-select-option>\n              مزاد قادم\n            </ion-select-option>\n            <ion-select-option>\n              مزاد جاري\n            </ion-select-option>\n            <ion-select-option>\n              مزاد منتهي\n            </ion-select-option> \n          </ion-select>\n         \n        </ion-slide>\n       <ion-slide>\n          <ion-select value=\"yall\" okText=\"موافق\" cancelText=\"إلغاء\" [multiple]=\"true\">\n            <ion-select-option>\n              بدون\n            </ion-select-option>\n            <ion-select-option>\n              إلكترويات\n            </ion-select-option>\n            <ion-select-option>\n              عقارات\n            </ion-select-option>\n            <ion-select-option>\n              رحلات سياحة\n            </ion-select-option>\n            <ion-select-option>\n              أخري\n            </ion-select-option>\n          </ion-select>\n          \n        </ion-slide>  \n      </ion-slides> -->\n     \n    </ion-row>\n</ion-grid>\n<!-- \n  <ion-icon name=\"chevron-down-outline\"></ion-icon>\n  filter grid -->\n<ion-grid *ngIf=\"errorLoad == true\" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n</ion-grid>\n\n<ion-grid *ngIf=\"!auctionsArray && errorLoad == false\"  class=\"custGrid\"> \n  <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n    <ion-col size=\"12\" class=\"ion-text-center\">\n      <!-- *ngIf=\"spinner == true\" -->\n      <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n    </ion-col>\n    <ion-col size=\"12\">\n      <!-- *ngIf=\"spinner == true\" --> \n    </ion-col>\n  </ion-row> \n</ion-grid>\n\n<ion-grid > \n  <ion-row class=\"ion-padding\">\n    <ion-col *ngFor=\"let auct of auctionsArray ; let i = index\" size=\"12\" class=\"radus5 borderlight w100 mgt10\">\n      <ion-grid class=\"ion-no-padding\" dir=\"rtl\"> \n        <ion-row>\n          <ion-item class=\"w100\" lines=\"none\"> \n            <ion-badge *ngIf=\"auct.currentStatus == 1\" color=\"warning\" slot=\"end\" class=\"badge\">\n            <ion-text> مزاد قادم</ion-text> \n              <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n            </ion-badge>\n            <ion-badge *ngIf=\"auct.currentStatus == 3\" color=\"light\" slot=\"end\" class=\"badge\">\n              <ion-text> مزاد منتهي </ion-text> \n                <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n              </ion-badge>\n              <ion-badge *ngIf=\"auct.currentStatus == 2\" color=\"success\" slot=\"end\" class=\"badge\">\n                <ion-text> مزاد جاري</ion-text> \n                  <ion-icon slot=\"end\" name=\"ellipse\" color=\"danger\"></ion-icon> \n              </ion-badge>\n            <ion-label>{{auct.title}}</ion-label>\n          </ion-item>\n        </ion-row>\n      \n        <ion-row>\n          <ion-col size=\"6\" class=\"pos\">\n                 <div class=\"Status\" *ngIf=\"auct.userIn\" >\n                  <ion-badge color=\"light\">\n                    <ion-icon color=\"success\" name=\"ribbon-outline\"></ion-icon>\n                    <ion-text> مشارك   </ion-text>\n                  </ion-badge> \n                 </div>\n                 <div class=\"Status\"  *ngIf=\"auct.userWin\">\n                  <ion-badge color=\"light\">\n                    <ion-icon name=\"ribbon-outline\" color=\"warning\"></ion-icon>\n                    <ion-text> فائز   </ion-text>\n                  </ion-badge> \n                 </div>\n                 <div class=\"Status\" *ngIf=\"auct.userOut\">\n                  <ion-badge color=\"light\">\n                    <ion-icon name=\"ribbon-outline\" color=\"danger\"></ion-icon>\n                    <ion-text> ملغي   </ion-text>\n                  </ion-badge> \n                 </div>\n                <img class=\"radus5 img\" [src]=\"auct.imgs[0]\"/>  \n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-grid   dir =\"rtl\" class=\"ion-no-padding\"> \n              <ion-row  class=\"ion-margin\" class=\"mgt10 ion-justify-content-center\">\n                <ion-label> \n                  <ion-text color=\"primary\"><b> يبدأ من :</b></ion-text>\n                  <ion-text> {{auct.productPrice - (0.3 * auct.productPrice)}} </ion-text> \n                </ion-label> \n              </ion-row> \n              <ion-row  class=\"ion-margin\" class=\"mgt10 ion-justify-content-center\">\n                <ion-label> \n                  <ion-text color=\"primary\"><b>العربون :</b></ion-text>\n                  <ion-text> {{auct.deposit}} </ion-text> \n                </ion-label> \n              </ion-row> \n              <ion-row class=\"mgt10 ion-justify-content-center\">\n                <ion-label> \n                  <!-- <ion-text color=\"primary\"><b> التاريخ : </b></ion-text>  -->\n                  <ion-text> {{auct.start | date:'EEE dd-MM-yyyy' : undefined  : 'ar'}} </ion-text>\n                  <!-- <ion-text> {{auct.start | date:'EEE dd-MM'}} </ion-text> -->\n                </ion-label>\n                <ion-label class=\"ion-text-center padding5\" dir=\"rtl\">\n                  <ion-text color=\"medium\" >{{auct.start | date:'hh:mm a': undefined  : 'ar'}}</ion-text>\n                 </ion-label>\n              </ion-row>\n              <ion-row   class=\"mgt10 ion-justify-content-center\">\n                <ion-label> \n                  <ion-text color=\"primary\"><b>المدة :</b>  </ion-text>\n                  <ion-text>  {{auct.duration}} </ion-text>\n                </ion-label> \n              </ion-row>\n            </ion-grid> \n          </ion-col>\n        </ion-row>\n\n        <ion-row *ngIf=\"auctionsArray[i].timeLeft | async as tm\">\n          <ion-col size=\"6\" class=\"timercol\">\n            <h6 class=\"htext\">\n              <ion-text>يوم : </ion-text>\n              <ion-text>ساعة : </ion-text>\n              <ion-text>دقيقة : </ion-text>\n              <ion-text>ثانية </ion-text>\n            </h6>\n            <h6 class=\"hnom\">\n              <ion-text color=\"primary\">\n                <b *ngIf=\"auct.currentStatus < 3 \">{{tm['da']}} :</b> \n                <b *ngIf=\"auct.currentStatus == 3\">00 :</b> \n              </ion-text>\n              <ion-text color=\"primary\">\n                <b *ngIf=\"auct.currentStatus < 3 \">{{tm['hr']}} :</b> \n                <b *ngIf=\"auct.currentStatus == 3 \">00 :</b> \n              </ion-text>\n              <ion-text color=\"primary\">\n                <b *ngIf=\"auct.currentStatus < 3 \">{{tm['mn']}} :</b> \n                <b *ngIf=\"auct.currentStatus == 3 \">00 :</b> \n              </ion-text>\n              <ion-text color=\"primary\">\n                <b *ngIf=\"auct.currentStatus < 3 \">{{tm['sc']}}</b>\n                <b *ngIf=\"auct.currentStatus == 3 \">00</b>\n               </ion-text>\n            </h6>\n          </ion-col>\n\n        </ion-row>\n\n        <ion-row  class=\"ion-margin-top\" dir=\"rtl\">\n          <ion-col size=\"4\">\n            <ion-item class=\"w100\" lines=\"none\">\n            <!-- <ion-button  fill=\"clear\" size=\"small\">\n              <b><ion-icon name=\"share-social\" color=\"primary\" style=\"font-size: 22px;\"></ion-icon></b>\n            </ion-button> -->\n          </ion-item>\n          </ion-col>\n          <ion-col size=\"4\">\n            <ion-button expand=\"block\" (click)=\"mazdDetails(auct)\">\n               <h5><b>التفاصيل</b></h5>\n            </ion-button>\n          </ion-col>\n        </ion-row>\n\n        </ion-grid>\n    </ion-col> \n  </ion-row>\n</ion-grid>\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_home_home_module_ts.js.map