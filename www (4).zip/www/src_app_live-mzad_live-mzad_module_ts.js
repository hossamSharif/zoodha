"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_live-mzad_live-mzad_module_ts"],{

/***/ 5360:
/*!*******************************************************!*\
  !*** ./src/app/live-mzad/live-mzad-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LiveMzadPageRoutingModule": () => (/* binding */ LiveMzadPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _live_mzad_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./live-mzad.page */ 3408);




const routes = [
    {
        path: '',
        component: _live_mzad_page__WEBPACK_IMPORTED_MODULE_0__.LiveMzadPage
    }
];
let LiveMzadPageRoutingModule = class LiveMzadPageRoutingModule {
};
LiveMzadPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LiveMzadPageRoutingModule);



/***/ }),

/***/ 8561:
/*!***********************************************!*\
  !*** ./src/app/live-mzad/live-mzad.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LiveMzadPageModule": () => (/* binding */ LiveMzadPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _pipes_date_ago_pipe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../pipes/date-ago.pipe */ 742);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _live_mzad_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./live-mzad-routing.module */ 5360);
/* harmony import */ var _live_mzad_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./live-mzad.page */ 3408);








let LiveMzadPageModule = class LiveMzadPageModule {
};
LiveMzadPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _live_mzad_routing_module__WEBPACK_IMPORTED_MODULE_1__.LiveMzadPageRoutingModule
        ],
        declarations: [_live_mzad_page__WEBPACK_IMPORTED_MODULE_2__.LiveMzadPage, _pipes_date_ago_pipe__WEBPACK_IMPORTED_MODULE_0__.DateAgoPipe],
        exports: [_pipes_date_ago_pipe__WEBPACK_IMPORTED_MODULE_0__.DateAgoPipe]
    })
], LiveMzadPageModule);



/***/ }),

/***/ 3408:
/*!*********************************************!*\
  !*** ./src/app/live-mzad/live-mzad.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LiveMzadPage": () => (/* binding */ LiveMzadPage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _live_mzad_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./live-mzad.page.html?ngResource */ 7443);
/* harmony import */ var _live_mzad_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./live-mzad.page.scss?ngResource */ 8997);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 2378);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/socket-service.service */ 905);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ 6908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! moment-timezone */ 2469);
/* harmony import */ var moment_timezone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment_timezone__WEBPACK_IMPORTED_MODULE_5__);












let LiveMzadPage = class LiveMzadPage {
  //time$ = timer(0, 1000).pipe(map(() => new Date()));
  constructor(alertController, api, socket, route, loadingController, toast, actionSheetCtl, datePipe, rout, modalController) {
    this.alertController = alertController;
    this.api = api;
    this.socket = socket;
    this.route = route;
    this.loadingController = loadingController;
    this.toast = toast;
    this.actionSheetCtl = actionSheetCtl;
    this.datePipe = datePipe;
    this.rout = rout;
    this.modalController = modalController;
    this.showMore = false;
    this.emptyLog = false;
    this.errorLoad = false;
    this.roundsMode = true;
    this.availRounds = 0;
    this.highestBidd = 0;
    this.lastBidd4U = 0;
    this.timeLeft = {
      da: "",
      hr: "",
      mn: "",
      sc: ""
    };
    this.showMe = false;
    this.users = [];
    this.usersLogs = [];
    this.termsArr = [];
    this.showError = false;
    this.msgError = "";
    this.route.queryParams.subscribe(params => {
      console.log('params', params);

      if (params && params.id) {
        this.USER_INFO = JSON.parse(params.user_info);
        this.auction_id = JSON.parse(params.id);
        console.log(this.auction_id);
        this.getAuction();
      }
    });
  }

  tirmString(string, length) {
    return string.substring(0, length) + '...';
  }

  ngOnInit() {
    //notify other when some how join live stream 
    this.socket.userJoinedAuction().subscribe(UserHadJoined => {
      console.log(UserHadJoined);

      if (UserHadJoined.length > 0) {
        this.presentToast(UserHadJoined[1] + "  إنضم", 'success'); //change user status from offline to online 
      }
    }); //notify other when some how add bidding (listing)

    this.socket.userBiddedInAuction().subscribe(logArr => {
      if (logArr.length > 0) {
        console.log('jahsja', logArr);
        this.mzd['logs'].push(logArr[0][0]);
        this.prepareAuc();
        this.presentToast(logArr[1].firstName + " " + logArr[0][0].pay, 'success');
      }
    }); //notify other when some how fucos input and start writting bid price (listing)

    this.socket.userFucosedBiddedInAuction().subscribe(logArr => {
      console.log(logArr);

      if (logArr.length > 0) {// this.presentToast(logArr[0].firstName  ,'success') 
      }
    }); //notify other when some how fucos input and start writting bid price (listing)

    this.socket.userFucosedLostBiddedInAuction().subscribe(logArr => {
      console.log(logArr);

      if (logArr.length > 0) {// this.presentToast(logArr[0].firstName  ,'danger') 
      }
    });
  }

  ionViewDidEnter() {
    ////  
    this.socket.auctionEndOntime().subscribe(ar => {
      console.log('here im', ar); // this.presentToast('holla  auction end on time ' ,'success') 

      if (ar.length > 0) {
        //this.presentToast('holla  auction end on time ' ,'success')
        this.onEndAuction(ar[1], ar[2]);
      }
    });
  }

  reload() {
    this.errorLoad = false;
    this.mzd = undefined;
    this.getAuction();
  }

  handleError(err) {
    this.errorLoad = true; // if (err.error == "No user with this phone found") {
    //   console.log('no user was found') 
    // // this.getsms('new',err) // uncomment it after apply smsgetway 
    // // this.getVirfyCode('new' , err) // comment it after apply smsgetway 
    // }else if(err.error == "another phone"){
    //   // to apply imei check uncmment the line in zoodohapi/controller/user.j function : loginPhone
    //   this.presentToast('seem you use another phone','danger') 
    // } else{ 
    //   this.presentToast('حدث خطأ ما ,حاول مرة اخري','danger')
    //   console.log(err.kind)
    // }
  }

  getAuction() {
    this.api.getAuction(this.auction_id).subscribe(data => {
      console.log(data);
      let res = data['auction'][0][0];
      this.mzd = data['auction'][0][0];
      this.users = data['auction'][1];
      console.log('im here baby', this.mzd, 'users', this.users);
      this.prepareAuc();
    }, err => {
      this.handleError(err.error.error);
      console.log(err);
    });
  }

  prepareAuc() {
    this.timeLeft = this.endAfterounter(); //ordering log depend on date desc
    // this.mzd['logs']=this.mzd['logs'].sort((x, y) => +new Date(x.time) > +new Date(y.time));

    if (this.mzd['logs'].length > 0) {
      this.emptyLog = false;
      this.mzd['logs'] = this.mzd['logs'].sort(function (a, b) {
        var dateA = new Date(a.time);
        var dateB = new Date(b.time);
        return dateA < dateB ? 1 : -1; // ? -1 : 1 for ascending/increasing order
      });
      console.log('sorting', this.mzd['logs']); //view time قبل دقيقتين 
      //use dateAgo pipe
      //get heigt price

      this.highestBidd = this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0);
      console.log('highestBidd', this.highestBidd); //  last bidd for you

      let flt = [];
      flt = this.mzd['logs'].filter(x => x._id == this.USER_INFO._id);

      if (flt.length > 0) {
        this.lastBidd4U = flt[0].pay;
        console.log('pay', this.lastBidd4U);
      } else {
        this.lastBidd4U = 0;
      } // prepare users Log


      console.log('prepare users Log', this.mzd['logs'].length);

      if (this.mzd['logs'].length > 2) {
        console.log('less');
        this.getUserinfoLog('less');
      } else {
        console.log('more');
        this.getUserinfoLog('more');
      }
    } else {
      this.emptyLog = true;
    } // prepare terms 


    if (this.mzd['terms'].length > 2) {
      this.getTerms('less');
    } else {
      this.getTerms('more');
    } // rounds preabare


    this.availRounds = this.mzd['rounds'];
    let flt = [];

    if (this.mzd['logs'].length > 0) {
      flt = this.mzd['logs'].filter(x => x.userId == this.USER_INFO._id);
      this.availRounds = this.mzd['rounds'] - +flt.length;
      console.log('rounds preabare', this.mzd['rounds'], flt.length);
      console.log('rounds preabare', this.usersLogs);
    }
  }

  onEndAuction(winnerId, orderId) {
    if (winnerId == this.USER_INFO._id) {
      this.presentAlert('winner', winnerId, orderId);
    } else {
      this.presentAlert();
    }
  }

  presentAlert(stat, winId, orderId) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let msg = "";
      let subHeader = "";
      let header = "";
      let btns = [];

      if (stat == 'winner') {
        subHeader = 'مبروووك ';
        msg = 'لقد ربحت المزاد , اضغط علي متابعة الطلب ';
        btns = [{
          text: 'متابعة الطلب',
          role: 'orders',
          handler: () => {
            _this.goToOrderDetails(orderId);
          }
        }];
      } else {
        subHeader = 'لم تربح المزاد  ';
        msg = 'حظا موفقا في المرة القادمة';
        btns = [{
          text: 'الرئيسية',
          role: 'home',
          handler: () => {
            _this.goHome();
          }
        }];
      }

      const alert = yield _this.alertController.create({
        header: 'تنبيه',
        subHeader: subHeader,
        message: msg,
        mode: 'ios',
        buttons: btns,
        backdropDismiss: false
      });
      yield alert.present();
      const {
        role
      } = yield alert.onDidDismiss(); //  this.roleMessage = `Dismissed with role: ${role}`;
    })();
  }

  goToOrderDetails(orederId) {
    let navigationExtras = {
      queryParams: {
        id: JSON.stringify(orederId),
        user_info: JSON.stringify(this.USER_INFO)
      }
    };
    this.alertController.dismiss();
    this.rout.navigate(['order-details'], navigationExtras);
  }

  goHome() {
    this.rout.navigate(['tabs/home']);
  }

  getUserinfoLog(moreOrLess) {
    let length;

    if (moreOrLess == 'less') {
      length = 2;
      this.view = 0;
    } else if (moreOrLess == 'more') {
      length = this.mzd['logs'].length;
      this.view = 1;
    } else {
      length = this.mzd['logs'].length;
      this.view = 3;
    }

    console.log('length', length);
    this.usersLogs = [];

    for (let index = 0; index < length; index++) {
      const element = this.mzd['logs'][index];
      console.log('element', element);
      let flt = [];
      flt = this.users.filter(x => x._id == element.userId);

      if (flt.length > 0) {
        this.usersLogs.push({
          "userId": element.userId,
          "time": element.time,
          "pay": +element.pay,
          "lastHighestPay": +element.lastHighestPay,
          "userName": flt[0]['userName']
        });
      }
    } // this.view = 0  
    // this.mzd['logs'].forEach(element => {
    //    let flt =  this.users.filter(x=>x._id == element.userId)[0].userName
    //    this.usersLogs.push({
    //       "userId": element.userId ,
    //       "time":  element.time,
    //       "pay" : +element.pay,
    //       "lastHighestPay": +element.lastHighestPay,
    //       "userName" : flt 
    //    })
    // }); 

  }

  getTerms(moreOrLess) {
    let length;

    if (moreOrLess == 'less') {
      length = 2;
      this.viewTerms = 0;
    } else if (moreOrLess == 'more') {
      length = this.mzd['terms'].length;
      this.viewTerms = 1;
    } else {
      length = this.mzd['terms'].length;
      this.viewTerms = 3;
    }

    this.termsArr = [];

    for (let index = 0; index < length; index++) {
      const element = this.mzd['terms'][index];
      console.log('element', element);
      this.termsArr.push(element);
    }
  }

  viewMoreLess() {
    console.log(this.view);

    if (this.view == 0) {
      this.getUserinfoLog('more');
      this.view = 1;
    } else {
      this.getUserinfoLog('less');
      this.view = 0;
    }
  }

  viewMoreLessTerms() {
    console.log(this.view);

    if (this.viewTerms == 0) {
      this.getTerms('more');
      this.viewTerms = 1;
    } else {
      this.getTerms('less');
      this.viewTerms = 0;
    }
  }

  startAfterounter(startDate) {
    setInterval(function () {
      const timeLeft = moment__WEBPACK_IMPORTED_MODULE_4__.duration(moment__WEBPACK_IMPORTED_MODULE_4__(startDate).diff(moment__WEBPACK_IMPORTED_MODULE_4__())); // get difference between now and timestamp

      console.log('days', timeLeft.days(), 'hours', timeLeft.hours(), 'min', timeLeft.minutes(), 'econd', timeLeft.seconds());
      return timeLeft;
    }, 1000);
  }

  endAfterounter() {
    let offset = moment_timezone__WEBPACK_IMPORTED_MODULE_5__().utcOffset();
    let newDate = moment__WEBPACK_IMPORTED_MODULE_4__(this.mzd['end']).add();
    console.log('init', this.mzd['end'], 'sdfs', offset, 'newDate', moment__WEBPACK_IMPORTED_MODULE_4__(newDate).format('YYYY-MM-DDTHH:mm:ss.SSSSZ'));
    return new rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable(observer => {
      setInterval(() => observer.next({
        da: this.memnto(newDate).days().toString(),
        hr: this.memnto(newDate).hours().toString(),
        mn: this.memnto(newDate).minutes().toString(),
        sc: this.memnto(newDate).seconds().toString()
      }), 1000);
    });
  }

  memnto(newDate) {
    return moment__WEBPACK_IMPORTED_MODULE_4__.duration(moment__WEBPACK_IMPORTED_MODULE_4__(newDate).diff(moment__WEBPACK_IMPORTED_MODULE_4__()));
  }

  validationPrice(type) {
    let h = this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0); // not more than oppenning price 

    if (this.availRounds == 0) {
      if (type == 'btn') {
        this.showError = true;
        this.msgError = 'انتهي عدد محاولاتك';
      } else {
        this.presentToast('انتهي عدد محاولاتك', 'danger');
        return true;
      }
    } else if (this.bidPrice <= this.mzd['productPrice'] - 0.3 * this.mzd['productPrice']) {
      if (type == 'btn') {
        this.showError = true;
        this.msgError = 'أقل من السعر الإفتتاحي';
      } else {
        this.presentToast('يحب المزايدة باعلي من السعر الإفتتاحي', 'danger');
        return true;
      }
    } else if (this.bidPrice <= h) {
      // not  more than hhiiest bid 
      if (type == 'btn') {
        this.showError = true;
        this.msgError = 'اقل من المطلوب';
      } else {
        this.presentToast('المبلغ اقل من المطلوب', 'danger');
        this.presentToast('', 'danger');
        return false;
      }
    } else if (this.bidPrice >= this.mzd['productPrice']) {
      // not more than product price
      if (type == 'btn') {
        this.showError = true;
        this.msgError = 'اعلي من سعر المنتج';
      } else {
        this.presentToast('المبلغ اعلي من سعر المنتج', 'danger');
        return false;
      }
    } else {
      if (type == 'btn') {
        this.showError = false;
      } else {
        return true;
      }
    }
  }

  bidChange(ev) {
    console.log(ev);
    this.validationPrice('btn');
  }

  increase(bidPrice) {
    this.validationPrice('btn');
    let h = this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0);

    if (bidPrice) {
      this.bidPrice = this.bidPrice + 1;
    } else {
      this.bidPrice = h + 1;
    }
  }

  decrease(bidPrice) {
    this.validationPrice('btn');
    let h = this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0);

    if (bidPrice) {
      this.bidPrice = this.bidPrice - 1;
    } else {
      this.bidPrice = h;
    }
  }

  focusBidding(ev) {
    let h = this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0);
    console.log(ev.target.value, 'h', h);

    if (h == 0 && ev.target.value == 0) {
      this.bidPrice = +this.mzd['productPrice'] - 0.3 * +this.mzd['productPrice'] + 1;
    } else {
      if (ev.target.value > 0) {
        this.bidPrice = this.bidPrice + 1;
      } else {
        this.bidPrice = h + 1;
      }
    }

    this.socket.userFucosBiddingInAuction([this.USER_INFO, this.mzd._id]);
  }

  unCheckFocus() {
    console.log('unCheckFocus');
    this.socket.userFucosLostBiddingInAuction([this.USER_INFO, this.mzd._id]); //  show indicator loader jst like typing...  
  }

  endAuction() {
    let arr = {
      _id: this.mzd['_id'],
      auction: this.mzd
    };
    console.log('auction', arr);
    this.api.endAuctionOntime(arr).subscribe(data => {
      console.log('auction update', data); // نهاي المزاد دالة في الباكند بتنهي المزاد 
      // وتعمل بوش نوتيف بإستخدام السوكيت لكل المساخدمين المتصيلين 
      // push notif for offline users of auction 
      //صفحة اللايف ح تستقبل الأوردور من الباكند وتظهر رسالة للمستخدمين 
      //  خاصة رسالة الفائز  تقوم بتوجيه الي صفحة الطلبات 
      // يتحول المزاد للصفحة الأوردرات
      // صفحة الأوردرات تعامل معاملة السلة 
      // تبرمج بإستخدام behavior subject 
    }, err => {
      console.log(err);
    });
  }

  bidding() {
    if (this.validationPrice('submit') == true) {
      let arr = {
        _id: this.mzd['_id'],
        log: [{
          "userId": this.USER_INFO._id,
          "time": new Date(),
          "pay": +this.bidPrice,
          "lastHighestPay": this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0)
        }]
      }; // let arr  = { 
      //   _id : this.mzd['_id'] ,
      //   users :[{
      //     "userId":"736fc6299c3a4269ace43b7641014af2",
      //     "status":1
      //    },
      //    {
      //     "userId":"700865bcaa934e5ebe956a2013c33395",
      //     "status":1
      //    },
      //    {
      //     "userId":"88a8ff31502e4ad5b43152a4befa4756" ,
      //     "status":1
      //    } ] 
      // }

      this.api.updateAuctionsLog(arr).subscribe(data => {
        console.log('auction update', data);
        this.mzd = data['updatedLogAuction'];
        console.log(this.mzd); // update log and hiegst price and

        this.prepareAuc(); // animate heighst price and hand bidding

        this.animateLogAndprice(); //alert others by new price using socket.io for room

        this.prepareBidding(); // let res = data['auction'][0]
        // this.mzad = res
        // console.log('im here baby',this.mzad)
      }, err => {
        console.log(err);
        this.handelErrorBiding(err.error.error);
      }); // 
      // add record to log 
      // animate input and highest bidding price
      // it done by addedd animation classes
      //show alert for other users using sockit 
      // it done by subiscribe  in ng on it  
    }
  }

  handelErrorBiding(err) {
    // if (err.error == "No user with this phone found") {
    //     console.log('no user was found')  
    //   } else if (err.error == "another phone") { 
    //     this.presentToast('seem you use another phone','danger') 
    //   } else { 
    //     this.presentToast('حدث خطأ ما ,حاول مرة اخري','danger')
    //     console.log(err.kind)
    //   } 
    this.presentToast('حدث خطأ ما ,حاول مرة اخري', 'danger');
  }

  prepareBidding() {
    let log = [{
      "userId": this.USER_INFO._id,
      "time": new Date(),
      "pay": +this.bidPrice,
      "lastHighestPay": this.mzd['logs'].reduce((acc, shot) => acc = acc > shot.pay ? acc : shot.pay, 0)
    }];
    this.socket.userBiddingInAuction([log, this.USER_INFO, this.mzd._id]);
  }

  animateLogAndprice() {
    this.showMe = true;
    setTimeout(() => {
      this.showMe = false;
    }, 3000);
  }

  presentToast(msg, color) {
    var _this2 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this2.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  } //extra fuction


  getOffsetUtc() {
    let time = moment_timezone__WEBPACK_IMPORTED_MODULE_5__().tz('Africa/Cairo').format('HH:mm:ss z');
    let off = moment_timezone__WEBPACK_IMPORTED_MODULE_5__(new Date()).utcOffset();
    let local = moment_timezone__WEBPACK_IMPORTED_MODULE_5__.tz.guess(this.mzd['end']);
    console.log('time', time, 'offset', off, 'local', local);
  }

  updateAuction() {
    // let st : Date = new Date('2022-11-11T21:35:03.976+00:00')
    // let en : Date = new Date('2022-11-11T21:35:03.976+00:00')
    // this.mzd[0].descr = '7ghutyasdadas'
    // this.mzd[0].fee = 19990000
    // this.mzd[0].start = st
    // this.mzd[0].end = en
    // this.mzd[0].logs.push({
    //  "price":123123,
    //  "userId":"kejrhoqieurhoq",
    //  "date":en
    // })
    this.api.updateAuctions(this.mzd[0]).subscribe(data => {
      console.log('auction update', data);
      this.mzd = data['updatedLogAuction'];
      console.log(this.mzd); // update log and hiegst price and
      // animate heighst price and hand bidding
      //alert others by new price using socket.io for room
      // let res = data['auction'][0]
      // this.mzad = res
      // console.log('im here baby',this.mzad)
    }, err => {
      console.log(err);
    });
  }

  updateTerms() {
    let arr = {
      _id: this.mzd['_id'],
      terms: [{
        "descr": "loakajskdfhdlak",
        "orderId": 1
      }, {
        "userId": "loakajskdfhdlak",
        "status": 2
      }, {
        "userId": "loakajskdfhdlak",
        "status": 1
      }]
    };
    this.api.updateAuctionsLog(arr).subscribe(data => {
      console.log('auction update', data); // this.mzd = data['updatedLogAuction']
      // console.log(this.mzd)
    });
  }

};

LiveMzadPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ActionSheetController
}, {
  type: _angular_common__WEBPACK_IMPORTED_MODULE_9__.DatePipe
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController
}];

LiveMzadPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
  selector: 'app-live-mzad',
  template: _live_mzad_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_live_mzad_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], LiveMzadPage);


/***/ }),

/***/ 742:
/*!****************************************!*\
  !*** ./src/app/pipes/date-ago.pipe.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DateAgoPipe": () => (/* binding */ DateAgoPipe)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! moment */ 6908);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);



moment__WEBPACK_IMPORTED_MODULE_0__.locale("ar"); // set your language
let DateAgoPipe = class DateAgoPipe {
    constructor(changeDetectorRef, ngZone) {
        this.changeDetectorRef = changeDetectorRef;
        this.ngZone = ngZone;
    }
    transform(value) {
        this.removeTimer();
        let d = new Date(value);
        let now = new Date();
        let seconds = Math.round(Math.abs((now.getTime() - d.getTime()) / 1000));
        let timeToUpdate = (Number.isNaN(seconds)) ? 1000 : this.getSecondsUntilUpdate(seconds) * 1000;
        this.timer = this.ngZone.runOutsideAngular(() => {
            if (typeof window !== 'undefined') {
                return window.setTimeout(() => {
                    this.ngZone.run(() => this.changeDetectorRef.markForCheck());
                }, timeToUpdate);
            }
            return null;
        });
        return moment__WEBPACK_IMPORTED_MODULE_0__(d).fromNow();
    }
    ngOnDestroy() {
        this.removeTimer();
    }
    removeTimer() {
        if (this.timer) {
            window.clearTimeout(this.timer);
            this.timer = null;
        }
    }
    getSecondsUntilUpdate(seconds) {
        let min = 60;
        let hr = min * 60;
        let day = hr * 24;
        if (seconds < min) { // less than 1 min, update every 2 secs
            return 2;
        }
        else if (seconds < hr) { // less than an hour, update every 30 secs
            return 30;
        }
        else if (seconds < day) { // less then a day, update every 5 mins
            return 300;
        }
        else { // update every hour
            return 3600;
        }
    }
};
DateAgoPipe.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.ChangeDetectorRef },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone }
];
DateAgoPipe = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Pipe)({
        name: 'dateAgo',
        pure: true
    })
], DateAgoPipe);



/***/ }),

/***/ 8997:
/*!**********************************************************!*\
  !*** ./src/app/live-mzad/live-mzad.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = ".borderlightbot {\n  border-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-light-shade);\n}\n\n.flex {\n  display: flex;\n}\n\n.borderbt {\n  border-bottom-style: solid;\n  border-bottom-width: 0.5px;\n}\n\n.pd10 {\n  padding-top: 10px;\n}\n\n.pb0 {\n  padding-bottom: 0px;\n}\n\n.imgContainer {\n  height: 200px;\n}\n\n.centerDiv {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.custH {\n  text-align: center;\n  width: 100%;\n}\n\n.lightItem {\n  --backgroun: var(--ion-color-light) ;\n}\n\n.white {\n  color: white;\n}\n\n.custGrid {\n  background-color: var(--ion-color-medium-shade);\n}\n\n.priceText {\n  color: white;\n  font-size: 16px;\n  font-weight: bold;\n}\n\n.po {\n  position: relative;\n}\n\n.fixGadegt {\n  position: absolute;\n  border-radius: 10px;\n  height: 80%;\n  display: grid;\n  justify-content: center;\n  align-items: center;\n}\n\n.colSpic {\n  margin-top: -50px;\n}\n\n.cardStatus {\n  position: absolute;\n  bottom: 0px;\n  background-image: linear-gradient(to right top, var(--ion-color-medium), var(--ion-color-light-shade));\n  border-radius: 10px;\n}\n\n.cardStatus2 {\n  width: 90%;\n  background-image: linear-gradient(to right top, var(--ion-color-medium), var(--ion-color-primary-shade));\n  border-radius: 10px;\n}\n\n.custImg {\n  width: 100%;\n  height: 100%;\n}\n\n.redBorder {\n  border-radius: 20px;\n  border-style: solid;\n  font-weight: bold;\n  text-align: center;\n  border-width: 0.5px;\n  border-color: var(--ion-color-danger);\n}\n\n.lightBorder {\n  border-color: var(--ion-color-light-shade);\n}\n\n.blueBorder {\n  border-radius: 20px;\n  border-style: solid;\n  font-weight: bold;\n  text-align: center;\n  border-width: 0.5px;\n  border-color: var(--ion-color-primary);\n}\n\n.childDiv {\n  position: relative;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.bidAnim {\n  position: fixed;\n  z-index: 1;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  top: 10%;\n  width: 100%;\n  opacity: 0.8;\n  height: 100%;\n}\n\n.animate__animated.animate__fadeOutUp {\n  --animate-duration: 2s;\n}\n\n.bidH {\n  width: 100%;\n  color: var(--ion-color-primary-contrast);\n  font-weight: bolder;\n  position: absolute;\n  top: 19%;\n  text-align: center;\n}\n\n.bidImg {\n  width: 100%;\n  height: 100%;\n}\n\n.paddind {\n  padding: 3px;\n}\n\n.bgc {\n  background-color: var(--ion-color-medium);\n}\n\n.timercol {\n  background-color: var(--ion-color-light-tint);\n  border-bottom-left-radius: 9px;\n  border-bottom-right-radius: 9px;\n}\n\n.footer {\n  border-style: solid;\n  border-width: 0.3px;\n  border-color: var(--ion-color-light-shade);\n  border-top-right-radius: 30px;\n  border-top-left-radius: 30px;\n}\n\n.custRow {\n  margin-top: 70%;\n  margin-left: 46%;\n}\n\n.footer-md::before {\n  background-image: none;\n}\n\n.totcol {\n  border-right-style: solid;\n  border-width: 0.5px;\n  border-color: var(--ion-color-light-shade);\n}\n\n.table {\n  text-align: center;\n  width: 100%;\n  margin: 12px;\n}\n\ntr:nth-child(even) {\n  background-color: #dddddd;\n}\n\ntd, th {\n  border: 1px solid #dddddd;\n  text-align: center;\n  padding: 8px;\n  font-size: 16px;\n  font-weight: bold;\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpdmUtbXphZC5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXGh1c2FtJTIwcHJvalxcem9vZG9oYVNkXFxzcmNcXGFwcFxcbGl2ZS1temFkXFxsaXZlLW16YWQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDBDQUFBO0FDQ0o7O0FEQ0E7RUFBTSxhQUFBO0FDR047O0FEREE7RUFDSSwwQkFBQTtFQUNBLDBCQUFBO0FDSUo7O0FEQUE7RUFDRSxpQkFBQTtBQ0dGOztBREFBO0VBQ0csbUJBQUE7QUNHSDs7QUREQTtFQUNJLGFBQUE7QUNJSjs7QUREQTtFQUNJLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FDSUo7O0FEREE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7QUNJSjs7QUREQTtFQUNBLG9DQUFBO0FDSUE7O0FEREE7RUFDSSxZQUFBO0FDSUo7O0FEQ0E7RUFDQywrQ0FBQTtBQ0VEOztBREdBO0VBQ0ksWUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQ0FKOztBREdBO0VBQ0ksa0JBQUE7QUNBSjs7QURJQTtFQUNJLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNESjs7QURJQTtFQUNJLGlCQUFBO0FDREo7O0FESUE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxzR0FBQTtFQUNBLG1CQUFBO0FDREo7O0FESUE7RUFHSSxVQUFBO0VBQ0Esd0dBQUE7RUFDQSxtQkFBQTtBQ0hKOztBRE1BO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNIQTs7QURRQTtFQUNJLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQ0FBQTtBQ0xKOztBRFFBO0VBRUksMENBQUE7QUNOSjs7QURTQTtFQUNJLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDRCxzQ0FBQTtBQ05IOztBRFdBO0VBQ0ksa0JBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ1JKOztBRFlBO0VBQ0ksZUFBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUVBLFFBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUNWSjs7QURhQTtFQUNJLHNCQUFBO0FDVko7O0FEYUE7RUFDSSxXQUFBO0VBQ0Esd0NBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLGtCQUFBO0FDVko7O0FEYUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQ1ZBOztBRGFBO0VBQ0ksWUFBQTtBQ1ZKOztBRGFBO0VBQ0kseUNBQUE7QUNWSjs7QURZQTtFQUNHLDZDQUFBO0VBQ0MsOEJBQUE7RUFDQSwrQkFBQTtBQ1RKOztBRFdBO0VBQ0ksbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDBDQUFBO0VBQ0EsNkJBQUE7RUFDQSw0QkFBQTtBQ1JKOztBRFlBO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0FDVEo7O0FEWUE7RUFDSSxzQkFBQTtBQ1RKOztBRFlBO0VBQ0kseUJBQUE7RUFDQSxtQkFBQTtFQUNBLDBDQUFBO0FDVEo7O0FEYUE7RUFBTyxrQkFBQTtFQUFtQixXQUFBO0VBQWEsWUFBQTtBQ1B2Qzs7QURTRTtFQUFvQix5QkFBQTtBQ0x0Qjs7QURPRTtFQUFRLHlCQUFBO0VBQTBCLGtCQUFBO0VBQW1CLFlBQUE7RUFBYyxlQUFBO0VBQWdCLGlCQUFBO0VBQWtCLFlBQUE7QUNFdkciLCJmaWxlIjoibGl2ZS1temFkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ib3JkZXJsaWdodGJvdHtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IC41cHg7XHJcbiAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XHJcbn1cclxuLmZsZXh7ZGlzcGxheTogZmxleDt9XHJcblxyXG4uYm9yZGVyYnR7XHJcbiAgICBib3JkZXItYm90dG9tLXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci1ib3R0b20td2lkdGg6IC41cHg7XHJcbiAgIFxyXG59XHJcblxyXG4ucGQxMHtcclxuICBwYWRkaW5nLXRvcDogMTBweDtcclxufVxyXG5cclxuLnBiMHtcclxuICAgcGFkZGluZy1ib3R0b206IDBweDtcclxufVxyXG4uaW1nQ29udGFpbmVye1xyXG4gICAgaGVpZ2h0OiAyMDBweDtcclxufVxyXG5cclxuLmNlbnRlckRpdiB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIH1cclxuXHJcbi5jdXN0SHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4ubGlnaHRJdGVte1xyXG4tLWJhY2tncm91biA6IHZhcigtLWlvbi1jb2xvci1saWdodClcclxufVxyXG5cclxuLndoaXRle1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG5cclxuXHJcbi5jdXN0R3JpZHtcclxuIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tc2hhZGUpO1xyXG59XHJcblxyXG5cclxuXHJcbi5wcmljZVRleHR7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG5cclxuLnBve1xyXG4gICAgcG9zaXRpb246cmVsYXRpdmU7ICBcclxufVxyXG5cclxuXHJcbi5maXhHYWRlZ3R7XHJcbiAgICBwb3NpdGlvbjphYnNvbHV0ZTsgXHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgaGVpZ2h0OiA4MCU7XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uY29sU3BpY3tcclxuICAgIG1hcmdpbi10b3A6IC01MHB4O1xyXG59XHJcblxyXG4uY2FyZFN0YXR1c3tcclxuICAgIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gICAgYm90dG9tOiAwcHg7IFxyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0IHRvcCwgdmFyKC0taW9uLWNvbG9yLW1lZGl1bSksIHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSkpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxufVxyXG5cclxuLmNhcmRTdGF0dXMye1xyXG4gICAgLy8gcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAvLyBib3R0b206IDBweDtcclxuICAgIHdpZHRoOiA5MCU7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQgdG9wLCB2YXIoLS1pb24tY29sb3ItbWVkaXVtKSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnktc2hhZGUpKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbn1cclxuXHJcbi5jdXN0SW1ne1xyXG53aWR0aDogMTAwJTtcclxuaGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG5cclxuXHJcbi5yZWRCb3JkZXJ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgYm9yZGVyLXN0eWxlOiBzb2xpZDsgXHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjsgXHJcbiAgICBib3JkZXItd2lkdGg6IDAuNXB4OyBcclxuICAgIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhbmdlcik7XHJcbn1cclxuXHJcbi5saWdodEJvcmRlcntcclxuICBcclxuICAgIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlKTtcclxufVxyXG5cclxuLmJsdWVCb3JkZXJ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgYm9yZGVyLXN0eWxlOiBzb2xpZDsgXHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjsgXHJcbiAgICBib3JkZXItd2lkdGg6IDAuNXB4OyBcclxuICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbn1cclxuXHJcblxyXG5cclxuLmNoaWxkRGl2e1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuXHJcbi5iaWRBbmlte1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgei1pbmRleDogMTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiAgY2VudGVyO1xyXG4gICAgLy9iYWNrZ3JvdW5kLWltYWdlOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQgdG9wLCB2YXIoLS1pb24tY29sb3ItbWVkaXVtKSwgdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlKSk7XHJcbiAgICB0b3A6IDEwJTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgb3BhY2l0eTogMC44O1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG59IFxyXG5cclxuLmFuaW1hdGVfX2FuaW1hdGVkLmFuaW1hdGVfX2ZhZGVPdXRVcHtcclxuICAgIC0tYW5pbWF0ZS1kdXJhdGlvbjogMnM7XHJcbn1cclxuXHJcbi5iaWRIe1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMTklO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uYmlkSW1ne1xyXG53aWR0aDogMTAwJTtcclxuaGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4ucGFkZGluZHtcclxuICAgIHBhZGRpbmc6IDNweDtcclxufVxyXG5cclxuLmJnY3tcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG59XHJcbi50aW1lcmNvbHtcclxuICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXRpbnQpO1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogOXB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDlweDtcclxufVxyXG4uZm9vdGVye1xyXG4gICAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuICAgIGJvcmRlci13aWR0aDogMC4zcHg7XHJcbiAgICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMzBweDtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDMwcHg7XHJcbn1cclxuXHJcbiBcclxuLmN1c3RSb3d7XHJcbiAgICBtYXJnaW4tdG9wOiA3MCU7XHJcbiAgICBtYXJnaW4tbGVmdDogNDYlO1xyXG59XHJcblxyXG4uZm9vdGVyLW1kOjpiZWZvcmV7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiAgbm9uZTtcclxufVxyXG5cclxuLnRvdGNvbHtcclxuICAgIGJvcmRlci1yaWdodC1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItd2lkdGg6IDAuNXB4O1xyXG4gICAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpO1xyXG59XHJcblxyXG5cclxuLnRhYmxle3RleHQtYWxpZ246IGNlbnRlcjt3aWR0aDogMTAwJTsgbWFyZ2luOiAxMnB4O31cclxuXHJcbiAgdHI6bnRoLWNoaWxkKGV2ZW4pIHtiYWNrZ3JvdW5kLWNvbG9yOiAjZGRkZGRkO31cclxuICBcclxuICB0ZCwgdGgge2JvcmRlcjogMXB4IHNvbGlkICNkZGRkZGQ7dGV4dC1hbGlnbjogY2VudGVyO3BhZGRpbmc6IDhweDsgZm9udC1zaXplOiAxNnB4O2ZvbnQtd2VpZ2h0OiBib2xkO2NvbG9yOiBibGFjazt9IiwiLmJvcmRlcmxpZ2h0Ym90IHtcbiAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcbiAgYm9yZGVyLXdpZHRoOiAwLjVweDtcbiAgYm9yZGVyLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpO1xufVxuXG4uZmxleCB7XG4gIGRpc3BsYXk6IGZsZXg7XG59XG5cbi5ib3JkZXJidCB7XG4gIGJvcmRlci1ib3R0b20tc3R5bGU6IHNvbGlkO1xuICBib3JkZXItYm90dG9tLXdpZHRoOiAwLjVweDtcbn1cblxuLnBkMTAge1xuICBwYWRkaW5nLXRvcDogMTBweDtcbn1cblxuLnBiMCB7XG4gIHBhZGRpbmctYm90dG9tOiAwcHg7XG59XG5cbi5pbWdDb250YWluZXIge1xuICBoZWlnaHQ6IDIwMHB4O1xufVxuXG4uY2VudGVyRGl2IHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5jdXN0SCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5saWdodEl0ZW0ge1xuICAtLWJhY2tncm91bjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KSA7XG59XG5cbi53aGl0ZSB7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmN1c3RHcmlkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XG59XG5cbi5wcmljZVRleHQge1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi5wbyB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLmZpeEdhZGVndCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgaGVpZ2h0OiA4MCU7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufVxuXG4uY29sU3BpYyB7XG4gIG1hcmdpbi10b3A6IC01MHB4O1xufVxuXG4uY2FyZFN0YXR1cyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAwcHg7XG4gIGJhY2tncm91bmQtaW1hZ2U6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCB0b3AsIHZhcigtLWlvbi1jb2xvci1tZWRpdW0pLCB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpKTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cblxuLmNhcmRTdGF0dXMyIHtcbiAgd2lkdGg6IDkwJTtcbiAgYmFja2dyb3VuZC1pbWFnZTogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0IHRvcCwgdmFyKC0taW9uLWNvbG9yLW1lZGl1bSksIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXNoYWRlKSk7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5cbi5jdXN0SW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLnJlZEJvcmRlciB7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gIGJvcmRlci1zdHlsZTogc29saWQ7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci13aWR0aDogMC41cHg7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhbmdlcik7XG59XG5cbi5saWdodEJvcmRlciB7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlKTtcbn1cblxuLmJsdWVCb3JkZXIge1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItd2lkdGg6IDAuNXB4O1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuLmNoaWxkRGl2IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmJpZEFuaW0ge1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIHotaW5kZXg6IDE7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICB0b3A6IDEwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIG9wYWNpdHk6IDAuODtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uYW5pbWF0ZV9fYW5pbWF0ZWQuYW5pbWF0ZV9fZmFkZU91dFVwIHtcbiAgLS1hbmltYXRlLWR1cmF0aW9uOiAycztcbn1cblxuLmJpZEgge1xuICB3aWR0aDogMTAwJTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcbiAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDE5JTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uYmlkSW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLnBhZGRpbmQge1xuICBwYWRkaW5nOiAzcHg7XG59XG5cbi5iZ2Mge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbn1cblxuLnRpbWVyY29sIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXRpbnQpO1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA5cHg7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA5cHg7XG59XG5cbi5mb290ZXIge1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBib3JkZXItd2lkdGg6IDAuM3B4O1xuICBib3JkZXItY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAzMHB4O1xuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAzMHB4O1xufVxuXG4uY3VzdFJvdyB7XG4gIG1hcmdpbi10b3A6IDcwJTtcbiAgbWFyZ2luLWxlZnQ6IDQ2JTtcbn1cblxuLmZvb3Rlci1tZDo6YmVmb3JlIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn1cblxuLnRvdGNvbCB7XG4gIGJvcmRlci1yaWdodC1zdHlsZTogc29saWQ7XG4gIGJvcmRlci13aWR0aDogMC41cHg7XG4gIGJvcmRlci1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlKTtcbn1cblxuLnRhYmxlIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICB3aWR0aDogMTAwJTtcbiAgbWFyZ2luOiAxMnB4O1xufVxuXG50cjpudGgtY2hpbGQoZXZlbikge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZGRkZGRkO1xufVxuXG50ZCwgdGgge1xuICBib3JkZXI6IDFweCBzb2xpZCAjZGRkZGRkO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDhweDtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgY29sb3I6IGJsYWNrO1xufSJdfQ== */";

/***/ }),

/***/ 7443:
/*!**********************************************************!*\
  !*** ./src/app/live-mzad/live-mzad.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar dir=\"rtl\">\n    <ion-buttons slot=\"end\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>\n      <ion-icon name=\"radio-outline\" ></ion-icon>  \n      البث الحي\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid *ngIf=\"!mzd && errorLoad == false\"  class=\"custGrid\"> \n    <ion-row class=\"ion-no-margin  ion-no-padding w100\" >\n      <ion-col size=\"12\" class=\"ion-text-center\">\n        <!-- *ngIf=\"spinner == true\" -->\n        <ion-spinner name=\"lines\" color=\"dark\" mode=\"ios\"></ion-spinner> \n      </ion-col>\n      <ion-col size=\"12\">\n        <!-- *ngIf=\"spinner == true\" --> \n      </ion-col>\n    </ion-row> \n  </ion-grid>\n\n  <ion-grid *ngIf=\"errorLoad == true\" class=\"custGrid\" > \n    <ion-row class=\"ion-no-margin  ion-no-padding ion-justify-content-center w100\" > \n      <ion-col size=\"12\" class=\"ion-text-center \"> \n        <h3>خطأ في التحميل</h3> \n      </ion-col>\n      <ion-col size=\"6\" class=\"ion-text-center\">\n        <ion-button expand=\"block\" (click)=\"reload()\">\n          <h5>تحديث</h5>\n          <ion-icon name=\"refresh\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  \n      </ion-col>\n    </ion-row> \n  </ion-grid>\n \n  \n\n\n\n\n\n<ion-grid class=\"ion-no-margin  ion-no-padding\"  dir=\"rtl\" >  \n    <!--  -->\n    <!--animation of bidding  -->\n    <div class=\"bidAnim \"*ngIf=\"showMe == true\">\n      <div class=\"childDiv animate__animated animate__fadeOutUp animate__delay-0s\">\n        <img class=\"bidImg\" src=\"../../assets/imgs/bidprimary.png\"/> \n        <h2 class=\"bidH\">{{bidPrice}}</h2>\n      </div>\n    </div>\n\n    <ion-row class=\"ion-no-margin  ion-no-padding po\" *ngIf=\"mzd\"> \n      <ion-col size=\"12\" class=\"ion-no-margin imgContainer\"> \n        <img class=\"radus5 custImg\" [src]=\"mzd['imgs'][0]\"/>  \n      </ion-col>     \n \n      <div class=\"fixGadegt\" style=\"background-color: #190b0b27; height: 90%;\">\n        <ion-grid class=\"ion-no-margin pd10 \" dir=\"rtl\">\n          <ion-row>\n            <ion-col class=\"ion-text-center\">\n              <ion-card-content class=\"ion-no-padding pd10\">\n                <ion-text class=\"priceText\"> {{+mzd['productPrice'] - (0.3 * +mzd['productPrice'])}} </ion-text><br>\n                <!-- <ion-text  class=\"white\"> ج.س</ion-text> -->\n                <ion-text class=\"white\"><b> السعر الإفتتاحي</b> </ion-text>\n              </ion-card-content>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n\n\n        <ion-grid class=\"ion-no-margin  ion-no-padding \" dir=\"rtl\">\n          <!-- <ion-row class=\"ion-no-margin  ion-no-padding\"> \n                  </ion-row> -->\n          <ion-row>\n            <ion-col class=\"ion-text-center\">\n              <ion-card-content class=\"ion-no-padding pd10\" [ngClass]=\"{'ion-no-padding pd10 animate__animated animate__zoomIn':showMe == true , 'ion-no-padding pd10':showMe == false}\">\n                <ion-text  class=\"priceText\"> {{highestBidd}} </ion-text><br>\n                <!-- <ion-text  class=\"white\"> ج.س</ion-text>  -->\n                <ion-text class=\"white\"><b>أعلي مزايدة</b> </ion-text>\n              </ion-card-content>\n            </ion-col>\n          </ion-row> \n        </ion-grid>\n      \n        <!-- <ion-grid class=\"ion-no-margin  ion-no-padding \" dir=\"rtl\">\n          <ion-row>\n            <ion-col class=\"ion-text-center\">\n              <ion-card-content class=\"ion-no-padding pd10\">\n                <ion-text class=\"priceText\"> {{lastBidd4U}} </ion-text> <br>\n               \n                <ion-text class=\"white\"><b>اخر مزايدة لك</b> </ion-text>\n              </ion-card-content>\n            </ion-col>\n          </ion-row> \n        </ion-grid> -->\n\n        <ion-grid class=\"ion-no-margin  ion-no-padding \" dir=\"rtl\">\n          <ion-row>\n            <ion-col class=\"ion-text-center\">\n              <ion-card-content class=\"ion-no-padding pd10\">\n                <ion-text class=\"priceText\"> {{availRounds}} </ion-text> <br>\n                <!-- <ion-text  class=\"white\"> ج.س</ion-text>  -->\n                <ion-text class=\"white\"><b> مزايداتك المتبقية </b> </ion-text>\n              </ion-card-content>\n            </ion-col>\n          </ion-row> \n        </ion-grid>\n      \n        <!-- <ion-grid class=\"ion-no-margin  ion-no-padding \" dir=\"rtl\">\n          <ion-row>\n            <ion-col class=\"ion-text-center\">\n              <ion-card-content class=\"ion-no-padding pd10\">\n                <ion-text class=\"priceText\"> 3 </ion-text>\n                <ion-text class=\"white\"> من </ion-text>\n                <ion-text class=\"priceText\"> 3</ion-text><br>\n                <ion-text class=\"white\"><b>مزايداتك المتبقية</b> </ion-text>\n              </ion-card-content>\n            </ion-col>\n          </ion-row>\n        </ion-grid> -->\n      </div> \n    </ion-row> \n\n   \n\n    <ion-row class=\"ion-no-padding\" *ngIf=\"mzd\"> \n      <!-- <ion-col size=\"12\" class=\"colSpic\" *ngIf=\"mzd['end']\"> -->\n        <!-- timeLine  -->\n        <!-- <ion-card class=\"cardStatus2\" *ngIf=\"timeLeft | async as tm\"> \n          <ion-grid>\n            <ion-row> \n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\" >{{tm['da'] }}  </ion-text> <br>\n                  <ion-text class=\"white\"><b> يوم</b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\"> {{tm['hr'] }} </ion-text> <br>\n                  <ion-text class=\"white\"><b> ساعة </b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\">  {{tm['mn'] }} </ion-text> <br>\n                  <ion-text class=\"white\"><b> دقيقة </b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\"> {{tm['sc'] }}  </ion-text> <br>\n                  <ion-text class=\"white\"><b> ثانية </b> </ion-text>\n                </ion-card-content>\n              </ion-col> \n            </ion-row> \n          </ion-grid>\n        </ion-card>   -->\n      <!-- </ion-col> -->\n      <!-- <ion-col size=\"12\"  class=\"borderbt\">\n        <ion-card-header> \n          <ion-card-title>مارسيدس مايباخ 2021</ion-card-title>\n        </ion-card-header> \n        <ion-card-content>\n          تعلن شركة زد للمزادات العقارية عن البيع بالمزاد العلني لمجموعة من العقارات المتنوعة تحت إشراف مركز الاسناد والتصفية «إنفاذ» وبقرار من محكمة التنفيذ\n        </ion-card-content>\n      </ion-col>  -->\n      <!-- <ion-card class=\"w100\"> \n        <ion-card-header>  \n            <ion-card-title>\n              <ion-icon name=\"radio-outline\" color=\"primary\"></ion-icon> \n              الحالة\n            </ion-card-title>\n          </ion-card-header>\n          <ion-grid class=\"ion-no-margin  ion-no-padding ion-padding-bottom\" dir=\"rtl\">\n            <ion-row class=\"ion-no-margin  ion-no-padding\"> \n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                    <ion-text color=\"primary\"><b>أعلي مزايدة</b> </ion-text><br> \n                    <ion-text> 3000 </ion-text>\n                    <ion-text> ج.س</ion-text> \n                  </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                    <ion-text color=\"primary\"><b>اخر مزايدة لك</b> </ion-text><br> \n                    <ion-text> 0 </ion-text>\n                    <ion-text> ج.س</ion-text> \n                  </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content class=\"ion-no-padding ion-padding-top\">  \n                      <ion-text color=\"primary\"><b>مزايداتك المتبقية</b> </ion-text><br> \n                       <ion-text> 3 </ion-text> \n                       <ion-text>  من </ion-text>  \n                       <ion-text>  3</ion-text>  \n                </ion-card-content>\n              </ion-col>\n            </ion-row>\n          </ion-grid> \n      </ion-card>  -->\n    \n\n      <!-- <ion-card class=\"w100 \">\n        <ion-card-header>\n          <ion-card-title>\n            <ion-icon name=\"bookmark-outline\" color=\"primary\"></ion-icon> \n          المشاركين \n          </ion-card-title> \n        </ion-card-header>\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\" >\n              <ion-item *ngFor=\"let per of mazad.users\"> \n                <ion-avatar>\n                  <ion-icon name=\"person\" slot=\"start\"></ion-icon>\n                </ion-avatar>\n                <ion-label>{{per.firstName}}</ion-label>\n              </ion-item>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n      </ion-card>  -->\n\n      <!-- timing and mzd detail  -->\n      <ion-col size=\"12\">\n        <ion-card-header class=\"pb0\"> \n          <ion-card-title> {{ mzd['title'] }}  </ion-card-title>\n          <ion-label>\n            {{mzd['shortDescr']}}\n          </ion-label>\n          <ion-label *ngIf=\"showMore == false\">{{tirmString(mzd['descr'] ,0)}}\n            <ion-text><ion-button fill=\"clear\" size=\"small\" (click)=\"showMore = true \">المزيد</ion-button></ion-text>\n          </ion-label>\n          <ion-label *ngIf=\"showMore == true\">\n            {{mzd['descr']}}\n            <ion-text><ion-button fill=\"clear\" size=\"small\" (click)=\"showMore = false \">اقل</ion-button></ion-text>\n          </ion-label>\n        </ion-card-header> \n        <!-- timing -->\n        <ion-card class=\"cardStatus2\" *ngIf=\"timeLeft | async as tm\"> \n          <ion-grid>\n            <ion-row> \n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\" >{{tm['da'] }}  </ion-text> <br>\n                  <ion-text class=\"white\"><b> يوم</b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\"> {{tm['hr'] }} </ion-text> <br>\n                  <ion-text class=\"white\"><b> ساعة </b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\">  {{tm['mn'] }} </ion-text> <br>\n                  <ion-text class=\"white\"><b> دقيقة </b> </ion-text>\n                </ion-card-content>\n              </ion-col>\n              <ion-col class=\"ion-text-center\">\n                <ion-card-content  class=\"ion-no-padding ion-padding-top\"> \n                  <ion-text class=\"priceText\"> {{tm['sc'] }}  </ion-text> <br>\n                  <ion-text class=\"white\"><b> ثانية </b> </ion-text>\n                </ion-card-content>\n              </ion-col> \n            </ion-row> \n          </ion-grid>\n        </ion-card>\n      </ion-col>\n\n\n       \n\n   <!-- history log  -->\n   <ion-card class=\"w100\">\n    <ion-card-header class=\"pb0\">  \n      <ion-card-title>\n        <ion-icon name=\"time-outline\" color=\"primary\"></ion-icon>\n        المزايدات \n        <!-- <h2 *ngIf=\"time$ | async as time\" >\n          {{time | date:'h:mm:ss'}}\n        </h2>     -->\n      </ion-card-title>\n    </ion-card-header>\n    <ion-grid *ngIf=\"emptyLog == false\">\n      <ion-list  class=\"ion-no-padding\">\n      <ion-item *ngFor=\"let log of usersLogs\">\n        <ion-avatar>\n          <ion-img src=\"../../assets/imgs/bid.png\"></ion-img>\n        </ion-avatar>\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\">\n              <ion-grid>\n                <ion-row>\n                  <ion-col size=\"12\">\n                   <ion-item lines=\"none\">\n                    <ion-label>{{log.userName}}</ion-label>\n                   </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-label> \n                      <ion-text>{{log.time | dateAgo}} </ion-text> <ion-text>{{log.time | date:'EEE dd-MM' : undefined  : 'ar' }} </ion-text> \n                      </ion-label>\n                  </ion-col> \n                </ion-row>\n              </ion-grid>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n       <ion-badge slot=\"end\">\n        <ion-label><ion-text>{{log.pay}}</ion-text></ion-label>  \n       </ion-badge>\n      </ion-item>\n\n      <ion-item *ngIf=\"mzd['logs'].length > 2\" button (click)=\"viewMoreLess()\" lines=\"none\" class=\"lightItem lightBorder\">\n         <h4 class=\"custH\">\n          <ion-label *ngIf=\"view == 0\">\n            <ion-note >المزيد</ion-note><br>\n            <ion-icon name=\"chevron-down-outline\" color=\"primary\"></ion-icon>\n          </ion-label>\n          <ion-label *ngIf=\"view == 1\">\n            <ion-note >اقل</ion-note><br>\n            <ion-icon   name=\"chevron-up-outline\" color=\"primary\"></ion-icon> \n          </ion-label> \n         </h4> \n      </ion-item> \n\n    </ion-list>\n    </ion-grid>\n\n\n      <ion-grid *ngIf=\"emptyLog == true\">\n        <ion-row>\n          <ion-col size=\"12\"> \n               <div class=\"w100 centerDiv\"><ion-thumbnail><ion-img src=\"../../assets/imgs/bid.png\"></ion-img></ion-thumbnail>  </div>  \n          </ion-col>\n          <ion-col size=\"12\" >  \n            <div  class=\"w100 centerDiv\" ><h2> كن اول من يضع مزايدة  </h2></div> \n          </ion-col>\n        </ion-row>\n       </ion-grid>\n    </ion-card> \n\n\n      <!-- fees  -->\n      <ion-card class=\"w100\" *ngIf=\"mzd\"> \n        <ion-card-header class=\"pb0\">  \n            <ion-card-title>\n               <ion-icon name=\"cash-outline\" color=\"primary\"></ion-icon>\n              رسوم المشاركة\n            </ion-card-title>\n          </ion-card-header>\n          <ion-grid class=\"ion-no-margin  ion-no-padding ion-padding-bottom\" dir=\"rtl\">\n            <!-- <ion-row class=\"ion-no-margin  ion-no-padding\">\n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item>\n                  <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\" class=\"ion-text-center\">\n                <ion-item>\n                  <ion-skeleton-text animated style=\"width: 100%\"></ion-skeleton-text>\n                </ion-item>\n              </ion-col>\n            </ion-row> -->\n          </ion-grid>\n          <ion-grid class=\"ion-no-margin  ion-no-padding ion-padding-bottom\" dir=\"rtl\">\n            <ion-row class=\"ion-no-margin  ion-no-padding\"> \n              <ion-col size=\"4\" class=\"ion-text-center\">\n                <ion-card-content> \n                    <ion-text color=\"primary\"><b>العربون</b> </ion-text><br> \n                    <ion-text> {{mzd['deposit']}} </ion-text>\n                    <ion-text> ج.س</ion-text> \n                  </ion-card-content>\n              </ion-col>\n              <ion-col size=\"4\" class=\"ion-text-center\">\n                <ion-card-content>  \n                      <ion-text color=\"primary\"><b>رسوم دفتر </b> </ion-text><br> \n                       <ion-text> {{mzd['fee']}} </ion-text> \n                       <ion-text>   ج.س</ion-text>  \n                </ion-card-content>\n              </ion-col>\n\n              <ion-col size=\"4\" class=\"ion-text-center totcol\">\n                <ion-card-content> \n                  <ion-text color=\"primary\"><b>المجموع </b>  </ion-text><br>\n                  <ion-text>  {{mzd['deposit'] + mzd['fee']}}  </ion-text>\n                  <ion-text>   ج.س</ion-text> \n                </ion-card-content>\n              </ion-col>\n            </ion-row>\n          </ion-grid> \n      </ion-card> \n      <!-- terms -->\n\n      <ion-card class=\"w100 \">\n        <ion-card-header class=\"pb0\">\n          <ion-card-title>\n            <ion-icon name=\"bookmark-outline\" color=\"primary\"></ion-icon> \n            بنود المزاد\n          </ion-card-title> \n        </ion-card-header>\n        <ion-grid>\n          <ion-row>\n            <ion-col size=\"12\" >\n              <ion-card-content> \n                <ion-label *ngFor=\"let term of termsArr\">\n                  <ion-icon name=\"pin\" color=\"primary\"></ion-icon>\n                  <ion-text>{{term.desc}}</ion-text><br>\n                 </ion-label> \n              </ion-card-content>\n            </ion-col>\n          </ion-row>\n          <ion-row  class=\"ion-justify-content-center\">\n            <ion-item  button (click)=\"viewMoreLessTerms()\" lines=\"none\" class=\"lightItem lightBorder\">\n              <h4 class=\"custH\">\n               <ion-label *ngIf=\"viewTerms == 0\">\n                 <ion-note >المزيد</ion-note><br>\n                 <ion-icon name=\"chevron-down-outline\" color=\"primary\"></ion-icon>\n               </ion-label>\n               <ion-label *ngIf=\"viewTerms == 1\">\n                 <ion-note >اقل</ion-note><br>\n                 <ion-icon   name=\"chevron-up-outline\" color=\"primary\"></ion-icon> \n               </ion-label> \n              </h4> \n           </ion-item>\n          </ion-row>\n          \n        </ion-grid>\n      </ion-card>\n\n    </ion-row>\n\n</ion-grid>\n</ion-content>\n\n\n<ion-footer class=\"footer\" *ngIf=\"mzd\">\n  <ion-grid>\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col size=\"8\" class=\"flex\">\n        <ion-button size=\"small\" (click)=\"decrease(bidPrice)\">\n          <ion-icon name=\"remove-circle\" color=\"light\"></ion-icon>\n        </ion-button>\n        <ion-input (ionFocus)=\"focusBidding($event)\" (ionBlur)=\"unCheckFocus()\" (ionChange)=\"bidChange($event)\" type=\"number\"\n          class=\"blueBorder\" [(ngModel)]=\"bidPrice\"\n          [ngClass]=\"{'redBorder': showError == true ,'blueBorder': showError == false}\"> \n        </ion-input><br>\n        <ion-button size=\"small\" (click)=\"increase(bidPrice)\">\n          <ion-icon name=\"add-circle\" color=\"light\"></ion-icon>\n        </ion-button>   \n      </ion-col>\n      <ion-col size=\"8\" *ngIf=\"showError == true\" class=\"ion-no-margin ion-no-padding ion-text-center\">\n        <ion-note color=\"danger\">{{msgError}}</ion-note>\n      </ion-col> \n      <ion-col size=\"8\">\n        <ion-button expand=\"block\" [disabled]=\"showError ==true\" (click)=\"bidding()\">\n          <h5>مزايدة</h5>\n          <ion-icon name=\"hand-right-outline\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button> \n        <!-- <ion-button expand=\"block\"  (click)=\"endAuction()\">\n          <h5>end it</h5>\n          <ion-icon name=\"hand-right-outline\" color=\"light\" slot=\"end\"></ion-icon>\n        </ion-button>  -->\n      </ion-col>\n      <!-- <ion-col size=\"6\" class=\"ion-text-center\">\n        <h4 class=\"ion-no-margin\">\n        <ion-text color=\"primary\">\n            أعلي مزايدة\n        </ion-text> <br>  \n        <ion-text> 3000 </ion-text>\n         <ion-text> ج.س</ion-text>\n       </h4>  \n      </ion-col>  -->\n    </ion-row>\n  </ion-grid>\n</ion-footer>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_live-mzad_live-mzad_module_ts.js.map