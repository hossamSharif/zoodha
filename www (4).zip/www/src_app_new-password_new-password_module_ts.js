"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_new-password_new-password_module_ts"],{

/***/ 4149:
/*!*************************************************************!*\
  !*** ./src/app/new-password/new-password-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewPasswordPageRoutingModule": () => (/* binding */ NewPasswordPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _new_password_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-password.page */ 8994);




const routes = [
    {
        path: '',
        component: _new_password_page__WEBPACK_IMPORTED_MODULE_0__.NewPasswordPage
    }
];
let NewPasswordPageRoutingModule = class NewPasswordPageRoutingModule {
};
NewPasswordPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NewPasswordPageRoutingModule);



/***/ }),

/***/ 2630:
/*!*****************************************************!*\
  !*** ./src/app/new-password/new-password.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewPasswordPageModule": () => (/* binding */ NewPasswordPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _new_password_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-password-routing.module */ 4149);
/* harmony import */ var _new_password_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-password.page */ 8994);







let NewPasswordPageModule = class NewPasswordPageModule {
};
NewPasswordPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _new_password_routing_module__WEBPACK_IMPORTED_MODULE_0__.NewPasswordPageRoutingModule
        ],
        declarations: [_new_password_page__WEBPACK_IMPORTED_MODULE_1__.NewPasswordPage]
    })
], NewPasswordPageModule);



/***/ }),

/***/ 8994:
/*!***************************************************!*\
  !*** ./src/app/new-password/new-password.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewPasswordPage": () => (/* binding */ NewPasswordPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _new_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-password.page.html?ngResource */ 9527);
/* harmony import */ var _new_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-password.page.scss?ngResource */ 5892);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 124);





let NewPasswordPage = class NewPasswordPage {
    constructor(rout) {
        this.rout = rout;
    }
    ngOnInit() {
    }
    newPassword() {
        this.rout.navigate(['login']);
    }
};
NewPasswordPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
NewPasswordPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-new-password',
        template: _new_password_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_new_password_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NewPasswordPage);



/***/ }),

/***/ 5892:
/*!****************************************************************!*\
  !*** ./src/app/new-password/new-password.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = ".header-md::after {\n  background-image: none;\n}\n\n.bordernon {\n  border: none;\n}\n\n.newHeight {\n  height: 375px;\n}\n\n.custH {\n  border-bottom-style: solid;\n  padding: 10px;\n  width: 120px;\n  text-align: center;\n}\n\n.custGrid {\n  position: relative;\n  top: -181px;\n}\n\n.footer-md::before {\n  background-image: none;\n}\n\n.borderNone {\n  border-radius: 0px;\n}\n\n.padd13 {\n  padding-top: 13%;\n}\n\n.padd1 {\n  padding: 1%;\n}\n\n.logoSvg {\n  position: absolute;\n  top: 30%;\n  left: 50%;\n  margin-right: 50%;\n  transform: translate(-50%, -50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5ldy1wYXNzd29yZC5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXGh1c2FtJTIwcHJvalxcem9vZG9oYVNkXFxzcmNcXGFwcFxcbmV3LXBhc3N3b3JkXFxuZXctcGFzc3dvcmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0JBQUE7QUNDSjs7QURDQTtFQUNJLFlBQUE7QUNFSjs7QURDQTtFQUNJLGFBQUE7QUNFSjs7QURBQTtFQUNJLDBCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQ0dKOztBRERBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0FDSUo7O0FERkE7RUFDSSxzQkFBQTtBQ0tKOztBREhBO0VBQ0ksa0JBQUE7QUNNSjs7QURKQTtFQUNJLGdCQUFBO0FDT0o7O0FETEE7RUFDSSxXQUFBO0FDUUo7O0FETkE7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQ0FBQTtBQ1NKIiwiZmlsZSI6Im5ldy1wYXNzd29yZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyLW1kOjphZnRlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOm5vbmU7XHJcbn1cclxuLmJvcmRlcm5vbntcclxuICAgIGJvcmRlcjogbm9uZTtcclxufVxyXG5cclxuLm5ld0hlaWdodHtcclxuICAgIGhlaWdodDogMzc1cHg7XHJcbn1cclxuLmN1c3RIe1xyXG4gICAgYm9yZGVyLWJvdHRvbS1zdHlsZTogc29saWQ7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgd2lkdGg6IDEyMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5jdXN0R3JpZHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRvcDogLTE4MXB4O1xyXG59XHJcbi5mb290ZXItbWQ6OmJlZm9yZXtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6ICBub25lO1xyXG59XHJcbi5ib3JkZXJOb25le1xyXG4gICAgYm9yZGVyLXJhZGl1czogMHB4O1xyXG59XHJcbi5wYWRkMTN7XHJcbiAgICBwYWRkaW5nLXRvcDoxMyVcclxufVxyXG4ucGFkZDF7XHJcbiAgICBwYWRkaW5nOiAxJTtcclxufVxyXG4ubG9nb1N2Z3tcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMzAlO1xyXG4gICAgbGVmdDogNTAlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxufSIsIi5oZWFkZXItbWQ6OmFmdGVyIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn1cblxuLmJvcmRlcm5vbiB7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuLm5ld0hlaWdodCB7XG4gIGhlaWdodDogMzc1cHg7XG59XG5cbi5jdXN0SCB7XG4gIGJvcmRlci1ib3R0b20tc3R5bGU6IHNvbGlkO1xuICBwYWRkaW5nOiAxMHB4O1xuICB3aWR0aDogMTIwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmN1c3RHcmlkIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IC0xODFweDtcbn1cblxuLmZvb3Rlci1tZDo6YmVmb3JlIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbn1cblxuLmJvcmRlck5vbmUge1xuICBib3JkZXItcmFkaXVzOiAwcHg7XG59XG5cbi5wYWRkMTMge1xuICBwYWRkaW5nLXRvcDogMTMlO1xufVxuXG4ucGFkZDEge1xuICBwYWRkaW5nOiAxJTtcbn1cblxuLmxvZ29Tdmcge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMzAlO1xuICBsZWZ0OiA1MCU7XG4gIG1hcmdpbi1yaWdodDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbn0iXX0= */";

/***/ }),

/***/ 9527:
/*!****************************************************************!*\
  !*** ./src/app/new-password/new-password.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = " \n<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n     <ion-button fill=\"clear\" >\n       <ion-icon name=\"arrow-back-outline\" color=\"light\"></ion-icon>\n     </ion-button>\n    </ion-buttons>\n    <ion-title>newPassword</ion-title> \n   </ion-toolbar>\n</ion-header>\n \n\n<ion-content>\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col  size=\"12\" class=\"head3 newHeight ion-text-center \">  \n        <svg class=\"logoSvg\" width=\"119\" height=\"119\" viewBox=\"0 0 119 119\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <circle opacity=\"0.27\" cx=\"59.5\" cy=\"59.5\" r=\"59.5\" fill=\"white\"/>\n          <path d=\"M90.1941 52.2367H61.0521C59.4103 47.8509 56.2761 44.1827 52.2005 41.876C51.2458 41.3609 50.0547 41.7062 49.523 42.6508C48.9907 43.596 49.3137 44.7926 50.249 45.3421C54.1875 47.55 57.0009 51.3292 57.986 55.7355C58.9712 60.1419 58.0354 64.7597 55.4124 68.4345C52.7893 72.1099 48.7265 74.4959 44.2391 74.9961L46.0929 73.0762L46.0935 73.0768C46.4715 72.6994 46.6818 72.1859 46.6774 71.6521C46.6729 71.1181 46.4542 70.6086 46.0702 70.2373C45.6861 69.8665 45.1688 69.6656 44.6348 69.68C44.1009 69.6945 43.5952 69.9226 43.2317 70.3139L38.2226 75.4995C38.2165 75.5056 38.2126 75.5134 38.2065 75.5195C38.1737 75.5544 38.1465 75.5961 38.116 75.6327H38.1165C38.0649 75.6926 38.0166 75.7554 37.9722 75.8208C37.9406 75.8714 37.9173 75.9274 37.8895 75.9813V75.9807C37.8562 76.0406 37.8257 76.1022 37.798 76.165C37.7769 76.2199 37.7663 76.2782 37.7491 76.3359H37.7497C37.7269 76.4047 37.7086 76.4747 37.6936 76.5457L37.6875 76.5696C37.6786 76.6273 37.6814 76.6839 37.6775 76.7416C37.6736 76.7994 37.6625 76.856 37.6637 76.9148V76.9398H37.6642C37.6681 77.0142 37.677 77.088 37.6897 77.1618C37.6975 77.2173 37.7019 77.2734 37.7136 77.3278C37.7325 77.3982 37.7547 77.4682 37.7813 77.5365C37.8002 77.5892 37.8141 77.6441 37.8379 77.6957C37.8679 77.7596 37.9012 77.8223 37.9373 77.8828C37.9661 77.9316 37.9911 77.9821 38.0239 78.0299C38.0716 78.0932 38.1227 78.1537 38.1771 78.2108C38.207 78.2436 38.2309 78.2813 38.2636 78.3102L38.2864 78.3329L43.6097 83.4675C44.4034 84.2057 45.6422 84.1724 46.3953 83.3926C47.1485 82.6128 47.1385 81.3734 46.3725 80.6058L44.6637 78.9546H44.6642C48.9895 78.4673 53.0368 76.5758 56.1855 73.5698C59.3347 70.5644 61.4122 66.6098 62.1004 62.3111C62.4196 60.2919 62.4218 58.2349 62.1076 56.2153H90.194C90.7218 56.2153 91.2274 56.4251 91.6004 56.7981C91.9734 57.1711 92.1832 57.6767 92.1832 58.2045V67.156C92.1832 68.2544 91.2924 69.1452 90.194 69.1452C89.0956 69.1452 88.2048 68.2544 88.2048 67.156V64.1722C88.2048 63.6444 87.995 63.1387 87.622 62.7658C87.249 62.3928 86.7434 62.183 86.2155 62.183H80.2479C79.1495 62.183 78.2587 63.0738 78.2587 64.1722V67.156C78.2587 68.2544 77.3679 69.1452 76.2695 69.1452C75.1711 69.1452 74.2802 68.2544 74.2802 67.156V64.1722C74.2802 63.6444 74.0704 63.1387 73.6975 62.7658C73.3245 62.3928 72.8188 62.183 72.291 62.183H66.3234C65.225 62.183 64.3341 63.0738 64.3341 64.1722C64.3341 65.2706 65.225 66.1614 66.3234 66.1614H70.3018V67.156C70.3018 69.2879 71.4391 71.2582 73.2856 72.3244C75.1322 73.3901 77.4067 73.3901 79.2533 72.3244C81.0998 71.2582 82.2371 69.2879 82.2371 67.156V66.1614H84.2263V67.156C84.2263 69.2879 85.3636 71.2582 87.2102 72.3244C89.0567 73.3901 91.3313 73.3901 93.1778 72.3244C95.0244 71.2582 96.1616 69.2879 96.1616 67.156V58.2045C96.16 56.6221 95.5306 55.1058 94.4117 53.9868C93.2928 52.8679 91.7764 52.2384 90.194 52.2369L90.1941 52.2367Z\" fill=\"white\"/>\n          <path d=\"M33.5015 59.199C33.5015 61.5729 34.4445 63.8501 36.1234 65.5286C37.8017 67.2075 40.0791 68.1505 42.4529 68.1505C44.8268 68.1505 47.104 67.2075 48.7825 65.5286C50.4614 63.8503 51.4044 61.5729 51.4044 59.199C51.4044 56.8252 50.4614 54.548 48.7825 52.8695C47.1042 51.1906 44.8268 50.2476 42.4529 50.2476C40.0797 50.2503 37.8046 51.1939 36.1262 52.8723C34.4479 54.5508 33.5043 56.8258 33.5015 59.199ZM47.426 59.199C47.426 60.5178 46.9021 61.7828 45.9696 62.7157C45.0366 63.6481 43.7717 64.1721 42.4529 64.1721C41.1342 64.1721 39.8692 63.6481 38.9363 62.7157C38.0038 61.7827 37.4799 60.5178 37.4799 59.199C37.4799 57.8803 38.0038 56.6153 38.9363 55.6824C39.8693 54.7499 41.1342 54.226 42.4529 54.226C43.7711 54.2277 45.0355 54.7522 45.9679 55.6841C46.8998 56.6165 47.4243 57.8809 47.426 59.199Z\" fill=\"white\"/>\n          <path d=\"M32.7055 76.5222C33.6602 77.0372 34.8513 76.692 35.383 75.7474C35.9153 74.8022 35.5923 73.6055 34.657 73.0561C30.7185 70.8488 27.9051 67.0695 26.92 62.6637C25.9343 58.2579 26.8689 53.64 29.4915 49.9652C32.114 46.2899 36.1757 43.9032 40.6625 43.4021L38.8098 45.3208V45.3203C38.4318 45.6977 38.2209 46.2111 38.2254 46.745C38.2298 47.2789 38.4491 47.789 38.8331 48.1598C39.2172 48.5305 39.7345 48.7314 40.2679 48.717C40.8019 48.7031 41.3075 48.4745 41.671 48.0837L46.6802 42.8981L46.6879 42.8881V42.8876C46.7501 42.8199 46.8073 42.7477 46.8594 42.6717C46.8811 42.6406 46.9083 42.6139 46.9283 42.5823H46.9277C46.9688 42.5129 47.006 42.4408 47.0382 42.3664C47.0592 42.3214 47.0859 42.2798 47.1037 42.2332C47.1214 42.1866 47.1386 42.1111 47.1564 42.0489V42.0495C47.1775 41.984 47.1952 41.9174 47.2091 41.8502C47.2091 41.8425 47.2091 41.8341 47.2152 41.8264C47.2241 41.7686 47.2213 41.712 47.2252 41.6543C47.2291 41.5966 47.2402 41.54 47.2391 41.4811V41.4562V41.4567C47.2346 41.3823 47.2263 41.308 47.2135 41.2347C47.2058 41.1792 47.2013 41.1231 47.1897 41.0687C47.1708 40.9977 47.1481 40.9278 47.122 40.8595C47.1031 40.8068 47.0892 40.7518 47.0654 40.7002V40.7008C47.0354 40.6364 47.0021 40.5742 46.9655 40.5137C46.9366 40.4649 46.9116 40.4144 46.8789 40.3666V40.3661C46.8317 40.3028 46.7806 40.2423 46.7257 40.1851C46.6957 40.1524 46.6718 40.1146 46.6391 40.0858L46.6163 40.063L41.2965 34.9307C40.5028 34.1925 39.2639 34.2258 38.5108 35.0056C37.7577 35.7854 37.7677 37.0248 38.5336 37.7924L40.2503 39.4503C34.6367 40.068 29.5516 43.0463 26.2664 47.6397C22.9812 52.2331 21.8055 58.0077 23.035 63.5194C24.2639 69.0314 27.7805 73.7596 32.7058 76.522L32.7055 76.5222Z\" fill=\"white\"/>\n          </svg>\n     </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid class=\"custGrid ion-margin-bottom\">\n     <ion-row class=\"ion-justify-content-center\">\n    <ion-col size=\"10\" >\n     <ion-card class=\"bordernon w100\" >\n      <ion-card-header>\n        <ion-card-title>\n         <h3 ><b>Create new password</b></h3> \n        </ion-card-title>\n        <ion-card-subtitle>\n          Your new password must be different from previous used password\n        </ion-card-subtitle>\n      </ion-card-header>\n       <ion-grid>\n        <ion-row class=\"ion-margin\">\n          <ion-list class=\"w100\"> \n            <ion-item>\n              <ion-label position=\"floating\">Password</ion-label> \n              <ion-input type=\"password\"></ion-input>\n              <ion-icon  slot=\"end\"  name=\"eye-off-outline\" ></ion-icon>\n            </ion-item>\n            <ion-item>\n              <ion-label position=\"floating\">Confirm Password</ion-label> \n              <ion-input type=\"password\"></ion-input>\n              <ion-icon  slot=\"end\"   name=\"eye-off-outline\" ></ion-icon>\n            </ion-item>\n          </ion-list>\n        </ion-row> \n        <ion-row class=\"ion-margin\">\n          <ion-col size=\"12\">\n            <ion-item color=\"primary\" button (click)=\"newPassword()\">\n              <ion-label class=\"ion-text-center\">Create new password</ion-label> \n            </ion-item>\n          </ion-col>\n        </ion-row> \n       </ion-grid> \n      </ion-card>\n    </ion-col>\n    </ion-row>\n  </ion-grid>\n \n</ion-content>\n\n";

/***/ })

}]);
//# sourceMappingURL=src_app_new-password_new-password_module_ts.js.map