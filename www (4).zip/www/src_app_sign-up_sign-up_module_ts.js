"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_sign-up_sign-up_module_ts"],{

/***/ 9204:
/*!***************************************************!*\
  !*** ./src/app/sign-up/sign-up-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SignUpPageRoutingModule": () => (/* binding */ SignUpPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _sign_up_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sign-up.page */ 80);




const routes = [
    {
        path: '',
        component: _sign_up_page__WEBPACK_IMPORTED_MODULE_0__.SignUpPage
    }
];
let SignUpPageRoutingModule = class SignUpPageRoutingModule {
};
SignUpPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SignUpPageRoutingModule);



/***/ }),

/***/ 3982:
/*!*******************************************!*\
  !*** ./src/app/sign-up/sign-up.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SignUpPageModule": () => (/* binding */ SignUpPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _sign_up_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sign-up-routing.module */ 9204);
/* harmony import */ var _sign_up_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sign-up.page */ 80);







let SignUpPageModule = class SignUpPageModule {
};
SignUpPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _sign_up_routing_module__WEBPACK_IMPORTED_MODULE_0__.SignUpPageRoutingModule
        ],
        declarations: [_sign_up_page__WEBPACK_IMPORTED_MODULE_1__.SignUpPage]
    })
], SignUpPageModule);



/***/ }),

/***/ 80:
/*!*****************************************!*\
  !*** ./src/app/sign-up/sign-up.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SignUpPage": () => (/* binding */ SignUpPage)
/* harmony export */ });
/* harmony import */ var E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 2321);
/* harmony import */ var _sign_up_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sign-up.page.html?ngResource */ 8796);
/* harmony import */ var _sign_up_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sign-up.page.scss?ngResource */ 5585);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/socket-service.service */ 905);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ 190);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _terms_terms_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../terms/terms.page */ 4622);











let SignUpPage = class SignUpPage {
  //   Minimum eight characters, at least one letter and one number:
  // "^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$"
  // Minimum eight characters, at least one letter, one number and one special character:
  // "^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$"
  // Minimum eight characters, at least one uppercase letter, one lowercase letter and one number:
  // "^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$"
  // Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character:
  // "^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$"
  // Minimum eight and maximum 10 characters, at least one uppercase letter, one lowercase letter, one number and one special character:
  // "^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,10}$"
  constructor(modalController, formBuilder, toast, route, storage, rout, api) {
    this.modalController = modalController;
    this.formBuilder = formBuilder;
    this.toast = toast;
    this.route = route;
    this.storage = storage;
    this.rout = rout;
    this.api = api;
    this.spinner = false;
    this.isSubmitted = false;
    this.isSubmitted2 = false;
    this.isOpen = false;
    this.confirmPass = "";
    this.agree = false;
    this.passType = 'password';
    this.confType = 'password';
    this.show = false;
    this.showConf = false;
    this.outdateCode = false;
    this.ionic2Form = this.formBuilder.group({
      code: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(4), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(4), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('^[0-9]+$')]]
    });
    this.ionicForm = this.formBuilder.group({
      firstName: [''],
      lastName: [''],
      fullName: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(4), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('[a-zA-Z][a-zA-Z ]+')]],
      email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$')]],
      birth: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required],
      gender: [''],
      phone: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(9), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.maxLength(9), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('^[0-9]+$')]],
      password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(5), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('^([^0-9]*|[^A-Z]*|[^a-z]*|[a-zA-Z0-9]*)$')]],
      confirmPass: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(5), _angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('^([^0-9]*|[^A-Z]*|[^a-z]*|[a-zA-Z0-9]*)$')]],
      agree: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required]]
    }); //case signup with normal way , not using phone 

    this.USER_INFO = {
      firstName: "",
      lastName: "",
      fullName: "",
      type: "",
      phone: undefined,
      contryCode: "",
      password: "",
      gender: undefined,
      email: "",
      userName: "",
      imei: "",
      birthDate: ""
    };
    this.route.queryParams.subscribe(params => {
      if (params && params.phone) {
        this.USER_INFO = {
          firstName: "",
          lastName: "",
          fullName: "",
          type: "",
          phone: JSON.parse(params.phone),
          contryCode: "",
          password: "",
          gender: undefined,
          email: "",
          userName: "",
          imei: "",
          birthDate: ""
        };
      } else {}
    });
  }

  ngOnInit() {}

  showPass(type) {
    if (type == 'pass') {
      if (this.show == true) {
        this.show = false;
        this.passType = 'password';
      } else {
        this.show = true;
        this.passType = 'text';
      }
    } else if (type == 'confirm') {
      if (this.showConf == true) {
        this.showConf = false;
        this.confType = 'password';
      } else {
        this.showConf = true;
        this.confType = 'text';
      }
    }
  }

  agreeCheck(ev) {
    console.log(ev.target.checked);
  }

  presentPopover(e) {
    this.popover.event = e;
    this.isOpen = true;
  }

  getInfo(type) {}

  genderChange(ev) {
    console.log(ev);
  }

  get errorControl() {
    return this.ionicForm.controls;
  }

  get errorControl2() {
    return this.ionic2Form.controls;
  }

  dateChange(ev) {
    console.log(ev.target.value);
    this.isOpen = false;
  }

  getVirfyCode(type, sendData) {
    let seq = (Math.floor(Math.random() * 10000) + 10000).toString().substring(1);
    return seq;
  }

  confirmAccount() {}

  getsms() {//   let seq = (Math.floor(Math.random() * 10000) + 10000).toString().substring(1)
    //   this.api.sendsms(this.phone , seq).subscribe(data =>{
    //     console.log('sms req',data)
    //     let res = data 
    //     console.log('sms response',data)
    //     //add ionic plugin to detect the sms msg and get the use substring and procced the confirmation fuction auto
    //    // this.orignalCode = res 
    //   }, (err) => {
    //   console.log(err); 
    // })  
  }

  validateCode() {
    this.isSubmitted2 = true;

    if (this.ionic2Form.valid == false) {
      console.log('Please provide all the required values!');
      return false;
    } else if (this.outdateCode == true) {
      this.presentToast(' انتهت المهلة ,إضغط إعادة ارسال للحصول علي رمز جديد', 'danger');
    } else if (this.code != this.orignalCode) {
      this.presentToast(' الرمز غير صحيح', 'danger');
      return false;
    } else {
      return true;
    }
  }

  validate() {
    this.isSubmitted = true;

    if (this.ionicForm.valid == false) {
      console.log('Please provide all the required values!');
      return false;
    } else if (this.USER_INFO.password.length > 0 && this.USER_INFO.password != this.confirmPass) {
      return false;
    } else {
      return true;
    }
  }

  next() {
    if (this.validate() == true) {
      this.verficStep = true;
      this.orignalCode = this.getVirfyCode();
    }
  }

  save() {
    if (this.validateCode() == true) {
      this.spinner = true;
      this.api.createUser(this.USER_INFO).subscribe(data => {
        console.log('user was created', data);
        let res = data;
        console.log('user was created', res['token']);
        this.storage.set('token', res['token']).then(response => {
          this.rout.navigate(['tabs/home']);
        });
      }, err => {
        console.log(err);
        this.spinner = false;
        this.handleError(err.error.error);
      }, () => {
        this.spinner = false;
      });
    }
  }

  handleError(msg) {
    if (msg == "duplicate phone") {
      this.presentToast('رقم الهاتف موجود مسبقا , قم بتسجيل الدخول', 'danger');
      return false;
    } else if (msg == "duplicate email") {
      this.presentToast("البريد موجود مسبقا", 'danger');
      return false;
    }
  }

  timerKiller() {
    setTimeout(() => {
      this.route.queryParams.subscribe(params => {
        if (params && params.type) {
          this.outdateCode = true;
        }
      });
    }, 180000);
  }

  showTerms(id, status) {
    var _this = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this.modalController.create({
        component: _terms_terms_page__WEBPACK_IMPORTED_MODULE_5__.TermsPage,
        componentProps: {
          "item": ""
        }
      });
      modal.onDidDismiss().then(dataReturned => {
        if (dataReturned !== null) {
          console.log('https://www.digitalocean.com/', dataReturned);

          _this.doAfterDissmiss(dataReturned);
        }
      });
      return yield modal.present();
    })();
  }

  doAfterDissmiss(dataReturned) {
    if (dataReturned.data == "agree") {
      this.agree = true;
    }
  }

  presentToast(msg, color) {
    var _this2 = this;

    return (0,E_husam_proj_zoodohaSd_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this2.toast.create({
        message: msg,
        duration: 2000,
        color: color,
        cssClass: 'cust_Toast',
        mode: 'ios',
        position: 'top'
      });
      toast.present();
    })();
  }

  login() {
    this.rout.navigate(['login']);
  }

  changePhone() {
    console.log('asdhlaks');
    this.rout.navigate(['login']);
  }

  froget() {
    this.rout.navigate(['forget-password']);
  }

  verify() {
    this.rout.navigate(['verify']);
  }

};

SignUpPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController
}, {
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ToastController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.ActivatedRoute
}, {
  type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__.Storage
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router
}, {
  type: _services_socket_service_service__WEBPACK_IMPORTED_MODULE_3__.SocketServiceService
}];

SignUpPage.propDecorators = {
  popover: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: ['popover']
  }]
};
SignUpPage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-sign-up',
  template: _sign_up_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_sign_up_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], SignUpPage);


/***/ }),

/***/ 5585:
/*!******************************************************!*\
  !*** ./src/app/sign-up/sign-up.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = ".header-md::after {\n  background-image: none;\n}\n\n.bordernon {\n  border: none;\n}\n\n.custH {\n  border-bottom-style: solid;\n  padding: 10px;\n  width: 120px;\n  text-align: center;\n}\n\n.custGrid2 {\n  position: relative;\n  top: -130px;\n}\n\n.footer-md::before {\n  background-image: none;\n}\n\n.borderNone {\n  border-radius: 0px;\n}\n\n.padd13 {\n  padding-top: 13%;\n}\n\n.padd1 {\n  padding: 1%;\n}\n\n.logoSvg {\n  position: absolute;\n  top: 30%;\n  left: 50%;\n  margin-right: 50%;\n  transform: translate(-50%, -50%);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNpZ24tdXAucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFxodXNhbSUyMHByb2pcXHpvb2RvaGFTZFxcc3JjXFxhcHBcXHNpZ24tdXBcXHNpZ24tdXAucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0JBQUE7QUNDSjs7QURDQTtFQUNJLFlBQUE7QUNFSjs7QURBQTtFQUNJLDBCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQ0dKOztBRERBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0FDSUo7O0FERkE7RUFDSSxzQkFBQTtBQ0tKOztBREhBO0VBQ0ksa0JBQUE7QUNNSjs7QURKQTtFQUNJLGdCQUFBO0FDT0o7O0FETEE7RUFDSSxXQUFBO0FDUUo7O0FETkE7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQ0FBQTtBQ1NKIiwiZmlsZSI6InNpZ24tdXAucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlci1tZDo6YWZ0ZXIge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTpub25lO1xyXG59XHJcbi5ib3JkZXJub257XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbn1cclxuLmN1c3RIe1xyXG4gICAgYm9yZGVyLWJvdHRvbS1zdHlsZTogc29saWQ7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgd2lkdGg6IDEyMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbi5jdXN0R3JpZDJ7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB0b3A6IC0xMzBweDtcclxufVxyXG4uZm9vdGVyLW1kOjpiZWZvcmV7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiAgbm9uZTtcclxufVxyXG4uYm9yZGVyTm9uZXtcclxuICAgIGJvcmRlci1yYWRpdXM6IDBweDtcclxufVxyXG4ucGFkZDEze1xyXG4gICAgcGFkZGluZy10b3A6MTMlXHJcbn1cclxuLnBhZGQxe1xyXG4gICAgcGFkZGluZzogMSU7XHJcbn1cclxuLmxvZ29Tdmd7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDMwJTtcclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIG1hcmdpbi1yaWdodDogNTAlO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcbn0iLCIuaGVhZGVyLW1kOjphZnRlciB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmU7XG59XG5cbi5ib3JkZXJub24ge1xuICBib3JkZXI6IG5vbmU7XG59XG5cbi5jdXN0SCB7XG4gIGJvcmRlci1ib3R0b20tc3R5bGU6IHNvbGlkO1xuICBwYWRkaW5nOiAxMHB4O1xuICB3aWR0aDogMTIwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmN1c3RHcmlkMiB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdG9wOiAtMTMwcHg7XG59XG5cbi5mb290ZXItbWQ6OmJlZm9yZSB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IG5vbmU7XG59XG5cbi5ib3JkZXJOb25lIHtcbiAgYm9yZGVyLXJhZGl1czogMHB4O1xufVxuXG4ucGFkZDEzIHtcbiAgcGFkZGluZy10b3A6IDEzJTtcbn1cblxuLnBhZGQxIHtcbiAgcGFkZGluZzogMSU7XG59XG5cbi5sb2dvU3ZnIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDMwJTtcbiAgbGVmdDogNTAlO1xuICBtYXJnaW4tcmlnaHQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG59Il19 */";

/***/ }),

/***/ 8796:
/*!******************************************************!*\
  !*** ./src/app/sign-up/sign-up.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n   <ion-buttons slot=\"start\">\n    <ion-button fill=\"clear\" >\n      <ion-icon name=\"arrow-back-outline\" color=\"light\"></ion-icon>\n    </ion-button>\n   </ion-buttons>\n    <ion-title dir=\"rtl\"> إنشاء حساب </ion-title>\n  </ion-toolbar> \n</ion-header>\n\n<ion-content>\n  <ion-grid class=\"ion-no-padding\">\n    <ion-row>\n      <ion-col size=\"12\" class=\"head2 ion-text-center \">  \n        <svg class=\"logoSvg\" width=\"157\" height=\"75\" viewBox=\"0 0 157 75\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M47.2954 26.3206L52.6937 20.954H61.6309L51.4418 31.1114L47.2954 26.3206Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M82.3263 0H5.51448H0L2.79949 4.75915L37.6506 63.8707L41.2371 57.5534L17.8111 17.8217H64.2035L67.7319 11.4991H14.0873L11.0342 6.32263H76.8118L76.8065 6.32792H84.1169L85.0465 4.75915L87.846 0H82.3263Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M56.3647 41.0311L38.9656 20.954H30.5513L52.9842 46.7727L47.1951 56.6027L40.397 68.5771L41.2052 69.9504L43.9202 74.5617L46.6404 69.9504L81.0689 11.5044H73.7586L56.3647 41.0311Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M33.4248 40.355L38.9234 34.83L43.1068 39.5838L36.7419 45.9804L33.4248 40.355Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M94.3589 15.4447V26.1039H96.9101V21.6511H105.002V19.5277H96.9101V17.5628H105.251V15.4447H94.3589Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M110.533 18.5189H107.981V26.1039H110.533V18.5189ZM107.981 15.4447V17.5628H110.533V15.4447H107.981Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M115.889 18.5189H113.337V26.104H115.889V22.3431C115.889 20.9909 116.628 20.2673 117.917 20.2673H119.174C120.479 20.2673 120.97 20.8219 120.97 22.1424V26.104H123.521V21.6353C123.521 19.6704 122.386 18.5189 120.141 18.5189H118.081C116.486 18.5189 116.005 19.3007 115.883 19.5965V18.5189H115.889Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M133.869 26.1039H136.42V15.4447H133.869V19.6704C133.805 19.5489 133.288 18.5189 131.671 18.5189H129.4C127.329 18.5189 126.099 19.6862 126.099 21.5455V23.1248C126.099 24.8732 127.129 26.1039 129.4 26.1039H131.671C133.082 26.1039 133.869 25.1215 133.869 25.1215V26.1039ZM132.12 20.2672C133.208 20.2672 133.869 20.9275 133.869 21.7092V22.9241C133.869 23.7059 133.208 24.3503 132.12 24.3503H130.398C129.141 24.3503 128.65 23.859 128.65 22.9241V21.7251C128.65 20.8166 129.109 20.2672 130.398 20.2672H132.12Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M94.3218 30.4775L99.8045 37.5397V41.1367H102.356V37.5397L107.839 30.4775H104.627L101.067 35.4374L97.5333 30.4775H94.3218Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M111.769 33.5148C109.529 33.5148 108.436 34.8828 108.436 36.5572V38.1418C108.436 39.8902 109.635 41.1368 111.769 41.1368H115.334C117.5 41.1368 118.651 39.9061 118.651 38.1735V36.5625C118.651 34.8723 117.547 33.52 115.318 33.52H111.769V33.5148ZM116.1 36.758V37.9728C116.1 38.987 115.577 39.3831 114.457 39.3831H112.719C111.536 39.3831 110.981 38.9394 110.981 37.9834V36.7368C110.981 35.7544 111.536 35.2631 112.719 35.2631H114.457C115.577 35.2684 116.1 35.8653 116.1 36.758Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M121.229 33.5464V37.9252C121.229 40.1701 122.597 41.1367 124.53 41.1367H126.97C128.058 41.1367 128.798 40.7194 129.167 40.1701V41.1367H131.719V33.5517H129.167V37.3125C129.167 38.6489 128.259 39.3831 126.97 39.3831H125.972C124.498 39.3831 123.774 38.7545 123.774 37.3125V33.5517H121.229V33.5464Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M136.848 33.5464H134.296V41.1314H136.848V37.1223C136.848 36.0923 137.571 35.2947 138.596 35.2947H139.531C140.667 35.2947 140.899 35.8652 141.068 36.6311H143.619C143.619 35.0201 143.033 33.5464 140.302 33.5464H139.029C137.967 33.5464 137.466 33.8686 136.848 34.6503V33.5464Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M89.5997 51.5107H84.529C84.529 50.7712 84.8195 50.1268 85.8178 50.1268H88.1683C89.267 50.1321 89.5997 50.7765 89.5997 51.5107ZM92.0453 52.9263V51.6375C92.0453 50.1162 91.2953 48.5527 88.7916 48.5527H85.1681C82.8968 48.5527 81.9883 50.0106 81.9883 51.3469V53.2643C81.9883 54.9229 82.9866 56.1695 85.1205 56.1695H88.855C91.422 56.1695 92.0506 55.018 92.0506 53.6816H89.6103C89.6103 54.2785 89.3198 54.5848 88.7018 54.5848H85.7544C84.7085 54.5848 84.5395 53.877 84.5395 53.2168V52.9263H92.0453Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M94.3747 45.505L99.2923 50.6814L93.7778 56.1642H97.5228L101.305 51.9597L105.081 56.1642H108.832L103.317 50.6814L108.23 45.505H104.775L101.305 49.3926L97.8345 45.505H94.3747Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M113.253 48.5792H110.702V59.2384H113.253V55.1237C113.528 55.5674 114.341 56.1695 115.466 56.1695H117.753C120.025 56.1695 121.07 54.849 121.07 53.1905V51.5319C121.07 49.5987 119.887 48.5845 117.753 48.5845H115.45C114.283 48.5845 113.686 49.0916 113.253 49.493V48.5792ZM118.519 52.9898C118.519 53.9564 117.949 54.4159 116.739 54.4159H114.911C113.792 54.4159 113.253 53.9088 113.253 52.9898V51.759C113.253 50.8505 113.792 50.3329 114.911 50.3329H116.739C117.954 50.3329 118.519 50.8241 118.519 51.759V52.9898Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M131.265 51.5107H126.199C126.199 50.7712 126.49 50.1268 127.488 50.1268H129.839C130.927 50.1321 131.265 50.7765 131.265 51.5107ZM133.705 52.9263V51.6375C133.705 50.1162 132.955 48.5527 130.451 48.5527H126.828C124.556 48.5527 123.648 50.0106 123.648 51.3469V53.2643C123.648 54.9229 124.646 56.1695 126.78 56.1695H130.515C133.082 56.1695 133.71 55.018 133.71 53.6816H131.27C131.27 54.2785 130.979 54.5848 130.361 54.5848H127.414C126.368 54.5848 126.199 53.877 126.199 53.2168V52.9263H133.705Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M138.76 48.5792H136.208V56.1643H138.76V52.1552C138.76 51.1252 139.483 50.3276 140.508 50.3276H141.443C142.579 50.3276 142.811 50.898 142.98 51.6639H145.531C145.531 50.0529 144.945 48.5792 142.214 48.5792H140.941C139.88 48.5792 139.378 48.9014 138.76 49.6832V48.5792Z\" fill=\"white\"/>\n          <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M148.368 47.1055V48.5792H147.443V50.3275H148.368V53.3383C148.368 55.0867 149.472 56.1642 151.442 56.1642H153.053C156.307 56.1642 156.74 54.6588 156.74 53.0636H154.189C154.189 53.8295 153.93 54.4158 153.19 54.4158H152.129C151.389 54.4158 150.914 54.0144 150.914 53.0636V50.3275H155.673V48.5792H150.914V47.1055H148.368Z\" fill=\"white\"/>\n        </svg>\n     </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid class=\"custGrid2 \">\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col size=\"10\" >\n       <ion-card class=\"bordernon w100\" >\n        <ion-card-header>\n          <ion-card-title  *ngIf=\"!verficStep\">\n            <h3 class=\"ion-text-center\"><b>إنشاء حساب</b></h3> \n           </ion-card-title>\n        </ion-card-header>\n        <ion-card-header *ngIf=\"verficStep\">\n          <ion-card-title class=\"ion-text-center\">\n           <h3 ><b> تأكيد الجوال</b></h3> \n          </ion-card-title>\n          <ion-card-subtitle class=\"ion-text-center\">\n             تم إرسال رسالة نصية برمز تأكيد الي   \n          </ion-card-subtitle>\n          <ion-card-subtitle class=\"ion-text-center\">\n            <ion-text *ngIf=\"USER_INFO.phone && orignalCode\"> {{USER_INFO.phone}} - {{orignalCode}} </ion-text>\n          </ion-card-subtitle>\n        </ion-card-header>\n        <ion-grid *ngIf=\"!verficStep\">\n          <form [formGroup]=\"ionicForm\" (ngSubmit)=\"next()\" novalidate> \n            <ion-list class=\"w100\" *ngIf=\"USER_INFO\" dir=\"rtl\">  \n              <ion-item>\n                <ion-label > اسم المستخدم :  </ion-label> \n                <ion-input  formControlName=\"fullName\" [(ngModel)]=\"USER_INFO.fullName\" ></ion-input> \n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.fullName.errors?.required\"> الحقل مطلوب</ion-note>\n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.fullName.errors?.pattern\"> حروف فقط </ion-note>\n              </ion-item> \n              <ion-item>\n                <ion-label>البريد الإلكتروني: </ion-label> \n                <ion-input formControlName=\"email\" [(ngModel)]=\"USER_INFO.email\" ></ion-input> \n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.email.errors?.required\"> الحقل مطلوب </ion-note> \n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.email.errors?.pattern\">    خطأ في صيغة البريد  </ion-note>\n              </ion-item>\n              <ion-item class=\"ion-margin-top\" >\n                <ion-label>الجوال: </ion-label>  \n                <ion-input dir=\"ltr\" formControlName=\"phone\" [(ngModel)]=\"USER_INFO.phone\"> </ion-input> \n                <ion-label slot=\"end\" dir=\"rtl\" class=\"ion-no-margin\"><ion-text color=\"medium\">966+</ion-text></ion-label>\n              </ion-item>\n              <ion-item>\n                <ion-label>تاريخ الميلاد: </ion-label> \n                <ion-input  value=\"{{ USER_INFO.birthDate | date: 'dd MMM yyyy' }}\" id=\"date\" (click)=\"presentPopover($event)\"></ion-input>\n                <ion-popover #popover [isOpen]=\"isOpen\" trigger=\"date\">\n                    <ng-template>\n                        <ion-datetime max=\"2004-01-01T00:00:00\"  min=\"1960-12-30T23:59:59\" formControlName=\"birth\" presentation=\"date\" [(ngModel)]=\"USER_INFO.birthDate\" locale=\"en-US\" (ionChange)=\"dateChange($event)\"></ion-datetime>\n                    </ng-template>\n                </ion-popover>\n              </ion-item>\n              <ion-radio-group formControlName=\"gender\"  [(ngModel)]=\"USER_INFO.gender\" (ionChange)=\"genderChange($event)\">\n                  <ion-grid>\n                    <ion-row>\n                      <ion-col size=\"6\">\n                        <ion-item>\n                          <ion-label>ذكـر</ion-label>\n                          <ion-radio slot=\"start\" value=0>  </ion-radio>\n                        </ion-item> \n                      </ion-col>\n                      <ion-col size=\"6\">\n                        <ion-item>\n                          <ion-label>انثي</ion-label>\n                          <ion-radio slot=\"start\" value=1></ion-radio> \n                        </ion-item> \n                      </ion-col>\n                    </ion-row>\n                  </ion-grid> \n              </ion-radio-group>  \n               <ion-item>\n                <ion-label>كلمة المرور</ion-label> \n                <ion-input formControlName=\"password\" [(ngModel)]=\"USER_INFO.password\" [type]=\"passType\"></ion-input>\n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.required\"> الحقل مطلوب </ion-note> \n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.length\"> مكون من 5 رموز علي الأقل </ion-note> \n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.password.errors?.pattern\"> يحوي حرف كبير وصغير ورمز ورقم</ion-note> \n                <ion-button  fill = \"clear\" (click)=\"showPass('pass')\">\n                  <ion-icon  *ngIf=\"show == false\"  slot=\"end\"   name=\"eye-off-outline\" ></ion-icon>\n                  <ion-icon *ngIf=\"show == true\"   slot=\"end\"   name=\"eye-outline\" ></ion-icon>\n                 </ion-button>\n              </ion-item>\n              <ion-item>\n                <ion-label>تأكيد كلمة المرور</ion-label> \n                <ion-input formControlName=\"confirmPass\" [(ngModel)]=\"confirmPass\"  [type]=\"confType\"></ion-input>\n                <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && USER_INFO.password.length > 0 && USER_INFO.password != confirmPass\">  كلمة المرور غير مطابقة  </ion-note> \n                \n               <ion-button  fill = \"clear\" (click)=\"showPass('confirm')\">\n                <ion-icon  *ngIf=\"showConf == false\"  slot=\"end\"   name=\"eye-off-outline\" ></ion-icon>\n                <ion-icon *ngIf=\"showConf == true\"   slot=\"end\"   name=\"eye-outline\" ></ion-icon>\n               </ion-button>\n              </ion-item>  \n\n              <ion-grid>\n                <ion-row>\n                  <ion-col size=\"12\">\n                    <ion-item button lines=\"none\" (click)=\"showTerms()\"><ion-label>قراءة الشروط الأحكام</ion-label> </ion-item>\n                  </ion-col>\n                  <ion-col size=\"12\">\n                    <ion-item lines=\"none\">\n                      <ion-checkbox  formControlName=\"agree\" [(ngModel)]=\"agree\" (ionChange)=\"agreeCheck($event)\"></ion-checkbox>\n                      <ion-label class=\"ion-margin-start\">    الموافقة علي الشروط  </ion-label> \n                      <ion-note slot=\"error\" *ngIf=\"isSubmitted == true && errorControl.agree.errors?.required\"> يجب الموافقة علي الشروط والأحكام  </ion-note> \n                    </ion-item>\n                  </ion-col> \n                </ion-row>\n              </ion-grid> \n            </ion-list>\n        \n            <ion-row class=\"ion-margin\" dir=\"rtl\" >\n              <ion-col size=\"12\" *ngIf=\"!verficStep \">\n                <ion-item color=\"primary\" [disabled]=\"spinner == true\" button (click)=\"next()\">\n                  <ion-label class=\"ion-text-center\">\n                    <ion-text >التالي</ion-text> \n                  </ion-label> \n                </ion-item>\n              </ion-col>\n              <ion-col size=\"12\" *ngIf=\"verficStep\">\n                <ion-item color=\"primary\" [disabled]=\"spinner == true\" button (click)=\"save()\">\n                  <ion-label class=\"ion-text-center\">\n                    \n                    <ion-text >حفــظ</ion-text>\n                  </ion-label>\n                  <ion-spinner name=\"lines\" color=\"light\" *ngIf=\"spinner == true\"></ion-spinner>  \n                </ion-item>\n              </ion-col>\n            </ion-row>\n\n          \n            <ion-row class=\" ion-justify-content-center\"> \n              <ion-col size=\"3\" class=\"ion-text-center\">\n                <ion-label><h3>أو</h3></ion-label>\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col size=\"6\">\n                <ion-item [disabled]=\"spinner == true\" color=\"primary\" button (click)=\"getInfo('google')\"> \n                  <ion-label class=\"ion-text-center\">google</ion-label>\n                  <ion-icon name=\"logo-google\" color=\"danger\"></ion-icon>\n                </ion-item>\n              </ion-col>\n              <ion-col size=\"6\">\n                <ion-item [disabled]=\"spinner == true\" color=\"primary\" button (click)=\"getInfo('apple')\"> \n                  <ion-label class=\"ion-text-center\">Apple</ion-label>\n                  <ion-icon name=\"logo-apple\" ></ion-icon>\n                </ion-item>\n              </ion-col>\n            </ion-row> \n          </form>\n        </ion-grid>\n\n        <ion-grid *ngIf=\"verficStep\"> \n          <form [formGroup]=\"ionic2Form\" (ngSubmit)=\"confirmAccount()\" novalidate>\n            <ion-row class=\"ion-padding-start\">\n              <ion-label>أدخل رمز التأكيد</ion-label> \n            </ion-row>\n            <ion-row class=\"ion-margin\" *ngIf=\"orignalCode\"> \n              <ion-col> \n                <ion-item>\n                  <ion-input class=\"custInput\" formControlName=\"code\" [(ngModel)]=\"code\" ></ion-input>\n                    <ion-note slot=\"error\" *ngIf=\"isSubmitted2 == true && errorControl2.code.errors?.pattern\">ادخل ارقام فقط  </ion-note> \n                    <ion-note slot=\"error\" *ngIf=\"isSubmitted2 == true && errorControl2.code.errors?.required\">رمز التأكيد مطلوب </ion-note>\n                    <ion-note slot=\"error\" *ngIf=\"isSubmitted2 == true && (errorControl2.code.errors?.minlength || errorControl2.code.errors?.maxlength)\">يجب ان يتكون من4 أرقام </ion-note> \n                </ion-item> \n              </ion-col> \n            </ion-row> \n           \n            <ion-row class=\"ion-margin\" >\n              <ion-col size=\"12\">\n                <ion-item color=\"primary\" button  [disabled]=\"spinner == true\"  (click)=\"save()\">\n                  <ion-label class=\"ion-text-center\">إرسال</ion-label> \n                  <ion-spinner name=\"lines\" color=\"light\" *ngIf=\"spinner == true\"></ion-spinner> \n    \n                </ion-item>\n              </ion-col>\n            </ion-row>\n            <ion-row class=\"ion-justify-content-start\">\n              <ion-button  fill=\"clear\"(click)=\"getsms()\">\n                <ion-label><ion-text color=\"primary\"><b>إعادة إرسال الرمز</b></ion-text></ion-label>\n              </ion-button>\n            </ion-row>  \n          </form>\n        </ion-grid>\n         \n          <ion-footer>\n            <ion-grid>\n              <ion-row class=\"ion-justify-content-center\">\n                <ion-col size=\"12\" class=\"ion-text-center\">\n                  <ion-button fill=\"clear\"  (click)=\"login()\">\n                    <ion-label color=\"medium\">هل لديك حساب? <ion-text color=\"dark\"><strong> تسجيل دخول</strong> </ion-text></ion-label>\n                  </ion-button>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </ion-footer>\n        </ion-card>\n      </ion-col>\n      </ion-row>\n      \n  </ion-grid>\n \n</ion-content>\n \n";

/***/ })

}]);
//# sourceMappingURL=src_app_sign-up_sign-up_module_ts.js.map